#!/bin/bash

# Get a list of all subdirectories in the current working directory
unset http_proxy
unset https_proxy
cd /app/repo/web_mon
hg pull https://yukesh.srinivasan:6Vxst8aPp@cmsuite.csez.zohocorpin.com/zoho//web_mon
hg update
#hg heads --template '{date|isodate}\n' -r 'not closed()' >commit.txt
cd /app/repo/me_apm_components
hg pull https://yukesh.srinivasan:6Vxst8aPp@cmsuite.csez.zohocorpin.com/me//me_apm_components
hg update
: '
#hg heads --template '{date|isodate}\n' -r 'not closed()' >commit.txt
directories=$( find /home/test/Documents/repo/ -mindepth 1 -maxdepth 1 -type d \( ! -name Custom_Semgrep -a ! -name Source ! -name .hg ! -name red-team-scripts ! -name redteam_scripts ! -name security \))
#directories="/home/test/Documents/repo/web_mon"
# Loop over each subdirectory and run the semgrep command
for folder in $directories
do
    cd "$folder"
    #folders="${folder#./}"
    base=$(basename "$folder")
    folders="$folder/$base"
    folder2="$folder"
    echo $base
    if [ -f "${folders}.txt" ]
    then
        output_file="${folder2}/current_${base}.txt"
    else
        output_file="${folders}.txt"
    fi
    #semgrep scan --config auto  --exclude='commit.txt' --exclude='result.txt' --exclude='prev_security.xml' --exclude="$base.txt" --exclude="uniq_file.txt" --gitlab-sast -o "$output_file"
    if [ -f "${folders}.txt" ] && [ -f "${folder2}/current_${base}.txt" ]
    then
        python3 /home/test/Documents/repo/final_json.py "${folders}.txt" "${folder2}/current_${base}.txt" >"$folder/result.txt"
        rm "${folders}.txt"
        mv "${folder2}/current_${base}.txt" "${folders}.txt"
    else
       cat "${folders}.txt" >"$folder/result.txt"
    fi
     echo "finish"
    cd ..
done
  '
