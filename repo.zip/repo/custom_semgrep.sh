rules="check_roles.yml public_api.yml internal_true.yml fileinput.yml persparam.yml"
fold="/app/repo/Custom_Semgrep/rules/"
output="/app/repo/Custom_Semgrep/output"
directories=$(find /app/repo/Custom_Semgrep/rules -mindepth 1 -maxdepth 1 -type d)
#directories="/app/repo/Custom_Semgrep/rules/invalid_authentication"
for folder in $directories
do
    cd "$folder"
    #folders="${folder#./}"
    base=$(basename "$folder")
    folders="$folder/$base"
    folder2="$folder"
    echo $base
    if [ -f "${folders}.txt" ]
    then
        output_file="${folder2}/current_${base}.txt"
    else
        output_file="${folders}.txt"
    fi

    if [ "$base" = "plus_request_validate" ]; then
      semgrep --config  /app/repo/Custom_Semgrep/rules/plus_request_validate/plus_request_validate.yml  /app/repo/pluss247server  --gitlab-sast -o "$output_file"
    else
      semgrep scan --config "/app/repo/Custom_Semgrep/rules/$base/$base.yml" /app/repo --exclude='commit.txt' --exclude='*APIRequestBy*.xml' --exclude='prev_security.xml' --exclude='result.txt' --exclude="$base.txt"  --exclude="uniq_file.txt" --gitlab-sast -o "$output_file"
    fi

    if [ -f "${folders}.txt" ] && [ -f "${folder2}/current_${base}.txt" ]
    then
        echo "${folders}.txt"
        echo "${folder2}/current_${base}.txt"
        python3 /app/repo/final_json.py "${folders}.txt" "${folder2}/current_${base}.txt" >"$folder/result.txt"
        rm "${folders}.txt"
        echo "true"
        mv "${folder2}/current_${base}.txt" "${folders}.txt"
    else
       echo "false"
       cat "${folders}.txt" >"$folder/result.txt"
    fi
     echo "finish"
    cd ..
done

#semgrep --config  /home/test/Documents/repo/Custom_SegGrep/rules/plus_request_validate/plus_request_validate.yml  /home/test/Documents/repo/pluss247server  --gitlab-sast -o /home/test/Documents/repo/Custom_SegGrep/rules/plus_request_validate/plus_request_validate.txt

#semgrep --config  /home/test/Documents/repo/Custom_SegGrep/rules/check_roles.yml  /home/test/Documents/repo  --gitlab-sast -o /home/test/Documents/repo/Custom_SegGrep/output/check_user_roles.txt
#semgrep --config  /home/test/Documents/repo/Custom_SegGrep/rules/public_api.yml  /home/test/Documents/repo  --gitlab-sast -o /home/test/Documents/repo/Custom_SegGrep/output/public_api.txt
#semgrep --config  /home/test/Documents/repo/Custom_SegGrep/rules/internal_true.yml  /home/test/Documents/repo  --gitlab-sast -o /home/test/Documents/repo/Custom_SegGrep/output/internal_true.txt
