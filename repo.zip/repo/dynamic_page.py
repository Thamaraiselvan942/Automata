import datetime
import html
now = datetime.datetime.now()
date=str(now.strftime("%Y-%m-%d %H:%M:%S"))

f=open("/app/repo/link.txt","r")
urls=f.readlines()
f2=open("/app/repo/all_link.txt","r")
url2=f2.readlines()
f3=open("/app/repo/custom_link.txt","r")
url3=f3.readlines()
print(date)
htmll = "<html>\n<head>\n<title>Static CVE Analyzer</title>\n</head>\n<body>\n<h1>Static CVE Analyzer "+date+"</h1>\n"

for url in urls:
    url=url.replace("\n","")
    if(url!="" and "Custom_SegGrep" not in url):
        htmll += f'<a href="{url}" target="_blank">{url}</a><br>\n'

htmll+=f'<h1>Custom Semgrep Rules CVE</h1><br>\n'
for url in url3:
    url=url.replace("\n","")
    if(url!=""):
        htmll += f'<a href="{url}" target="_blank">{url}</a><br>\n'

htmll+=f'<h1>Daily Updated Code CVE</h1><br>\n'

for url in url2:
    url=url.replace("\n","")
    if(url!=""):
        htmll += f'<a href="{url}" target="_blank">{url}</a><br>\n'

htmll += "</body>\n</html>"

with open("/app/repo/automation.html", "w") as f:
    f.write(htmll)
#=================================================================================================================================
last_run = now.strftime('%d-%m-%Y')
file="/app/repo/security/"+last_run+"/new_security_changes.txt"
output_test=""
with open(file, 'r') as f:
    output_text = f.read()
    output_text = html.escape(output_text)
    output_text=output_text.strip()
if(output_text=="" or output_text=="\n"):
    output_text="No security configurations have been updated yet."

html = """
<nav class="navbar navbar-expand navbar-dark bg-white topbar mb-4 static-top shadow">

    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <div>
        <h1 class="h3 mb-0 text-gray-800">Daily Updated Security Configurations</h1>
        <span class="">The report is generated on {last_run}</span>
    </div>
</nav>
<style>
    table {{
      border-collapse: collapse;
    }}
    tr {{
      padding: 8px;
    }}
    .highlight:hover {{
      cursor: pointer;
    }}
  pre.prettyprint {{
  background-color: #f5f5f5;
  border: 1px solid #ccc;
  font-size: 14px;
  padding: 10px;
  white-space: pre-wrap;
}}

pre.prettyprint code {{
  font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
}}
</style>

<div class="row">
        <div class="col-xl-12 col-lg-7">
        <div class="card shadow mb-4">
        <div class="card-header py-3">
           <pre class="prettyprint">{output_text}</pre>
           </div>
       </div>
    </div>

</div>
""".format(last_run=last_run, output_text=output_text)

with open('/app/repo/Source/SEMGREP/templates/web_security.html', 'w') as f:
    f.write(html)
