#!/usr/bin/python3
import os
import gitlab
import subprocess
import time

REPO_FOLDER = "/app/repo/"
gl = gitlab.Gitlab()
gl = gitlab.Gitlab(url='https://git.csez.zohocorpin.com', private_token='Zceskw3tbcs4FexqSfgy')
#135
gid=[156,135]
for id in gid:
    group = gl.groups.get(id)
    for project in group.projects.list(iterator=True):
        project_obj = gl.projects.get(project.id)
        '''
        commits = project_obj.commits.list(ref_name='master', per_page=1)
        last_commit_time="0"
        if commits:
            last_commit = commits[0]
            last_commit_time = last_commit.created_at
            print(last_commit_time)
        else:
            print("commit not happned")'''
        ind=project.ssh_url_to_repo.rfind("/")+1
        ind2=project.ssh_url_to_repo[ind:].index(".")
        repo_name=project.ssh_url_to_repo[ind:ind2+ind]
        print(repo_name)
        repo = REPO_FOLDER  + repo_name
        #print ("repo name" + repo + "\t Is exists" +  str(os.path.exists(repo)))
        print(repo)
        if(os.path.exists(repo)):
            print("repo Already Exist",os.getcwd(),project.ssh_url_to_repo)
            os.chdir(repo)
            os.system("git stash")
            branch_cmd = "git branch --show-current"
            branch_process = subprocess.Popen(branch_cmd.split(), stdout=subprocess.PIPE)
            branch_output, _ = branch_process.communicate()
            current_branch = branch_output.decode("utf-8").strip()
            pull_cmd = f"git pull --set-upstream origin default"
            print(current_branch)
            if current_branch != "default":
                pull_cmd = pull_cmd.replace("default", current_branch)

            # Run the git pull command
            pull_process = subprocess.Popen(pull_cmd.split())
            pull_process.communicate()
            #subprocess.call(['git', 'pull'])
        else:
            print("Repo not found Cloning...",project.ssh_url_to_repo)
            os.chdir("/app/repo/")
            subprocess.call(['git', 'clone', project.ssh_url_to_repo])
        ''' with open("commit.txt", 'w') as f:
            if(last_commit_time=="0"):
                f.write("commit not happned")
            else:
                f.write(last_commit_time)'''
        time.sleep(2)



'''
ssh://git@git.csez.zohocorpin.com:2222/apminsight/rum.git
fatal: destination path '/app/repo' already exists and is not an empty directory.
'''
