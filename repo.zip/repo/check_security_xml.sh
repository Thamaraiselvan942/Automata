files=$(find /app/repo -type f -name "*security.xml" ! -name "*prev_*security.xml")
mkdir -p /app/repo/security/"`date +"%d-%m-%Y"`"
output=/app/repo/security/"`date +"%d-%m-%Y"`"/new_security_changes.txt
touch $output
#rm $output
for file in $files
do
   base=$(basename "$file")
   folder="${file/$base}"
   folder="${folder%/}"
   res=$(echo $file | cut -d / -f 6 )
   #echo $res
   res=$(echo $res | tr '[:lower:]' '[:upper:]')
   #echo $res >>$output
   #len="${#res}"
   #for ((i=1; i<=$len; i++)); do printf '='; done >>$output
   #printf '\n' >>$output
   #echo "File $file: " >> $output
   out=$(diff "$folder/prev_$base" "$file")
   if [ -n "$out" ] && [ ${#out} -gt 0 ]; then
      echo "true"
      echo $res >>$output
      len="${#res}"
      for ((i=1; i<=$len; i++)); do printf '='; done >>$output
      printf '\n' >>$output
      echo "File $file: " >> $output
      echo "$out" >> $output
      printf '\n\n' >>$output
   fi

   #diff $folder/prev_$base $file >> $output
   #for i in {1..150}; do printf '='; done >>$output
   #printf '\n\n' >>$output

   rm $folder/prev_$base
   #echo $folder/prev_$base
   cp $file "$folder/prev_$base"
done
