#!/bin/sh
unset http_proxy
unset https_proxy
echo "Repository Cloning Started..."
python3 /app/repo/sast.py
echo "Semgrep Execution Started..."
sh /app/repo/script.sh
echo "Send Repo Difference to Cliq Bot..."
bash /app/repo/bot.sh

