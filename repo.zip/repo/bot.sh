echo "Notifying the customer on cliq"
ip=$(ip addr show enp0s3 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
url="http://$ip:8000"
sh /app/repo/custom_semgrep.sh
output=$(find /app/repo/ -type f -name result.txt)
res=""
rm /app/repo/link.txt
rm /app/repo/all_link.txt
for item in $output; do
  dir=$(echo $item | sed 's,/result.txt,,g')
  touch $dir/commit.txt
  given_date=$(cat $dir/commit.txt | cut -dT -f1 | cut -d ' ' -f1)
  today=$(date +%Y-%m-%d)
  yesterday=$(date -d "yesterday" +%Y-%m-%d)
  date_flg="false"
  if [ "$given_date" = "$today" ] || [ "$given_date" = "$yesterday" ]; then
    date_flg="true"
  else
    date_flg="false"
  fi
  #echo $given_date
  #echo $date_flg
  flg=$(cat $item | jq '.vulnerabilities | length > 0')
  # && [ "$date_flg" = "true" ];
 if [ "$flg" = "true" ]
  then
   echo $flg
   echo $item
  if [[ "$item" =~ /repo/(.+) ]]; then
    result="${BASH_REMATCH[1]}"
    path="$result"
  fi
   #url="http://10.51.49.239:8000"
   res="$url/$path"
   echo $res
  echo $res >>/app/repo/link.txt
fi
done
touch /app/repo/link.txt
#tmp="http://10.51.49.239:8000/automation.html"
tmp="http://$ip:8000/automation.html"
directories=$(find /app/repo/Custom_Semgrep/rules/ -mindepth 1 -maxdepth 1 -type d \( ! -name Custom_Semgrep -a ! -name Source ! -name .hg ! -name red-team-scripts ! -name redteam_scripts ! -name security \))
for item in $directories; do
 path=$(basename "$item")
 #path="${item#./}"
 res="$url/$path/$path.txt"
 echo $res >>/app/repo/all_link.txt
done
touch /app/repo/all_link.txt
#=================================================================================================================================================================
rm /app/repo/custom_link.txt
#sh /app/repo/custom_semgrep.sh
output=$(find /app/repo/Custom_Semgrep/rules/ -mindepth 1 -maxdepth 1 -type d)
for item in $output; do
 path=$(basename "$item")
 item="$item/$path.txt"
 flg=$(cat $item | jq '.vulnerabilities | length > 0')
 if [ "$flg" = "true" ];
  then
  if [[ "$item" =~ /repo/(.+) ]];
   then
    result="${BASH_REMATCH[1]}"
    path="$result"
  fi
  # url="http://10.51.49.72:8000"
   res="$url/$path"

   echo $res >>/app/repo/custom_link.txt
fi
done
touch /app/repo/custom_link.txt
bash /app/repo/check_security_xml.sh
python3 /app/repo/cliq.py
python3 /app/repo/dynamic_page.py
#==================================================================================================================================================================
#echo "Generate Access Token..."
#access_token=$(curl -s https://accounts.zoho.com/oauth/v2/token -X POST -d "refresh_token=1000.2613be0b91f28b73d001f886d858282a.3b74a81549afb4506188d6111e8405d0" -d "grant_type=refresh_token" -d "client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO" -d "client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800"| jq '.access_token')
#access_token=$(echo $access_token | tr -d '"')
#echo $access_token
#data="http://$ip:8000/automation.html"
#curl https://cliq.zoho.com/api/v2/channelsbyname/sitexredteamprivatej/message -H "Content-Type: application/json;charset=UTF-8" -H "Accept: application/json; version=2.0" -H "Authorization: Zoho-oauthtoken $access_token" -d "{\"text\" : \"Semgrep Automation Result: $data\"}"
#curl https://cliq.zoho.com/api/v2/channelsbyname/sitexredteameasm/message -H "Content-Type: application/json;charset=UTF-8" -H "Accept: application/json; version=2.0" -H "Authorization: Zoho-oauthtoken $access_token" -d "{\"text\" : \"Semgrep Automation Result: $data\"}"
