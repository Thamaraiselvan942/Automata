import sys
import simplejson as json
import re
from jsondiff import diff
import os
def validate_json(file):
    with open(file, 'r') as f:
        json_obj = json.load(f)
        return json_obj
        json_data = f.read()
        fixed_json_data = ""
        prev_char = ""
        for i, char in enumerate(json_data):
            if prev_char == '"' and char in [']', '}']:
                fixed_json_data += ','
            fixed_json_data += char
            prev_char = char
        fixed_json_data = re.sub(r'([{\[,])(\s*)([a-zA-Z0-9_]+)(\s*):', r'\1\2"\3"\4:', fixed_json_data)
        fixed_json = json.loads(fixed_json_data)
        return fixed_json
def remove_non_json_keys(obj):
    if isinstance(obj, dict):
        return {k: remove_non_json_keys(v) for k, v in obj.items() if isinstance(k, (str, int, float, bool, type(None)))}
    elif isinstance(obj, list):
        return [remove_non_json_keys(i) for i in obj]
    else:
        return obj

def read_line(filename, line_content):
    with open(filename, 'r') as file:
        for i, line in enumerate(file, start=1):
            if line.strip() == line_content:
                return line.strip()


def print_line_at(filename, line_number):
    with open(filename, 'r') as file:
        for i, line in enumerate(file, start=1):
            if i == line_number:
                return line.strip()


def check_file_path_exists(file_path):
    return os.path.exists(file_path)

def check(path,line_no,name,type):
    ind=file2.rfind("/")
    file=file2[:ind]
    rule_name=file1[ind+1:].replace(".txt","")
    Flag=True
    fpath=file+"/uniq_file.txt"
    curr_content=""
    prev_content=""
    if(check_file_path_exists(fpath)):
        f=open(fpath,"r")
        lin=json.load(f)
        if(path in lin.keys()):
            prev_content=lin[path]
        if("/app/repo/" not in path):
            curr_content=print_line_at("/app/repo/"+path,line_no)
        else:
            curr_content=print_line_at(path,line_no)
        curr_content=curr_content.strip()
        if(curr_content in prev_content):
            Flag=False
    return Flag

file1 = sys.argv[1]
file2 = sys.argv[2]
fixed_json1=validate_json(file1)
fixed_json2=validate_json(file2)
type=True
if("Custom_Semgrep" in file1):
    type=False
f=[]
f2=[]
c=0
l=[]
m=[]
def Uniq_Dict(path,line_no,uniq_dict):
    curr_content=""
    if("/app/repo/" not in path):
        curr_content=print_line_at("/app/repo/"+path,line_no)
    else:
        curr_content=print_line_at(path,line_no)
    if(curr_content!=None and curr_content!=""):
        curr_content=curr_content.strip()
        if(path not in uniq_dict.keys()):
            uniq_dict[path]=[curr_content]
        else:
            uniq_dict[path].append(curr_content)
uniq_dict={}
for val in range(len(fixed_json2["vulnerabilities"])):
    if("id" in fixed_json2["vulnerabilities"][val].keys()):
        l.append(fixed_json2["vulnerabilities"][val]["id"])
        path=fixed_json2["vulnerabilities"][val]["location"]["file"]
        line=fixed_json2["vulnerabilities"][val]["location"]["start_line"]
        Uniq_Dict(path,line,uniq_dict)

for val in range(len(fixed_json1["vulnerabilities"])):
    if("id" in fixed_json1["vulnerabilities"][val].keys()):
        m.append(fixed_json1["vulnerabilities"][val]["id"])
        path=fixed_json1["vulnerabilities"][val]["location"]["file"]
        line=fixed_json1["vulnerabilities"][val]["location"]["start_line"]
        Uniq_Dict(path,line,uniq_dict)
r=[]
for i in l:
    if(i not in m):
        r.append(i)
jsn={"vulnerabilities":[],"scan":{"start_time":fixed_json2["scan"]["start_time"]}}
for val in range(len(fixed_json2["vulnerabilities"])):
   id=fixed_json2["vulnerabilities"][val]["id"]
   if(id in r):
       path=fixed_json2["vulnerabilities"][val]["location"]["file"]
       line=fixed_json2["vulnerabilities"][val]["location"]["start_line"]
       name=fixed_json2["vulnerabilities"][val]["identifiers"][0]["name"]
       if((name!="" and path!="" and line!="") and (name!=None and path!=None and line!=None)): 
           res=check(path,line,name,type)
           if(res==True):
               jsn["vulnerabilities"].append(fixed_json2["vulnerabilities"][val])

ind=file1.rfind("/")
file=file1[:ind]
fpath=file+"/uniq_file.txt"
f=open(fpath,"w")
json.dump(uniq_dict,f)
json_diff=json.dumps(jsn,indent=4)
print(json_diff)

