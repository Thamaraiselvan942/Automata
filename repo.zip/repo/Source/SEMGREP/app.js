var app = angular.module('asm.app', ['ui.router', 'chart.js']);
var url_domain="http://10.51.49.72:8080"
app.config(['$stateProvider', '$urlRouterProvider','ChartJsProvider', function($stateProvider, $urlRouterProvider, ChartJsProvider){
        (function (ChartJsProvider) {
                ChartJsProvider.setOptions({ colors : [ '#803690', '#00ADF9', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'] });
        });

        $urlRouterProvider.when('', '/semgrep/list');//NO I18N
$stateProvider.state({
    name: 'custom_web_security',
    url: '/security/list/:date',
    templateUrl: 'templates/custom_web_security.html',
    controller: 'CustomWebSecurityController',
    resolve: {
      loadData: ['$http', '$stateParams', function($http, $stateParams) {
        var date = $stateParams.date;
        return $http.get(url_domain + '/get_security_xml/' + date);
      }]
    }
  });

  $urlRouterProvider.otherwise('/semgrep/list');

  var domainState = {
    name: 'domains',
    url: '/semgrep/:filename',
    templateUrl: 'templates/domains.html',
    controller: "domainController"
  }
 var web_security = {
    name: 'security',
    url: '/security/list',
    templateUrl: 'templates/web_security.html',
    controller: "WebsecurityController"
  }

  var addDomainState = {
    name: 'add-domain',
    url: '/domains/add',
    templateUrl: 'templates/add-domain.html',
    controller: "AddwDomainController"
  }

  var domainDetails = {
        name: 'domain-details',
    url: '/domains/:domain_id',
    templateUrl: 'templates/domain-details.html',
    controller: "DomainDetailsController"
  }

  var addSubscriberState = {
        name: 'add-subscriber',
    url: '/subscribers/add',
    templateUrl: 'templates/add-subscribers.html',
    controller: "AddSubscriberController"
  }

  var subscribersListState = {
        name: 'list-subscriber',
    url: '/subscribers/list',
    templateUrl: 'templates/subscribers-list.html',
    controller: "ListSubscriberController"
  }
 var linuxagent = {
    name: 'linuxagent',
    url: '/semgrep/list',
    templateUrl: 'templates/lin-agent.html',
    controller: "LinuxAgentController"
  }
  var custom_web_security = {
    name: 'custom_web_security',
    url: '/security/list/:date',
    templateUrl: 'templates/custom_web_security.html',
    controller: "CustomWebSecurityController"
  }
 var custom_semgrep = {
    name: 'custom_semgrep',
    url: '/custom_semgrep/list',
    templateUrl: 'templates/custom_semgrep.html',
    controller: "New_Custom_SemgrepController"
  }
var linuxpoller = {
    name: 'linuxpoller',
    url: '/linuxpoller/list',
    templateUrl: 'templates/lin-poller.html',
    controller: "LinuxPollerController"
  };
var windowspoller = {
    name: 'windowspoller',
    url: '/windowspoller/list',
    templateUrl: 'templates/win-poller.html',
    controller: "WindowsPollerController"
  };
 var gitasset = {
    name: 'gitasset',
    url: '/git_assets/list',
    templateUrl: 'templates/gitassets.html',
    controller: "GitController"
  };
 var gdorks = {
    name: 'gdorks',
    url: '/gdorks/<img src=x>',
    templateUrl: 'templates/gdorks.html',
    controller: "GDorksController"
  };
 var blacklist = {
    name: 'blacklist',
    url: '/blacklist/ip',
    templateUrl: 'templates/blacklist.html',
    controller: "BlacklistController"
  };
var zonetransfer = {
    name: 'zonetransfer',
    url: '/zonetransfer',
    templateUrl: 'templates/zone_transfer.html',
    controller: "ZonetransferController"
  };
  $stateProvider.state(domainState);
  $stateProvider.state(domainDetails);
  $stateProvider.state(addDomainState);
  $stateProvider.state(addSubscriberState);
  $stateProvider.state(subscribersListState);
  $stateProvider.state(linuxagent);
  $stateProvider.state(linuxpoller);
  $stateProvider.state(windowspoller);
  $stateProvider.state(gitasset);
  $stateProvider.state(gdorks);
  $stateProvider.state(blacklist);
  $stateProvider.state(zonetransfer);
  $stateProvider.state(custom_semgrep);
  $stateProvider.state(web_security);
}]);


app.controller('AppController', ['$scope', '$stateParams', '$http', function($scope, $stateParams, $http) {
        $scope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];

  $scope.title = "Domains secured by Site24x7 EASM";
  $scope.sub_title = "Secure your Domain by adding it to our EASM";
  $scope.action_link = "/index.html#!/domains/add";
  $scope.action_text = "Add a Domain";

        $scope.processing = true;
                $scope.processing = false;
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  $scope.options = {
    scales: {
      yAxes: [
        {
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left'
        },
        {
          id: 'y-axis-2',
          type: 'linear',
          display: true,
          position: 'right'
        }
      ]
    }
  };


  $scope.pie_labels =["Critical", "High", "Medium", "Low", "Info"];

  $scope.pie_data = [
    [1, 2, 3, 4, 5]
  ];


}]);

app.controller('DomainDetailsController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
  //$scope.domain_name = "";

  $scope.processing = true;
  var domain_id = $stateParams.domain_id
  $http.get(url_domain+'/api/assets/' + domain_id).then(function(response){
      $scope.processing = false;
      console.log(response.data);
      $scope.result = response.data;
      $scope.domain_name = $scope.result.domain_name;
      $scope.last_run = $scope.result.last_run;
      $scope.port_details = $scope.result.port_details;
      $scope.port_count = $scope.result.port_count;
      $scope.dork_count = $scope.result.dorks_count;
      $scope.zone_count = $scope.result.zone_count;
      $scope.sub_domains = $scope.result.sub_domains;
      $scope.vuln_detials = $scope.result.vuln_detials;
      $scope.fuzzing= $scope.result.fuzz_details;
      $scope.vulnerabilitiesCount = $scope.result.vulnerabilities;
      $scope.repetition = $scope.result.repetition;
      $scope.labels = $scope.result.asset_history.label;
      $scope.series = $scope.result.asset_history.series;
      $scope.data = $scope.result.asset_history.data;
      $scope.result_dat = {};

      $scope.port_details.forEach((item) => {
      const { ip, service, version } = item;
      const port = item.port;
      if (!$scope.result_dat[port]) {
        $scope.result_dat[port] = [];
      }
      $scope.result_dat[port].push([ip, service, version]);
});
      $scope.title = "Attack Surface of " + $scope.result.domain_name
      $scope.result_data=$scope.result_dat
    });
  $scope.addDomain = function(domain_name){
    postdata = {"domain-name": domain_name};
    $scope.processing = true;
    $http.post(url_domain+'/api/add-domain', postdata).then(function(response){
      $scope.processing = false;
          alert(response.data.status);
      });
}
  $http.get(url_domain+'/get_data/dorks?id='+domain_id).then(function(response){
    $scope.processing = false;
    $scope.dorks = response.data["dork"]
   });

   $scope.expandedRows2 = {};

  $scope.toggleRow2 = function(port) {
    $scope.expandedRows2[port] = !$scope.expandedRows2[port];
  };

   $http.get(url_domain+'/get_data/zone_transfer?id='+domain_id).then(function(response){
    $scope.processing = false;
    $scope.zone = response.data["zone"]["result"]
   });

}]);

app.controller('AddDomainController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
        $scope.addDomain = function(domain_name){
                postdata = {"domain-name": domain_name};
                $scope.processing = true;
                $http.post(url_domain+'/api/add-domain', postdata).then(function(response){
                        $scope.processing = false;
                alert(response.data.status);
        });
        }

}]);


app.controller('AddSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/domain/list').then(function(response){
    $scope.processing = false;
         //handle your response here
         $scope.domains = response.data.result;
    });

  $scope.addSubscriber= function(mobile, selected_domains, selected_categories){
   //postdata = {"mobile":mobile,"domains":selected_domains,"categories":selected_categories };
   postdata={"Phone":mobile,"Subscribe":[]}
   var arr=[];
   //var obj={"domain":"","asset":0,"low":0,"info":0,"high":0,"medium":0,"critical":0}
    var asset=0;
    var low=0;
    var medium=0;
    var critical=0;
    var high=0;
    var info=0;
   if (selected_categories.indexOf('New Asset') > -1) {
         asset=1;

    }
   if (selected_categories.indexOf('New High Vulnrability') > -1) {
         high=1;

   }
   if (selected_categories.indexOf('New Medium Vulnrability') > -1) {
         medium=1;

    }
   if (selected_categories.indexOf('New Critical Vulnrability') > -1) {
         critical=1;

    }
   if (selected_categories.indexOf('New Low Vulnrability') > -1) {
         low=1;

    }
   if (selected_categories.indexOf('New Info Vulnrability') > -1) {
         info=1;

    }


   for (var domain of selected_domains) {
         var obj={"domain":domain,"asset":asset,"low":low,"info":info,"high":high,"medium":medium,"critical":critical};
         arr.push(obj);

  }
postdata.Subscribe=arr

   //alert(postdata)/api/add/subscribe
   $scope.processing = true;
   $http.post(url_domain+'/api/add/subscribe', postdata).then(function(response){
   $scope.processing = false;
   alert(response.result.status);
});
  }


        $scope.addDomain = function(domain_name){
                postdata = {"domain-name": domain_name};
                $scope.processing = true;
                $http.post(url_domain+'/api/add-domain', postdata).then(function(response){
                        $scope.processing = false;
                alert(response.data.status);
        });
        }

}]);
app.controller('ListSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/get/subscribe').then(function(response){
    $scope.processing = false;
         $scope.subscribers = response.data.data;
 });

}]);
app.controller('GitController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/get_data/github').then(function(response){
    $scope.processing = false;
         $scope.contrib_repo = response.data.site24x7["contrib_repo"];
         $scope.org_repo = response.data.site24x7["org_repo"];
         //alert(response.data.site24x7["contrib_repo"]);
 });

}]);

app.controller('GDorksController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = true;
        var domain_id = $stateParams.domain_id;
        //alert(domain_id);
  $http.get(url_domain+'/get_data/dorks?id='+domain_id).then(function(response){
    $scope.processing = false;
         $scope.dorks = response.data
         //alert(response.data["count"]);
 });

}]);

app.controller('ZonetransferController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = true;
        var domain_id = $stateParams.domain_id;
        //alert(domain_id);
  $http.get(url_domain+'/get_data/zone_transfer?id='+domain_id).then(function(response){
    $scope.processing = false;
         $scope.zone = response.data
         //alert(response.data["count"]);
 });

}]);

app.controller('ListSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/get/subscribe').then(function(response){
    $scope.processing = false;
         $scope.subscribers = response.data.data;
 });

}]);

app.controller('LinuxAgentController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/get_data/repos').then(function(response){
    $scope.processing = false;
         $scope.semgrep_details = response.data["data"]["default"]
         $scope.Uniq_Vuln=response.data["uniq_vuln"].length
         $scope.Uniq_Vuln_details=response.data["uniq_vuln"]
          $scope.Total_Vuln=response.data["total_vuln"]
          $scope.Security_Update=response.data["security_update"]
 });

}]);
app.controller('BlacklistController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/agent?type=BlacklistedIP').then(function(response){
    $scope.processing = false;
         $scope.blist_ip = JSON.parse(response.data.blist)["res"];
         $scope.blist_date = JSON.parse(response.data.blist)["res"]["date"];
         delete $scope.blist_ip.date;
         //alert($scope.blist_date)
 });
$scope.expandedRows = {};

  $scope.toggleRow = function(ip) {
    $scope.expandedRows[ip] = !$scope.expandedRows[ip];
  };

}])

app.controller('domainController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
        var filename = $stateParams.filename;
   $scope.repo_name=filename.replace(/^(default_|custom_)/, "");
  $http.get(url_domain+'/get_data/semgrep?filename='+filename).then(function(response){
    $scope.processing = false;
         $scope.semgrep_data = response.data["data"];
         $scope.semgrep_date=response.data["date"];
         $scope.last_run=response.data["date"];
 });
/*
$scope.openModal = function(start, end) {

  // Display the loading message in the modal
  var modal = document.getElementById("myModal");
  var modalContent = document.getElementById("myModalContent");
  var modalLoading = document.getElementById("myModalLoading");
  var span = document.getElementsByClassName("close")[0];

  modal.style.display = "block";
  modalLoading.style.display = "block";
  modalContent.innerHTML = "";

  // Make a GET request to retrieve the data
  $http.get('http://10.22.9.89:8000/get_data?start=' + start + '&end=' + end)
    .then(function(response) {
      // Parse the JSON data from the response
      var jsonData = response.data;

      // Display the data in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<pre>" + JSON.stringify(jsonData, null, 2) + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    }, function(error) {
      console.log(error);
    });
};
*/
$scope.openModal = function(start, end,file) {

  // Display the loading message in the modal
  var modal = document.getElementById("myModal");
  var modalContent = document.getElementById("myModalContent");
  var modalLoading = document.getElementById("myModalLoading");
  var span = document.getElementsByClassName("close")[0];

  modal.style.display = "block";
  modalLoading.style.display = "block";
  modalContent.innerHTML = "";

  // Make a GET request to retrieve the data
  $http.get('http://10.51.49.72:8080/get_line?start=' + start + '&end=' + end + '&filename=' + file)
    .then(function(response) {
      // Parse the JSON data from the response
      var jsonData = response.data;

      // Display the data in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<b style='color: #070707;'>"+file+"</b> <br><br> <pre>" + jsonData + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    }, function(error) {
      // Display the error message in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<b style='color: #070707;'>"+file+"</b> <br><br> <pre>Error Occured: " + error.statusText + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    });
};

}])

app.controller('New_Custom_SemgrepController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
        //var filename = $stateParams.filename;
   //$scope.repo_name=filename.replace(/^(default_|custom_)/, "");
  $http.get(url_domain+'/get_data/semgrep?type=custom_semgrep').then(function(response){
    $scope.processing = false;
         $scope.custom_semgrep_data = response.data["data"];
         $scope.semgrep_date=response.data["date"];
 });

$scope.openModal = function(start, end,file) {

  // Display the loading message in the modal
  var modal = document.getElementById("myModal");
  var modalContent = document.getElementById("myModalContent");
  var modalLoading = document.getElementById("myModalLoading");
  var span = document.getElementsByClassName("close")[0];

  modal.style.display = "block";
  modalLoading.style.display = "block";
  modalContent.innerHTML = "";

  // Make a GET request to retrieve the data
  $http.get('http://10.51.49.72:8080/get_line?start=' + start + '&end=' + end + '&filename=' + file)
    .then(function(response) {
      // Parse the JSON data from the response
      var jsonData = response.data;

      // Display the data in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<pre>" + jsonData + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    }, function(error) {
      // Display the error message in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<pre>Error Occured: " + error.statusText + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    });
};
}])

//-----------------------------------------------------------------------------------------------------------------------
app.controller('CustomWebSecurityController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        $scope.processing = true;
        var date = $stateParams.date;
  $http.get(url_domain+'/get_security_xml/'+ date).then(function(response){
    $scope.processing = false;
 });

}]);

app.controller('WindowsPollerController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/agent?type=WindowsPoller').then(function(response){
    $scope.processing = false;
         $scope.windowspoller_cve = JSON.parse(response.data.cve)["data"];
         $scope.windowspoller_servlet=JSON.parse(response.data.servlet)["data"];
         $scope.winpoller_last_run=JSON.parse(response.data.cve)["data"][0][6]
         $scope.windowspoller_servlet_last_run=JSON.parse(response.data.servlet)["data"][0][1];
         //alert($scope.linux_servlet)
 });

}]);
