var app = angular.module('asm.app', ['ui.router', 'chart.js']);
var url_domain="http://10.51.49.72:8080"
app.config(['$stateProvider', '$urlRouterProvider','ChartJsProvider', function($stateProvider, $urlRouterProvider, ChartJsProvider){
        (function (ChartJsProvider) {
                ChartJsProvider.setOptions({ colors : [ '#803690', '#00ADF9', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'] });
        });

        $urlRouterProvider.when('', '/semgrep/list');//NO I18N
$stateProvider.state({
    name: 'custom_web_security',
    url: '/security/list/:date',
    templateUrl: 'templates/custom_web_security.html',
    controller: 'CustomWebSecurityController',
    resolve: {
      loadData: ['$http', '$stateParams', function($http, $stateParams) {
        var date = $stateParams.date;
        return $http.get(url_domain + '/get_security_xml/' + date);
      }]
    }
  });

  $urlRouterProvider.otherwise('/semgrep/list');

  var semgrep_rules = {
    name: 'semgrep_rules',
    url: '/semgrep/:filename',
    templateUrl: 'templates/semgrep_output.html',
    controller: "SemgrepResultController"
  }
 var web_security = {
    name: 'security',
    url: '/security/list',
    templateUrl: 'templates/web_security.html',
  }


 var semgrep = {
    name: 'semgrep',
    url: '/semgrep/list',
    templateUrl: 'templates/semgrep.html',
    controller: "SemgrepController"
  }
 var custom_semgrep = {
    name: 'custom_semgrep',
    url: '/custom_semgrep/list',
    templateUrl: 'templates/custom_semgrep.html',
    controller: "New_Custom_SemgrepController"
  }
  $stateProvider.state(semgrep_rules);
  $stateProvider.state(semgrep);
  $stateProvider.state(custom_semgrep);
  $stateProvider.state(web_security);
}]);

app.controller('AppController', ['$scope', '$stateParams', '$http', function($scope, $stateParams, $http) {
        $scope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];
         $scope.title = "Domains secured by Site24x7 SEMGREP Automation";

}]);

app.controller('SemgrepController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        $scope.processing = false;
  $http.get(url_domain+'/get_data/repos').then(function(response){
    $scope.processing = false;
         $scope.semgrep_details = response.data["data"]["default"]
         $scope.Uniq_Vuln=response.data["uniq_vuln"].length
         $scope.Uniq_Vuln_details=response.data["uniq_vuln"]
          $scope.Total_Vuln=response.data["total_vuln"]
          $scope.Security_Update=response.data["security_update"]
 });

}]);

app.controller('SemgrepResultController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        $scope.processing = false;
        var filename = $stateParams.filename;
   $scope.repo_name=filename.replace(/^(default_|custom_)/, "");
  $http.get(url_domain+'/get_data/semgrep?filename='+filename).then(function(response){
    $scope.processing = false;
         $scope.semgrep_data = response.data["data"];
         $scope.semgrep_date=response.data["date"];
         $scope.last_run=response.data["date"];
 });
$scope.openModal = function(start, end,file) {

  // Display the loading message in the modal
  var modal = document.getElementById("myModal");
  var modalContent = document.getElementById("myModalContent");
  var modalLoading = document.getElementById("myModalLoading");
  var span = document.getElementsByClassName("close")[0];

  modal.style.display = "block";
  modalLoading.style.display = "block";
  modalContent.innerHTML = "";

  // Make a GET request to retrieve the data
  $http.get('http://10.51.49.72:8080/get_line?start=' + start + '&end=' + end + '&filename=' + file)
    .then(function(response) {
      // Parse the JSON data from the response
      var jsonData = response.data;

      // Display the data in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<b style='color: #070707;'>"+file+"</b> <br><br> <pre>" + jsonData + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    }, function(error) {
      // Display the error message in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<b style='color: #070707;'>"+file+"</b> <br><br> <pre>Error Occured: " + error.statusText + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    });
};

}])

app.controller('New_Custom_SemgrepController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        $scope.processing = false;
        //var filename = $stateParams.filename;
   //$scope.repo_name=filename.replace(/^(default_|custom_)/, "");
  $http.get(url_domain+'/get_data/semgrep?type=custom_semgrep').then(function(response){
    $scope.processing = false;
         $scope.custom_semgrep_data = response.data["data"];
         $scope.semgrep_date=response.data["date"];
 });

$scope.openModal = function(start, end,file) {

  // Display the loading message in the modal
  var modal = document.getElementById("myModal");
  var modalContent = document.getElementById("myModalContent");
  var modalLoading = document.getElementById("myModalLoading");
  var span = document.getElementsByClassName("close")[0];

  modal.style.display = "block";
  modalLoading.style.display = "block";
  modalContent.innerHTML = "";

  // Make a GET request to retrieve the data
  $http.get('http://10.51.49.72:8080/get_line?start=' + start + '&end=' + end + '&filename=' + file)
    .then(function(response) {
      // Parse the JSON data from the response
      var jsonData = response.data;

      // Display the data in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<b style='color: #070707;'>"+file+"</b> <br><br><pre>" + jsonData + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    }, function(error) {
      // Display the error message in the modal
      modalLoading.style.display = "none";
      modalContent.innerHTML = "<b style='color: #070707;'>"+file+"</b> <br><br><pre>Error Occured: " + error.statusText + "</pre>";

      span.onclick = function() {
        modal.style.display = "none";
      };

      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      };
    });
};
}])

//-----------------------------------------------------------------------------------------------------------------------
app.controller('CustomWebSecurityController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        $scope.processing = true;
        var date = $stateParams.date;
  $http.get(url_domain+'/get_security_xml/'+ date).then(function(response){
    $scope.processing = false;
 });

}]);

