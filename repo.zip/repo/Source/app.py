from ast import arg
import html
from crypt import methods
from importlib.metadata import requires
from logging import critical
from multiprocessing import connection
from pickletools import read_string1
import subprocess
import os
from distutils.log import debug
from turtle import delay
from flask import Flask,render_template,url_for,request,redirect
import sys
import os
import redis
from rq import Queue
from concurrent.futures import ThreadPoolExecutor
import time
import json
import re
import requests
import datetime
app=Flask(__name__,static_folder="SEMGREP", static_url_path="/SEMGREP")
r=redis.Redis()
q=Queue(connection=r)
tmp=""
url_domain="http://10.51.49.72:8080"
import simplejson as json
import re
from jsondiff import diff
import os
now = datetime.datetime.now()

def dynamic_page(date):
        last_run=date
        date_format = "%d-%m-%Y"
        output_text=""
        if datetime.datetime.strptime(date, date_format):
       	    file="/app/repo/security/"+last_run+"/new_security_changes.txt"
            output_text=""
            if (os.path.exists(file)):
                with open(file, 'r') as f:
                    output_text = f.read()
                    output_text = html.escape(output_text)
                    output_text=output_text.strip()
                if(output_text=="" or output_text=="\n"):
                    output_text="No security configurations have been found for the given date"
        else:
            output_text="Invalid date format / Data is not found for the given date."
        html1 = """
	<nav class="navbar navbar-expand navbar-dark bg-white topbar mb-4 static-top shadow">

		<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
			<i class="fa fa-bars"></i>
		</button>
		<div>
			<h1 class="h3 mb-0 text-gray-800">Daily Updated Security Configurations</h1>
			<span class="">The report is generated on {last_run}</span>
		</div>
	</nav>
	<style>
		table {{
		  border-collapse: collapse;
		}}
		tr {{
		  padding: 8px;
		}}
		.highlight:hover {{
		  cursor: pointer;
		}}
	  pre.prettyprint {{
	  background-color: #f5f5f5;
	  border: 1px solid #ccc;
	  font-size: 14px;
	  padding: 10px;
	  white-space: pre-wrap;
	}}

	pre.prettyprint code {{
	  font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
	}}
	</style>

	<div class="row">
			<div class="col-xl-12 col-lg-7">
			<div class="card shadow mb-4">
			<div class="card-header py-3">
			   <pre class="prettyprint">{output_text}</pre>
			   </div>
		   </div>
		</div>

	</div>
	""".format(last_run=last_run, output_text=output_text)
        with open('/app/repo/Source/SEMGREP/templates/custom_web_security.html', 'w') as f:
            f.write(html1)

def validate_json(file):
    with open(file, 'r') as f:
        json_obj = json.load(f)
        return json_obj
        json_data = f.read()
        fixed_json_data = ""
        prev_char = ""
        for i, char in enumerate(json_data):
            if prev_char == '"' and char in [']', '}']:
                fixed_json_data += ','
            fixed_json_data += char
            prev_char = char
        fixed_json_data = re.sub(r'([{\[,])(\s*)([a-zA-Z0-9_]+)(\s*):', r'\1\2"\3"\4:', fixed_json_data)
        fixed_json = json.loads(fixed_json_data)
        return fixed_json
def remove_non_json_keys(obj):
    if isinstance(obj, dict):
        return {k: remove_non_json_keys(v) for k, v in obj.items() if isinstance(k, (str, int, float, bool, type(None)))}
    elif isinstance(obj, list):
        return [remove_non_json_keys(i) for i in obj]
    else:
        return obj


@app.route('/')
def index():
    return render_template('SEMGREP/automation.html')

def print_lines_in_range(filename, start_line, end_line):
    with open(filename, 'r') as file:
        lines = file.readlines()
        start_index = start_line -1
        end_index = end_line if end_line is None else end_line - 1
        lines_in_range = lines[start_index:end_index+1]
        result = '\n'.join(lines_in_range).strip()
        result=html.escape(result)
        return f"<pre>{result}</pre>"

def validate_file_path(file):
    if(("../" in file) or ("/etc" in file) or ("/passwd" in file)):
        return False
    else:
        return True

@app.route('/get_line',methods=["GET","POST"])
def ReadLine():
    if request.method=="GET":
        args = request.args
        start_line=args.get("start")
        end_line=args.get("end")
        filename=args.get("filename")
        if(validate_file_path(filename) and os.path.exists("/app/repo/"+filename)):
            filename="/app/repo/"+filename
            return print_lines_in_range(filename, int(start_line), int(end_line))
        return "invalid file path"

@app.route('/get_security_xml/<section>',methods=["GET","POST"])
def Assets(section):
    if request.method=="GET":
            assert section == request.view_args['section']
            date=section
            dynamic_page(date)
    return {"status":"success"}
@app.route('/get_data/semgrep',methods=["GET","POST"])
def ReadSemgrepData():
    if request.method=="GET":
            args = request.args
            filename=args.get("filename")
            type=args.get("type")
            repo=""
            pathlist=[]
            if((filename=="" or filename==None) and type=="custom_semgrep"):
                repo="/app/repo/link.txt"
                f=open(repo,"r")
                f=f.readlines()
                for data in f:
                    ind=data.index("8000/")+5
                    repo_file=data[ind:].replace("\n","")
                    path="/app/repo/"+repo_file
                    if("Custom_Semgrep" in repo_file):
                        repo=repo_file.replace("/result.txt","")
                        ind=repo.rfind("/")+1
                        repo=repo[ind:]
                    else:
                        ind=repo_file.index("/")
                        repo=repo_file[:ind]
                    pathlist.append({path:repo})
            #----------------------------------------
            else:
                repo=filename
                pathlist.append({"/app/repo/Custom_Semgrep/rules/"+repo+"/"+repo+".txt":repo})
            data=[]
            for paths in pathlist:
                path=list(paths.keys())[0]
                print(path)
                with open(path, 'r') as f:
                    json_string = f.read()
                repo=list(paths.values())[0]
                result = json.loads(json_string)
                res={"data":result["vulnerabilities"]}
                for i in range(len(result["vulnerabilities"])):
                    file=result["vulnerabilities"][i]["location"]["file"]
                    print(file)
                    if("/app/repo/security.xml"==file or "/app/repo/webapps/WEB-INF/security.xml"==file):
                        continue
                    if("/app/repo/" in file):
                        file=file.replace("/app/repo/","")
                    start_line=result["vulnerabilities"][i]["location"]["start_line"]
                    end_line=result["vulnerabilities"][i]["location"]["end_line"]
                    severity=result["vulnerabilities"][i]["severity"]
                    message=result["vulnerabilities"][i]["message"]
                    api="-"
                    filename="/app/repo/"+file
                    line=print_lines_in_range(filename, int(start_line), int(start_line))
                    line=html.unescape(line)
                    if("<url" in line):
                        #print(line)
                        if("path=" in line):
                            ind=line.index("path=")+6
                            end=line[ind:].index('"')
                            r=line[ind:end+ind]
                            api=r
                    data.append({"file":file,"start_line":start_line,"end_line":end_line,"severity":severity,"message":message,"repo_name":repo,"api":api})

            #res=json.dumps(res)
            data = [dict(t) for t in {tuple(d.items()) for d in data}]
            data = sorted(data, key=lambda x: x['repo_name'])
            return {"data":data,"date":now.strftime('%d-%m-%Y')}

@app.route('/get_data/repos',methods=["GET","POST"])
def ReadRepo():
    if request.method=="GET":
        args = request.args
        type=args.get("type")
        path=""
        security_update=0
        '''
        date= now.strftime('%d-%m-%Y')
        f="/app/repo/security/"+date+"/new_security_changes.txt"
        f=open(f,"r")
        f=f.readlines()
        for k in range(len(f)):
            if("File " in f[k]):
                    if(f[k+1]!="" and f[k+1]!="\n" and f[k+1]!=" "):
                        security_update+=1'''
        if(type=="default_custom"):
            path="/app/repo/link.txt"
        if(type=="custom_semgrep"):
            path="/app/repo/link.txt"
        else:
            path="/app/repo/all_link.txt"
        uniq_vuln=[]
        total_vuln=0
        f=open(path,"r")
        f=f.readlines()
        repos=[]
        res={"custom":[],"default":[]}
        vuln=[]
        r=0
        tmp_data={}
        for data in f:
            ind=data.index("8000/")+5
            repo_file=data[ind:].replace("\n","")
            #print(repo_file)
            path="/app/repo/Custom_Semgrep/rules/"+repo_file
            with open(path, 'r') as f:
                json_string = f.read()
            result = json.loads(json_string)
            lastrun=result["scan"]["start_time"]
            high=0
            low=0
            medium=0
            critical=0
            info=0
            repo=""
            flg=False
            if("Custom_Semgrep" in repo_file):
                repo=repo_file.replace("/result.txt","")
                ind=repo.rfind("/")+1
                repo=repo[ind:]
                flg=True
            else:
                ind=repo_file.index("/")
                repo=repo_file[:ind]
            for i in range(len(result["vulnerabilities"])):
                severity=result["vulnerabilities"][i]["severity"]
                message=result["vulnerabilities"][i]["message"]
                name=result["vulnerabilities"][i]["identifiers"][0]["name"]
                total_vuln+=1
                curr_flg=False
                if(name not in vuln ):
                    vuln.append(name)
                    r+=1
                    tmp_data[name]=0
                    uniq_vuln.append({"id":r,"message":name,"count":0})
                else:
                    tmp_data[name]+=1
                if(severity=="High"):
                    high+=1
                elif(severity=="Low"):
                    low+=1
                elif(severity=="Medium"):
                    medium+=1
                elif(severity=="Critical"):
                    critical+=1
                elif(severity=="Info"):
                    info+=1
            if(flg==True):
                res["custom"].append({"repo_name":repo,"filename":repo,"lastrun":lastrun,"vulnerabilities":{"high":high,"low":low,"medium":medium,"critical":critical,"info":info}})
            else:
                res["default"].append({"repo_name":repo,"filename":repo,"lastrun":lastrun,"vulnerabilities":{"high":high,"low":low,"medium":medium,"critical":critical,"info":info}})

        for ind in range(len(uniq_vuln)):
            uniq_vuln[ind]["count"]=tmp_data[uniq_vuln[ind]["message"]]
        return {"data":res,"uniq_vuln":uniq_vuln,"total_vuln":total_vuln,"security_update":security_update}

if __name__  == "__main__":
    app.run(debug=False)
