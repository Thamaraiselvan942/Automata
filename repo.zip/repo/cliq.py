import requests
import json
import sys
import os
from datetime import datetime
date_string = datetime.today().strftime('%d-%m-%Y')
ip=os.popen("ip addr show enp0s3 | grep -oP '(?<=inet\s)\d+(\.\d+){3}'").read().replace("\n","")

print("Generate Access Token...")
url = 'https://accounts.zoho.com/oauth/v2/token'
payload = {
    'refresh_token': '1000.2613be0b91f28b73d001f886d858282a.3b74a81549afb4506188d6111e8405d0',
    'grant_type': 'refresh_token',
    'client_id': '1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO',
    'client_secret': '11fcd919188f3c0cf494bc79fa8957c69326964800'
}
access_token=""

response = requests.post(url, data=payload)
access_token = response.json()['access_token']
print(access_token)

url = 'https://cliq.zoho.com/api/v2/channelsbyname/sitexredteameasm/message'
headers = {
    'Content-Type': 'application/json;charset=UTF-8',
    'Accept': 'application/json; version=2.0',
    'Authorization': f'Zoho-oauthtoken {access_token}'
}

dat="http://"+ip+":8080/SEMGREP/index.html#!/semgrep/list"+date_string+"\n"
'''
cus_dat=open("/app/repo/custom_link.txt","r")
cus_dat=cus_dat.readlines()
res=""

for i in cus_dat:
    if("result_xml" in i):
        res+=i
        ind=i.index("8000/")+5
        r=i[ind:]
        f="/app/repo/"+r.replace("\n","")
        tm=open(f,"r")
        tmp=tm.readlines()
        for j in tmp:
            if("[+]" in j):
                ind=j.index(" ")
                j=j[:ind]
                res=res+j
        res+="\n"
'''
f="/app/repo/security/"+date_string+"/new_security_changes.txt"
f=open(f,"r")
f=f.readlines()
final_flg=False
res=""
for k in range(len(f)):
    if("File " in f[k]):
        if(f[k+1]!="" and f[k+1]!="\n" and f[k+1]!=" "):
            print("k+1",f[k+1])
            final_flg=True
            if(res==""):
                res=f[k-2].replace("\n","")
            else:
                if(f[k-2].replace("\n","") not in res):
                    res=res+","+f[k-2].replace("\n","")
result=""
if("," in res):
    last_comma_index=res.rfind(",")
    result = res[:last_comma_index] + " & " + res[last_comma_index + 1:]
else:
    result=res
cont="Security configuration changes are discovered in "+result+". Please click on the link below to find the details,\n"+"http://"+ip+":8080/SEMGREP/index.html#!/security/list"
print(cont)
if(final_flg==True):
    f=open("/app/repo/custom_link.txt","a")
    f.write("http://"+ip+":8000/security/"+date_string+"/new_security_changes.txt\n")
    f.close()

if(res!=""):
    res=cont
else:
    res="Security configuration has not been updated yet.\n"

data={
    "text": dat+res,
    "card": {
        "color": "#e74c3c",
        "theme": "modern-inline",
        "title": "Semgrep Automation Result"
    }
}
response = requests.post(url, headers=headers, data=json.dumps(data))
print(response.text)
if response.status_code == 200:
    print("Message posted successfully.")
else:
    print(f"Error posting message: {response.content}")
