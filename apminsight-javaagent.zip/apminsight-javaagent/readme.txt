-------------------------------------------------------------
		APM Insight Java Agent
-------------------------------------------------------------

Monitor the performance of the application, track transaction,
response time, throughput & SQL slow queries using APM Insight Java Agent.

For overview use the link given below,

https://www.site24x7.com/help/getting-started/apm-insight.html

For fresh installation steps use the link given below,

https://www.site24x7.com/help/apm/java-agent/add-java-agent.html

For agent configuration help use the link given below,

https://www.site24x7.com/help/apm/apm-insight-configuration.html

For troubleshooting use the link given below,

https://support.site24x7.com/portal/helpcenter/site24x7/apm-insight/java-monitoring

-------------------------------------------------------------

Send an EMail to support@site24x7.com for any feedback, issues in installing agent.
