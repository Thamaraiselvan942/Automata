#!/usr/bin/python3
import subprocess
import requests
import json
import subprocess
import requests
import time
domain="http://52.140.3.229:8080/"
def BlacklistedIP():
        print("Downloading IP List")
        res = requests.get("https://creatorapp.zohopublic.com/site24x7/location-manager/json/IP_Address_View/C80EnP71mW2fDd60GaDgnPbVwMS8AGmP85vrN27EZ1CnCjPwnm0zPB5EX4Ct4q9n3rUnUgYwgwX0BW3KFtxnBqHt60Sz1Pgntgru")
        jsonListIPAddress = json.loads(res.text)
        print("Download and Parsing completed for the IP List")
        ipAddressList = []
        cidrList = []
        for ipDetails in jsonListIPAddress["IP_Address_View"]:
            externalIp = ipDetails["external_ip"]
            if "/" in externalIp:
                cidrList.append(externalIp)
            else:
                ipAddressList.append(externalIp)
        with open("cidr.txt", "w") as cidrFile:
            for cidr in cidrList:
                cidrFile.write(cidr + "\n")
        print("Running MapCidr")
        p1 = subprocess.run(['mapcidr', '-cl', 'cidr.txt', '-silent'], stdout=subprocess.PIPE)
        content = p1.stdout.decode("utf-8")
        if content is not None and content != "":
            lines = content.split("\n")
            for line in lines:
                ipAddressList.append(line)
        with open("hosts.txt", "w") as ipAddrFile:
            for ipAddress in ipAddressList:
                ipAddrFile.write(ipAddress + "\n")
        print("Running BlackList Checker");
        blackListedIPAddress = []
        ipAddressList.insert(0, '101.3.121.242')
        ipAddressList.insert(1, '46.38.236.202')
        ipAddressList.insert(2, "185.130.44.108")
        blackListedIPAddress={}
        for ipAddress in ipAddressList:
            print("Running for IP : ", ipAddress)
            blacklistedCount = 0;
            p1 = subprocess.run(['python3','isthisipbad.py','--ip', ipAddress], stdout=subprocess.PIPE)
            content = p1.stdout.decode("utf-8")
            lines = content.split("\n")
            ipAddress=ipAddress.replace("[","").replace("]","")
            blackListedIPAddress[ipAddress]=[]
            for line in lines:
                if "is listed in " in line:
                    st=line.index('in')+2
                    res=line[st:]
                    res=res.replace("&","$")
                    print(res)
                    blackListedIPAddress[ipAddress].append(res)

        print("Completed for All the IP Address")
        print("BlackListed IP Addresses = " + str(blackListedIPAddress));
        cwd=os.getcwd()
        f=open(cwd+"/output.txt", "w")
        f2=open(cwd+"output.json", "w")
        date=("="*90)+str(datetime.datetime.now())+("="*90)+"\n\n"
        f2.write(date+str(blackListedIPAddress)+"\n\n")
        f2.close()
        for key,val in blackListedIPAddress.items():
                print(key)
                f.write(str(key)+"\n")
                f.write(("="*len(key))+"\n")
                for res in val:
                        f.write(str(res)+"\n")
        f.close()
        return blackListedIPAddress



def StatusUpdate(api,data):
        r=requests.post(api,json=data)
        r=r.json()
        if(r["status"]=="updated"):
            print("removing the task id")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task finished")
        else:
            api=api.replace("Finished","Failed")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task failed")


while(True):
        blist_api=domain+"api/job/job_status_check?type=BlacklistIPScanning"
        r=requests.get(blist_api)
        r=r.json()
        blist_id=r["job_id"]
        print("blist_ID:",blist_id)
        blist_status=domain+"api/job/status_complete?type=BlacklistIPScanning&status=Finished&id="+blist_id
        blist_start=domain+"api/job/status_complete?type=BlacklistIPScanning&status=Started&id="+blist_id
        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=CVEScanning
        if(blist_id!=""):
            data=[]
            start=requests.get(blist_start)
            if("BlacklistIPScanning" in blist_id):
                for i in range(1,13):
                    data=BlacklistedIP()
                    data={"BlacklistedIP":data}
                    obj.StatusUpdate(blist_status,data,i)

        else:
            print("Task not assigned...")
        time.sleep(30)
