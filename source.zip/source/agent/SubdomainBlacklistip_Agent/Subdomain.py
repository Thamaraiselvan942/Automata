import os
import datetime
import requests
import time
import asyncio
def SubdomainFinder():
        print("SubdomainScanning Started...")
        date=os.popen('echo "`date +"%d-%m-%Y"`"').read()
        date=date.replace("\n","")
        pwd=os.getcwd()
        folders=os.popen("ls -d */").read()
        flist=folders.split("\n")
        dct={}
        for fold  in flist:
            if(date in fold ):
                domain=fold.split("-")[0]
                dct[domain]={}
                #print(domain)
                fold=pwd+"/"+domain+"-"+date
                #----------------------------
                newhost=fold+"/"+domain+"-new_hosts.txt"
                priviledge_host=fold+"/"+domain+"-auth_pages.txt"
                vulnerabilities=fold+"/"+domain+"_nuclei_results.txt"
                prehost=fold+"/"+domain+"-predomains.txt"
                dct[domain]["newhost"]=[]
                dct[domain]["priviledge_host"]=[]
                dct[domain]["vulnerabilities"]=[]
                dct[domain]["prehost"]=[]
                #print(dct)
                f1=open(newhost,"r")
                f2=open(priviledge_host,"r")
                f3=open(vulnerabilities,"r")
                f4=open(prehost,"r")
                f1=[i.replace("\n","") for i in f1.readlines()]
                f2=[i.replace("\n","") for i in f2.readlines()]
                f3=[i.replace("\n","") for i in f3.readlines()]
                f4=[i.replace("\n","") for i in f4.readlines()]
                if(f1!=[]):
                    dct[domain]["newhost"]=f1
                if(f2!=[]):
                    dct[domain]["priviledge_host"]=f2
                if(f3!=[]):
                    dct[domain]["vulnerabilities"]=f3
                if(f4!=[]):
                    dct[domain]["prehost"]=f4
        return dct
def StatusUpdate(api,data):
        r=requests.post(api,json=data)
        r=r.json()
        if(r["status"]=="updated"):
            print("removing the task id")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task finished")
        else:
            api=api.replace("Finished","Failed")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task failed")
def background(f):
    def wrapped(*args, **kwargs):
        return asyncio.get_event_loop().run_in_executor(None, f, *args, **kwargs)
    return wrapped

@background
def Start(argument):
    #time.sleep(1)
    print('function finished for '+str(argument)+"\n")
    os.system(argument)

def Run():
    fil="/home/site24x7/automation/sources/asm.sh"
    ls=["localzoho.com","localsite24x7.com","localmanageengine.com","site24x7.com","site24x7.com.au","site24x7.eu","site24x7.in","site24x7.jp","site24x7.net.au","downradar.net","site24x7rum.com","site24x7rum.com.au","site24x7rum.eu"]
    #ls=["localzoho.com","localsite24x7.com"]
    print("Running...")
    for i in ls:
        path=fil+" "+i
        Start(path)

while(True):
        #Subdomain Scanning Check Status
        #52.140.3.229:8080
        sdomain_api="http://52.140.3.229:8080/api/job/job_status_check?type=SubdomainScanning"
        r=requests.get(sdomain_api)
        r=r.json()
        sdomain_id=r["job_id"]
        print("Subdomain_ID:",sdomain_id)
        sdomain_status="http://52.140.3.229:8080/api/job/status_complete?type=SubdomainScanning&status=Finished&id="+sdomain_id
        sdomain_start="http://52.140.3.229:8080/api/job/status_complete?type=SubdomainScanning&status=Started&id="+sdomain_id
        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=CVEScanning
        if(sdomain_id!="" ):
            if("SubdomainScanning" in sdomain_id):
                resp=requests.get(sdomain_start)
                #st=Run()
                data=SubdomainFinder()
                data={"Subdomain":data}
                StatusUpdate(sdomain_status,data)

        else:
            print("Task not assigned...")
        time.sleep(30)

#data=SubdomainFinder()
#data={"Subdomain":data}
#sdomain_status="http://52.140.3.229:8080/api/job/status_complete?type=SubdomainScanning&status=Finished&id=SubdomainScanning1663881240874"
#StatusUpdate(sdomain_status,data)
#print(data)
