import os

import datetime

import time

import json

import subprocess

import requests

import csv
from threading import Timer

#http://172.24.224.154:8080/api/job/vulnerability_scan?type=SubdomainScanning
domain="http://172.24.240.220:8080/"
class AutomationScan():

    def Proxify(self,cmd):

        print("Starting Executing Proxify...") 

        apilist=[]

        kill = lambda process: process.kill()

        p = subprocess.Popen(

            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        my_timer = Timer(300, kill, [p])

        try:

            my_timer.start()

            stdout, stderr = p.communicate()

            res=stdout.decode('ISO-8859-1').split("\n")

            for data in res:

                if("GET" in data or "POST" in data):

                    data=data.replace("\n","").replace("\r","").replace("HTTP/1.1","")

                    if("{" in data):

                        ind=data.index("{")

                        data=data[:ind]

                    if(len(data)<10000):

                        print(data)

                        apilist.append(str(data))



        finally:

            my_timer.cancel()

        apilist=list(set(apilist))

        return apilist



    
    def StartServlet(self):

        #poller 8081 agent 7777

        proxy = [['proxify', '-ha','127.0.0.1:8081','-v']]  #,['proxify', '-ha','127.0.0.1:7777','-v']

        dct={}

        for cmd in proxy:

            typ="WIN_POLLER_SERVLETS"

            res=self.Proxify(cmd)

            dct[typ]=res

        return dct



    def StatusUpdate(self,api,data,num):

        r=requests.post(api,json=data)

        r=r.json()

        if(r["status"]=="updated"):
            if(num==12):
                print("removing the task id")

                r=requests.get(api)

                r=r.json()

                print("Task finished")
            else:
                print("Task updated evey 1hr:",r)
                
        else:

            api=api.replace("Finished","Failed")

            r=requests.get(api)

            r=r.json()

            print(r)

            print("Task failed")




while(True):

        servlet_api=domain+"hapi/job/job_status_check?type=Win_Poller_Servlet"

        r=requests.get(servlet_api)

        r=r.json()

        servlet_id=r["job_id"]

        print("Servlet_ID:",servlet_id)

        servlet_status=domain+"api/job/status_complete?type=Win_Poller_Servlet&status=Finished&id="+servlet_id

        servlet_start=domain+"api/job/status_complete?type=Win_Poller_Servlet&status=Started&id="+servlet_id

        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=ServletScanning

        if(servlet_id!=""):

            print("Start Checking latest Windows Poller...")
            #os.system("python Win_Agent.py")

            data=[]

            start=requests.get(servlet_start)

            obj=AutomationScan()

            if("Win_Poller_Servlet" in servlet_id):

                for i in range(1,13):

                    data=obj.StartServlet()

                    data={"Servlets":data}

                    os.system("IF not EXIST Servlet_logs.txt type nul>Servlet_logs.txt")

                    file=open("Servlet_logs.txt","a")

                    date=("="*90)+str(datetime.datetime.now())+("="*90)+"\n\n"

                    file.write(date+str(data)+"\n\n")
                    file.close()
                    obj.StatusUpdate(servlet_status,data,i)



        else:

            print("Task not assigned...")

        time.sleep(30)

'''
servlet_status="http://192.168.43.100:8080/api/job/status_complete?type=Win_Poller_Servlet&status=Finished&id=WIN_POLLER_SERVLETS1664114234593"
obj=AutomationScan()
data={'Servlets': {'WIN_POLLER_SERVLETS': ['GET /login/downloadRecorder.do?custID=us_0396d997f639e308f6c67c2f1c805263&agentUniqueID=95a90a18f38eca3662c72893f3ddbc69&platform=Microsoft+Windows+10+Pro&bitsize=64&jreversion=11.0.13&t=updateprobe&rbmpollerupgrade=true ', 'GET /poller/PollerStatusUpdater?agentUniqueID=95a90a18f38eca3662c72893f3ddbc69&custID=us_0396d997f639e308f6c67c2f1c805263 ', 'POST /poller/PollerFileCollector ', 'GET /network/TrapConfigReceiver ', 'GET /poller/PollerConfigReceiver?custID=us_0396d997f639e308f6c67c2f1c805263&agentUniqueID=95a90a18f38eca3662c72893f3ddbc69&category=4&monagentDNS=thamarai-pt5438&IpAddress=192.168.54.2&agentdetails=OS+Details+%3A+Microsoft+Windows+10+Pro+10.0.19044+%3Cbr%3ENo+of+Processors+%3A+4+%3Cbr%3EProcessor+Details+%3A+Intel64+Family+6+Model+140+Stepping+1%2C+GenuineIntel%2C+AMD64%2C+System+Type+%3A+64-bit+OS&agentVersion=5.2.4&agentOSFlavour=Windows+10&jreversion=11.0.13&bno=524&requestType=POLLER_START ', '', 'POST /poller/PollerImmediateReportCollector ', 'POST /poller/PollerFailedReportCollector ', 'GET /register?prd=SI&zuid=95a90a18f38eca3662c72893f3ddbc69&key=us_0396d997f639e308f6c67c2f1c805263_category_4&config=16 ', 'GET /network/NetworkConfigSender?custID=us_0396d997f639e308f6c67c2f1c805263&agentUniqueID=95a90a18f38eca3662c72893f3ddbc69&&type=s247_id_updater%2CGLOBAL_CONFIG%2Cvoip_dc_config%2Cserver_categories%2Cdynamic_network_update ', 'GET /ncm/getNCMConfig?user_id=us_0396d997f639e308f6c67c2f1c805263&poller_id=95a90a18f38eca3662c72893f3ddbc69&category=4 ', 'POST /poller/PollerPluginsUpdater ', 'POST /network/NetworkMessageReceiver ', 'POST /poller/DataAgentHandlerServlet ', 'GET /netflow/getNetflowConfig?user_id=us_0396d997f639e308f6c67c2f1c805263&poller_id=95a90a18f38eca3662c72893f3ddbc69&category=4 ', 'POST /network/ServerDataReceiver ']}}
obj.StatusUpdate(servlet_status,data,1)
'''



