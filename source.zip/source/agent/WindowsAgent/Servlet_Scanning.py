import os

import datetime

import time

import json

import subprocess

import requests

from threading import Timer

#http://172.24.224.154:8080/api/job/vulnerability_scan?type=SubdomainScanning
domain="http://172.24.240.220:8080/"
class AutomationScan():

    def Proxify(self,cmd):

        print("Starting Executing Proxify...") 

        apilist=[]

        kill = lambda process: process.kill()

        p = subprocess.Popen(

            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        my_timer = Timer(300, kill, [p])

        try:

            my_timer.start()

            stdout, stderr = p.communicate()

            res=stdout.decode('ISO-8859-1').split("\n")

            for data in res:

                if("GET" in data or "POST" in data):

                    data=data.replace("\n","").replace("\r","").replace("HTTP/1.1","")

                    if("{" in data):

                        ind=data.index("{")

                        data=data[:ind]

                    if(len(data)<10000):

                        print(data)

                        apilist.append(str(data))



        finally:

            my_timer.cancel()

        apilist=list(set(apilist))

        return apilist



   

    
    
    def StartServlet(self):

        #poller 8081 agent 7777

        proxy = [['proxify', '-ha','127.0.0.1:8082','-v']]  #,['proxify', '-ha','127.0.0.1:7777','-v']

        dct={}

        for cmd in proxy:

            typ="WIN_AGENT_SERVLETS"

            res=self.Proxify(cmd)

            dct[typ]=res

        return dct



    def StatusUpdate(self,api,data,num):

        r=requests.post(api,json=data)

        r=r.json()

        if(r["status"]=="updated"):
            if(num==12):
                print("removing the task id")

                r=requests.get(api)

                r=r.json()


                print("Task finished")
            else:
                print("Task update every 1 hour:",r)
                
        else:

            api=api.replace("Finished","Failed")

            r=requests.get(api)

            r=r.json()

            print(r)

            print("Task failed")




while(True):

        servlet_api=domain+"api/job/job_status_check?type=Win_Agent_Servlet"

        r=requests.get(servlet_api)

        r=r.json()

        servlet_id=r["job_id"]

        print("SERVLET_ID:",servlet_id)

        servlet_status=domain+"api/job/status_complete?type=Win_Agent_Servlet&status=Finished&id="+servlet_id

        servlet_start=domain+"api/job/status_complete?type=Win_Agent_Servlet&status=Started&id="+servlet_id

        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=CVEScanning

        if(servlet_id!=""):

            print("Start Checking latest Windows server agent...")
            os.system("python Win_Agent.py")

            data=[]

            start=requests.get(servlet_start)

            obj=AutomationScan()

            if("Win_Agent_Servlet" in servlet_id):

                for i in range(1,13):

                    data=obj.StartServlet()

                    data={"Servlets":data}

                    os.system("IF not EXIST servlet_logs.txt type nul>servlet_logs.txt")

                    file=open("servlet_logs.txt","a")

                    date=("="*90)+str(datetime.datetime.now())+("="*90)+"\n\n"

                    file.write(date+str(data)+"\n\n")
                    file.close()
                    obj.StatusUpdate(servlet_status,data,i)



        else:

            print("Task not assigned...")

        time.sleep(30)
'''
servlet_status="http://192.168.43.100:8080/api/job/status_complete?type=Win_Agent_Servlet&status=Finished&id=WIN_AGENT_SERVLETS1664114234593"
obj=AutomationScan()
data={'Servlets': {'WIN_AGENT_SERVLETS': ['POST /plus/RegisterAgent?custID=us_0396d997f639e308f6c67c2f1c805263&monagentID=thamarai-pt5438&monagentKey=SITE24X7&IpAddress=192.168.43.117&osName=Windows%208&agentUniqueID=1663078900&category=Workstation&monagentDNS=thamarai-pt5438.csez.zohocorpin.com&updateStatus=No&agentVersion=9.0.9&productVersion=20.3.0&isMasterAgent=NO&MACAddress=0a:00:27:00:00:07,0a:00:27:00:00:0e,0a:00:27:00:00:18,ac:74:b1:06:4f:8c,ac:74:b1:06:4f:8d,ae:74:b1:06:4f:8c&installer=STANDALONE&freeServiceFormat=json&bno=2030&bootTime=114086&upTime=465326&uuid=4C4C4544-0036-3210-804A-B3C04F394B33&DomainName=csez.zohocorpin.com&auid=1664114374&auid_old=1664106742&OsArch=64&settings=%7B%20%22res_check%22:%20%221%22,%20%22apps_dis%22:%20%221%22,%20%22ser_dis%22:%20%221%22,%20%22dc%22:%20%221%22,%20%22heartbeat%22:%20%221%22,%20%22mgmt%22:%20%221%22,%20%22it_aut%22:%20%220%22,%20%22plugins%22:%20%221%22%20%7D&timeStamp=1664114344097 ', 'POST /plus/cdiscover/ChildDiscoveryServlet?action=RA_DPS&agentKey=SITE24X7&custID=us_0396d997f639e308f6c67c2f1c805263&bno=2030 ', 'POST /plus/CheckSumValidator?action=validate_checksum&agentKey=SITE24X7&CUSTOMERID=us_0396d997f639e308f6c67c2f1c805263&bno=2030&osArch=64 ']}}
obj.StatusUpdate(servlet_status,data)


'''
