import os

import time

from bs4 import BeautifulSoup

import requests

import re

def Mail_automation(mail,version):

    url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.40cbb30c154d8c7b89fa24e00ff7a751.a59cb05cfb2550c91197de0051e6a59a&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=https://zylkerapps.com/oauth2callback&scope=ZohoMail.messages.ALL"

    r=requests.post(url)

    data = r.json()

    access_token='Zoho-oauthtoken '

    access_token+=data['access_token']

    default_mail="thamaraiselvan.pc@zohocorp.com,"+mail

    #print(storeName,attachmentPath,attachmentName)

    url2="https://mail.zoho.com/api/accounts/6508471000000008002/messages"

    payload = {"fromAddress": "thamaraiselvan.pc@zohocorp.com","toAddress": default_mail,"subject": "Windows Agent Automation ","content": "New Windows Monitoring Agent is Released Version:"+version}

    headers = {'Content-Type': 'application/json','Authorization':access_token}

    res = requests.post(url2, json=payload, headers=headers)

    data=res.json()

    print(data)

    time.sleep(10)



url = "https://www.site24x7.com/help/server-agent-release-notes.html"

req = requests.get(url)

soup = BeautifulSoup(req.text, "html.parser")

c=0

for link in soup.find_all('ul')[:3]:

    if(c==1):

        win=link

    if(c==2):

        lin=link

    c+=1



#check existing version list to newly added latest version agent

os.system("IF not EXIST win_version.txt type nul>win_version.txt")


winf=open("win_version.txt","r")

curr_winlis=[]

curr_linlis=[]

for i in winf.read().split("\n"):

    ver=i.replace("\n","")

    if(ver!=""):

        curr_winlis.append(ver)




#---------------------------------

winf=open("win_version.txt","w")

#print("Windows Agent version")

new_winlis=[]

new_linlis=[]

#print(curr_winlis)

for ver in list(win):

    ver=str(ver)

    if("-" in ver):

        sind=ver.rfind('"')+2

        eind=ver.rfind("-")-1

        ver=ver[sind:eind]

        winf.write(ver+"\n")

        #check newlist with current list

        if(ver not in curr_winlis):

            new_winlis.append(ver)






#Check the current version of the agent

#version=os.popen("sudo cat /opt/site24x7/monagent/version.txt | egrep -o '([0-9]{1,}\.)+[0-9]{1,}'").read().replace("\n","")

'''
if("." in version):

    print("Current Version:",version)

else:

    print("Currently there is no monitor found in your system...")

    version=""


'''

version=""
#----------------------------------------

if(len(new_linlis)>0):

    Mail_automation("arjunvijayece2018@gmail.com",new_linlis[0])

    print("New Windows Version:",new_linlis[0])

    cwd=os.getcwd()
    if(version!=""):

        print("uninstalling current version...")

        un=os.system("msiexec.exe /uninstall "+cwd+"Site24x7WindowsAgent.msi EDITA1=us_0396d997f639e308f6c67c2f1c805263 ENABLEPROXY=yes ProxyServerName=127.0.0.1:8082 ProxyUserName=\"test\" ProxyPassword="" /qn")

    os.system("curl https://staticdownloads.site24x7.com/server/Site24x7WindowsAgent.msi -o Site24x7WindowsAgent.msi")
    cmd="msiexec.exe /i "+cwd+"Site24x7WindowsAgent.msi EDITA1=us_0396d997f639e308f6c67c2f1c805263 ENABLEPROXY=yes ProxyServerName=127.0.0.1:8082 ProxyUserName=\"test\" ProxyPassword="" /qn"

    os.system(cmd)

    os.system("IF EXIST  Site24x7WindowsAgent.msi del  Site24x7WindowsAgent.msi")
    '''

    print("check Status...")

    status=os.popen("yes Y | sudo /etc/init.d/site24x7monagent status").read()

    if("up" in status):

        print("up")

    else:

        os.system("yes Y |sudo /etc/init.d/site24x7monagent start") 

        status=os.popen("yes Y | sudo /etc/init.d/site24x7monagent status").read()

        print(status)

    #create custom plugin and move into /opt/site24x7/monagent/plugins

    os.system("sudo cp -r test /opt/site24x7/monagent/plugins")
'''
    time.sleep(10)





