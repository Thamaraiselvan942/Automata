import os

import datetime

import time

import json

import subprocess

import requests

from threading import Timer

#http://172.24.224.154:8080/api/job/vulnerability_scan?type=SubdomainScanning
domain="http://172.24.240.220:8080/"
class AutomationScan():

    def PortScan(self):

        print("Starting Nmap Scanning...")

        portlist=[]

        port=subprocess.getoutput("nmap -p1-65000 127.0.0.1")

        port=port.split("\n")

        for i in port:

            if("/" in i and i.count("/")==1):

                ls=i.split()

                port=ls[0].split("/")

                port=port[0]

                portlist.append([port,ls[2]])

        return portlist
    def StatusUpdate(self,api,data):

        r=requests.post(api,json=data)

        r=r.json()

        if(r["status"]=="updated"):

            print("removing the task id")

            r=requests.get(api)

            r=r.json()

            print(r)

            print("Task finished")

        else:

            api=api.replace("Finished","Failed")

            r=requests.get(api)

            r=r.json()

            print(r)

            print("Task failed")




while(True):

        port_api=domain+"api/job/job_status_check?type=Win_Agent_Port"

        r=requests.get(port_api)

        r=r.json()

        port_id=r["job_id"]

        print("PORT_ID:",port_id)

        port_status=domain+"api/job/status_complete?type=Win_Agent_Port&status=Finished&id="+port_id

        port_start=domain+"api/job/status_complete?type=Win_Agent_Port&status=Started&id="+port_id

        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=CVEScanning

        if(servlet_id!=""):

            print("Start Checking latest Windows server agent...")
            #os.system("python Win_Agent.py")

            data=[]

            start=requests.get(servlet_start)

            obj=AutomationScan()

            if("Win_Agent_Port" in servlet_id):

                for i in range(12//3):

                    data=obj.PortScan()

                    data={"Port":data}

                    os.system("IF not EXIST port_logs.txt type nul>port_logs.txt")

                    file=open("port_logs.txt","a")

                    date=("="*90)+str(datetime.datetime.now())+("="*90)+"\n\n"

                    file.write(date+str(data)+"\n\n")
                    file.close()
                obj.StatusUpdate(port_status,data)



        else:

            print("Task not assigned...")

        time.sleep(30)
'''
servlet_status="http://192.168.43.100:8080/api/job/status_complete?type=Win_Agent_Servlet&status=Finished&id=WIN_AGENT_SERVLETS1664114234593"
obj=AutomationScan()
data={'Servlets': {'WIN_AGENT_SERVLETS': ['POST /plus/RegisterAgent?custID=us_0396d997f639e308f6c67c2f1c805263&monagentID=thamarai-pt5438&monagentKey=SITE24X7&IpAddress=192.168.43.117&osName=Windows%208&agentUniqueID=1663078900&category=Workstation&monagentDNS=thamarai-pt5438.csez.zohocorpin.com&updateStatus=No&agentVersion=9.0.9&productVersion=20.3.0&isMasterAgent=NO&MACAddress=0a:00:27:00:00:07,0a:00:27:00:00:0e,0a:00:27:00:00:18,ac:74:b1:06:4f:8c,ac:74:b1:06:4f:8d,ae:74:b1:06:4f:8c&installer=STANDALONE&freeServiceFormat=json&bno=2030&bootTime=114086&upTime=465326&uuid=4C4C4544-0036-3210-804A-B3C04F394B33&DomainName=csez.zohocorpin.com&auid=1664114374&auid_old=1664106742&OsArch=64&settings=%7B%20%22res_check%22:%20%221%22,%20%22apps_dis%22:%20%221%22,%20%22ser_dis%22:%20%221%22,%20%22dc%22:%20%221%22,%20%22heartbeat%22:%20%221%22,%20%22mgmt%22:%20%221%22,%20%22it_aut%22:%20%220%22,%20%22plugins%22:%20%221%22%20%7D&timeStamp=1664114344097 ', 'POST /plus/cdiscover/ChildDiscoveryServlet?action=RA_DPS&agentKey=SITE24X7&custID=us_0396d997f639e308f6c67c2f1c805263&bno=2030 ', 'POST /plus/CheckSumValidator?action=validate_checksum&agentKey=SITE24X7&CUSTOMERID=us_0396d997f639e308f6c67c2f1c805263&bno=2030&osArch=64 ']}}
obj.StatusUpdate(servlet_status,data)


'''
