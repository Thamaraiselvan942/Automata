import os
import time
from bs4 import BeautifulSoup
import requests
import re
import time
def Mail_automation(mail,version):
    url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.40cbb30c154d8c7b89fa24e00ff7a751.a59cb05cfb2550c91197de0051e6a59a&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=https://zylkerapps.com/oauth2callback&scope=ZohoMail.messages.ALL"
    r=requests.post(url)
    data = r.json()
    access_token='Zoho-oauthtoken '
    access_token+=data['access_token']
    default_mail="thamaraiselvan.pc@zohocorp.com,"+mail
    #print(storeName,attachmentPath,attachmentName)
    url2="https://mail.zoho.com/api/accounts/6508471000000008002/messages"
    payload = {"fromAddress": "thamaraiselvan.pc@zohocorp.com","toAddress": default_mail,"subject": "Linux Poller Automation ","content": "New Linux Poller is Released Version:"+version}
    headers = {'Content-Type': 'application/json','Authorization':access_token}
    res = requests.post(url2, json=payload, headers=headers)
    data=res.json()
    print(data)
    time.sleep(10)

url = "https://www.site24x7.com/help/on-premise-poller-release-notes.html"
req = requests.get(url)
soup = BeautifulSoup(req.text, "html.parser")
c=0
version=soup.find_all('p')[2]

#check existing version list to newly added latest version agent
os.system("test -f lin_version.txt || touch lin_version.txt")

linf=open("lin_version.txt","r")
curr_linlis=[]
for i in linf.read().split("\n"):
    ver=i.replace("\n","")
    if(ver!=""):
            curr_linlis.append(ver)

linf=open("lin_version.txt","w")
new_linlis=[]
#print("Linux Agent version")
for ver in list(version):
    ver=str(ver)
    if("-" in ver):
        sind=ver.rfind('"')+2
        eind=ver.rfind("-")-1
        ver=ver[sind:eind]
        if("<br/>" in ver):
            ver=ver.replace("<br/>","")
            if("\n" in ver):
                ver=ver.replace("\n","")
            if('' in ver):
                ver=ver.replace('',"")
        if(len(ver)>1):
            linf.write(ver+"\n")
            #check newlist with current list
            if(ver not in curr_linlis):
                new_linlis.append(ver)



#Check the current version of the agent
#version=os.popen("sudo cat /opt/site24x7/monagent/version.txt | egrep -o '([0-9]{1,}\.)+[0-9]{1,}'").read().replace("\n","")
version=""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if("." in version):
    print("Current Version:",version)
else:
    print("Currently there is no monitor found in your system...")
    version=""

if(len(new_linlis)>0):
    #Mail_automation("arjunvijayece2018@gmail.com",new_linlis[0])
    print("New Linux Version:",new_linlis[0])
    if(version!=""):
        print("uninstalling current version...")
    #os.system("yes Y | sudo wget https://staticdownloads.site24x7.com/probe/Site24x7OnPremisePoller_64bit.bin")
    chmod=os.system("yes Y | sudo chmod +x Site24x7OnPremisePoller_64bit.bin")
    cmd="printf 'y\ny\ny\ny\ny\ny\ny\ny\ny\nus_0396d997f639e308f6c67c2f1c805263\n/opt/Site24x7OnPremisePoller_64\nY\ny\ny\ny\n1\nlocalhost\n8082\ny\ny\n1\n' | sudo ./Site24x7OnPremisePoller_64bit.bin -i console"
    os.system(cmd)
    #os.system("yes Y | sudo chmod 755 Site24x7OnPremisePoller_64bit.bin")
    print("Poller Status..")
    status=os.popen(" yes Y | sudo sh /opt/Site24x7OnPremisePoller/Service.sh status").read()
    print(status)
    if("not" in status)::
        start=os.system("sudo sh /opt/Site24x7OnPremisePoller/StartServer.sh&")
        status=os.popen(" yes Y | sudo sh /opt/Site24x7OnPremisePoller/Service.sh status").read()
        print(status)
    else:
        print("up")
    time.sleep(10)




