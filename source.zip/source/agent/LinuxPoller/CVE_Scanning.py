import os
import datetime
import time
import json
import subprocess
import requests
import csv
from threading import Timer
#http://172.24.224.154:8080/api/job/vulnerability_scan?type=SubdomainScanning
domain="http://172.24.240.220:8080/"
class AutomationScan():
    def StartJAR(self):
        dct={}
        #SCAN VULNERABLE JAR USING DEPENDENCY CHECKER "E:\\Site24x7OnPremisePoller\\NetworkPlus\\lib"
        #"E:\\Site24x7OnPremisePoller\\lib\\jars",
        Path=["/opt/Site24x7OnPremisePoller_64/Site24x7OnPremisePoller/lib/jars","/opt/Site24x7OnPremisePoller_64/Site24x7OnPremisePoller/RealBrowser/jars"]
        for p in Path:
            List=[]
            #os.system("C:\\Users\\thamarai-pt5438\\Videos\\dependency-check-7.1.1-release\\dependency-check\\bin\\dependency-check.bat --out . --scan "+p+" -f CSV")
            cwd=os.getcwd()
            path="dependency-check/bin/dependency-check.sh"
            #os.system(path+"--out . --scan "+p+" -f CSV")
            with open(cwd+'/dependency-check/bin/dependency-check-report.csv',encoding='utf8') as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                line_count = 0
                for row in csv_reader:
                    if(line_count!=0):
                        #2-DependencyName,10-CVE,11-CWE,12-Vulnerability,14-CVSS_Severity,15-CVSS_Score
                        DependencyName=row[2]
                        CVE=row[10]
                        CWE=row[11]
                        Vulnerability=row[12]
                        CVSS_Severity=row[14]
                        CVSS_Score=row[15]
                        tmp=[DependencyName,CVE,CWE,CVSS_Severity,CVSS_Score]
                        #print(tmp)
                        List.append(tmp)
                    line_count += 1

            if("RealBrowser" in p):
                typ="RealBrowser"
                dct[typ]=List

            else:
                typ="POLLER"
                dct[typ]=List
            return dct

    def StatusUpdate(self,api,data):
        r=requests.post(api,json=data)
        r=r.json()
        if(r["status"]=="updated"):
            print("removing the task id")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task finished")

        else:
            api=api.replace("Finished","Failed")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task failed")




while(True):
        cve_api=domain+"api/job/job_status_check?type=Lin_Poller_Cve"
        r=requests.get(cve_api)
        r=r.json()
        cve_id=r["job_id"]
        print("CVE_ID:",cve_id)
        cve_status=domain+"api/job/status_complete?type=Lin_Poller_Cve&status=Finished&id="+cve_id
        cve_start=domain+"api/job/status_complete?type=Lin_Poller_Cve&status=Started&id="+cve_id
        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=CVEScanning
        if(cve_id!=""):
            print("Start Checking latest Linux Poller...")
            #os.system("python LinuxPoller.py")
            data=[]
            start=requests.get(cve_start)
            obj=AutomationScan()
            if("Lin_Poller_Cve" in cve_id):
                data=obj.StartJAR()
                data={"CVE":data}
                os.system("test -f Cve_logs.txt || touch Cve_logs.txt")
                file=open("Cve_logs.txt","a")
                date=("="*90)+str(datetime.datetime.now())+("="*90)+"\n\n"
                file.write(date+str(data)+"\n\n")
                file.close()
                obj.StatusUpdate(cve_status,data)

        else:
            print("Task not assigned...")
        time.sleep(30)
