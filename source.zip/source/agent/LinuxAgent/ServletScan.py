import os
import datetime
import time
import json
import subprocess
import requests
from threading import Timer
#http://172.24.224.154:8080/api/job/vulnerability_scan?type=SubdomainScanning
class AutomationScan():
    def Proxify(self,cmd):
        print("Starting Executing Proxify...") 
        apilist=[]
        kill = lambda process: process.kill()
        p = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        my_timer = Timer(60, kill, [p])
        try:
            my_timer.start()
            stdout, stderr = p.communicate()
            res=stdout.decode('ISO-8859-1').split("\n")
            for data in res:
                if("GET" in data or "POST" in data):
                    data=data.replace("\n","").replace("\r","").replace("HTTP/1.1","")
                    if("{" in data):
                        ind=data.index("{")
                        data=data[:ind]
                    if(len(data)<10000):
                        print(data)
                        apilist.append(str(data))

        finally:
            my_timer.cancel()
        apilist=list(set(apilist))
        return apilist

    def NMAP(self):
        print("Starting Nmap Scanning...")
        portlist=[]
        port=subprocess.getoutput("nmap -p1-65000 127.0.0.1")
        port=port.split("\n")
        for i in port:
            if("/" in i and i.count("/")==1):
                ls=i.split()
                port=ls[0].split("/")
                port=port[0]
                portlist.append([port,ls[2]])
        return portlist
    def StartServlet(self):
        #poller 8081 agent 7777
        proxy = [['proxify', '-ha','127.0.0.1:8081','-v']]  #,['proxify', '-ha','127.0.0.1:7777','-v']
        dct={}
        for cmd in proxy:
            typ="LIN_POLLER"
            if("127.0.0.1:8081" in cmd):
                typ="LIN_SERVER_MON_AGENT"
            res=self.Proxify(cmd)
            dct[typ]=res
        return dct

    def StatusUpdate(self,api,data):
        r=requests.post(api,json=data)
        r=r.json()
        if(r["status"]=="updated"):
            print("removing the task id")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task finished")
        else:
            api=api.replace("Finished","Failed")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task failed")


while(True):
        servlet_api="http://192.168.43.100:8080/api/job/job_status_check?type=ServletScanning"
        r=requests.get(servlet_api)
        r=r.json()
        servlet_id=r["job_id"]
        print("SERVLET_ID:",servlet_id)
        servlet_status="http://192.168.43.100:8080/api/job/status_complete?type=ServletScanning&status=Finished&id="+servlet_id
        servlet_start="http://192.168.43.100:8080/api/job/status_complete?type=ServletScanning&status=Started&id="+servlet_id
        #http://52.140.3.229:8080/api/job/vulnerability_scan?type=CVEScanning
        if(servlet_id!=""):
            print("Start Checking latest Linux server agent...")
            os.system("python3 LinuxAgent.py")
            data=[]
            start=requests.get(servlet_start)
            obj=AutomationScan()
            if("ServletScanning" in servlet_id):
                for i in range(12//4):
                    data=obj.StartServlet()
                    data={"Servlets":data}
                    os.system("test -f servlet_logs.txt || touch servlet_logs.txt")
                    file=open("servlet_logs.txt","a")
                    date=("="*90)+str(datetime.datetime.now())+("="*90)+"\n\n"
                    file.write(date+str(data)+"\n\n")
                obj.StatusUpdate(servlet_status,data)

        else:
            print("Task not assigned...")
        time.sleep(30)

