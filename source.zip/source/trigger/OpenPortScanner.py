import subprocess
import requests
import mysql.connector
import trigger.Generate_Access_Token as gen
import server.db.Database as db
import trigger.ConnectReports as con
class OpenPortScan():
    #CONSTANT PORT SERVICE NAME
    def __init__(self,port,jid,Type):
        self.cport={"162":"SNMP Trap Receiver","514": "Syslog Receiver","9996":"Netflow Listener","1514":"Firewall Log Receiver",
               "161":"SNMP","22":"SSH","23":"Telnet","8060":"Webserver","13306":"PostgreSQL Database","1433":"MSSQL Database","7275":"Remote Desktop",
               "135":"WMI","69":"TFTP Port [NCM]"
               }
        self.new_res=[]
        PortList=port
        self.type=Type
        self.count=0
        obj=db.Database()
        mydb=obj.CreateDatabase()
        res=obj.WriteDB(PortList,jid,None,mydb,self.cport,self.type)
        #self.new_res=res
        #self.UpdateConnect(self.new_res)
        self.count+=res
        obj=con.Report()
        obj.UpdateConnect(Type,self.count)

    #CONNECT DATABASE
    '''
    def Database(self):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Arjun@123",
        )
        mycursor = mydb.cursor()
        mycursor.execute("CREATE DATABASE IF NOT EXISTS APIINFO")
        mycursor.execute("USE APIINFO")
        mycursor.execute("CREATE TABLE IF NOT EXISTS OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),CONSTRAINT PK_PORT PRIMARY KEY (Job_Id,port))")
        return mydb
        '''
       
    #READ Data FROM TABLE
    def ReadDB(self,mydb):
            mycursor = mydb.cursor()
            sql = "SELECT port from OPENPORT" 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            r=set(res)
            rs=[]
            for i in list(r):
                res=list(i)[0]
                rs.append(res)
            return rs
        
    def ReadDBConnect(self,mydb):
            mycursor = mydb.cursor()
            sql = "SELECT * from OPENPORT" 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            return res

    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,new_res):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        lif="<li>"
        lil="</li>"
        ulf="<ul>"
        ull="</ul>"
        #title=bf+"DependencyName"+(" "*10)+"CVE"+(" "*10)+"CWE"+(" "*50)+"CVSS_Severity"+(" "*10)+"CVSS_Score"+(" "*10)+"Type"+bl
        title1=bf+"Total Openports "
        title2=bf+"New Openports "
        con=olf
        obj=db.Database()
        mydb=obj.CreateDatabase()
        r=obj.ReadDBConnect(mydb,self.type)
        c=0
        exist_count=len(r)
        curr_count=len(new_res)
        for i in list(r):
            c+=1
            if(c==400):
                break
            ls=list(i)
            port=ls[1]
            serv=ls[2]
            if(port  in new_res):
                con=con+lif+port+" - "+serv+lil
 
        con+=oll
        if(curr_count!=0):
            content=title1+ulf+lif+str(exist_count)+lil+ull+title2+bl+con
        else:
            content=title1+olf+lif+str(exist_count)+lil+oll+title2+bl+olf+lif+str(curr_count)+lil+oll
        url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Security Automation Results For Port Scanning" 
        print(content)
        res=requests.post(url,headers=headers)
        print(res.text)
        



    #INSERT INTO DATABASE
    def WriteDB(self,jid):
        port_key=self.cport.keys()
        mydb=self.Database()
        for ports in self.portlist:
            res=self.ReadDB(mydb)
            mycursor = mydb.cursor()
            sql = "INSERT INTO OPENPORT(Job_Id,Port, Service) VALUES (%s,%s, %s)"
            port=str(ports[0])
            if(port not in res):
                if(port in port_key):
                    val = (jid,port,self.cport[str(port)])
                elif((int(port)>=5000 and int(port)<=6000 )or (int(port)>=49152 and int(port)<=65535)):
                    val = (jid,port,"WMI")
                else:
                    val = (jid,port,ports[1])
                mycursor.execute(sql, val)
                mydb.commit()
                print(mycursor.rowcount, "record inserted.",port)
                self.new_res.append(port)
                
        #self.UpdateConnect(self.new_res)
        




                
