import schedule as sh
import requests
import time
import threading
def ApiCall(type):
    print("Scheduled Job is executed...")                                                                                                                                                                              
    sturl="http://52.140.3.229:8080/api/job/job_status_check"
    if(type=="NucleiAutomation"):
        url="http://52.140.3.229:8080/api/job/start?url=https://www.site24x7.com&type="+type 
    else:                                                                                                                                                       
        url="http://52.140.3.229:8080/api/job/vulnerability_scan?type="+type                                                                                                                                               
    status=requests.get(sturl)                                                                                                                                                                                         
    res=status.json()                                                                                                                                                                                                  
    job_ids=res["job_id"]                                                                                                                                                                                              
    if(len(job_ids)<1):                                                                                                                                                                                                        
        res=requests.get(url)                                                                                                                                                                                              
        print("Scheduled Job is executed...",res)                                                                                                                                                                  
        status=requests.get(sturl)                                                                                                                                                                                         
        res=status.json()                                                                                                                                                                                                  
        job_ids=res["job_id"]                                                                                                                                                                                              
        if(len(job_ids)<1):                                                                                                                                                                                                    
            res=requests.get(url)                                                                                                                                                                                              
            print("Scheduled Job is executed...",res)                                                                                                                                                                      
    else:                                                                                                                                                                                                                                                                                                                                                               
        res=requests.get(url)                                                                                                                                                                                              
        print("Scheduled Job is executed...",res)                                                                                                                                                                      
    return None 
   
def ScheduleJobs(type,day,time,hour,minute,everyday): 
    #/api/job/job_schedule?type=CVEScanning&minute=1  
    if(minute!=None and minute!="" and minute!="null"):
        sh.every(minute).minutes.do(ApiCall,type)
        
    #/api/job/job_schedule?hour=5&type=CVEScanning
    elif(hour!=None and hour!="" and hour!="null"):
        sh.every(hour).hour.do(ApiCall,type)
    #/api/job/job_schedule?everyday=&type=CVEScanning
    elif(everyday!=None and everyday!="" and everyday!="null" ):
        print("everyday",everyday)
        sh.every().day.at(everyday).do(ApiCall,type)
    

    #/api/job/job_schedule?day=monday&time=6:00&type=CVEScanning
    elif(None not in (time,day)):
        if(day=="monday"):
            sh.every().monday.at(time).do(ApiCall,type)
        elif(day=="tuesday"):
            sh.every().tuesday.at(time).do(ApiCall,type)
        elif(day=="wednesday"):
            sh.every().wednesday.at(time).do(ApiCall,type)
        elif(day=="thursday"):
            sh.every().thursday.at(time).do(ApiCall,type)
        elif(day=="friday"):
            sh.every().friday.at(time).do(ApiCall,type)
        elif(day=="saturday"):
            sh.every().saturday.at(time).do(ApiCall,type)
        elif(day=="sunday"):
            sh.every().sunday.at(time).do(ApiCall,type)
    
    #/api/job/job_schedule?day=monday
    elif(day!=None):
        if(day=="monday"):
            sh.every().monday.do(ApiCall,type)
        elif(day=="tuesday"):
            sh.every().tuesday.do(ApiCall,type)
        elif(day=="wednesday"):
            sh.every().wednesday.do(ApiCall,type)
        elif(day=="thursday"):
            sh.every().thursday.do(ApiCall,type)
        elif(day=="friday"):
            sh.every().friday.do(ApiCall,type)
        elif(day=="saturday"):
            sh.every().saturday.do(ApiCall,type)
        elif(day=="sunday"):
            sh.every().sunday.do(ApiCall,type)
    return None
    
   
def run_continuously(interval=1):
    cease_continuous_run = threading.Event()
    class ScheduleThread(threading.Thread):
        @classmethod
        def run(cls):
            while not cease_continuous_run.is_set():
                sh.run_pending()
                #print("test")
                time.sleep(interval)

    continuous_thread = ScheduleThread()
    continuous_thread.start()
    return cease_continuous_run

stop_run_continuously = run_continuously()
	

            


            

   
                      

            


            
