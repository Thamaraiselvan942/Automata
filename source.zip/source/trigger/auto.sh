#!/bin/bash

nuclei -update 
nuclei -ut

super_admin_access_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.FVKUIN8UJBBR71C0KC3ROQYTZRECEQ" \
        -d "client_secret=2a195e87fe563804b9261fb3b74d97e2f65564244d" \
        -d "refresh_token=1000.d21b6bbe2b27986f4aab941bbe3be34d.bc55b77fe54c6ce5d50c781adf2689e9"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')
echo "Executing Nuclei Automation for Super Admin..."
nuclei -u https://www.site24x7.in -var access_token=$super_admin_access_token -t ../templates/ -tags all -silent -p http://192.168.100.100:3128/ #> ~/Documents/output.txt


admin_access_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.3L1OOU8RZEPXRX9D5RHHXLY6DEQ0AH" \
        -d "client_secret=f55d1b2a6c05c41eafc59991d0fb2771dc1cf3158d" \
        -d "refresh_token=1000.f88631ec4d9e8fafe78430bdae2fa916.84cfebeb4ff91c63c2aac4a85ab6aa50"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')
echo "Executing Nuclei Automation for Admin..."
nuclei -u https://www.site24x7.in -var access_token=$admin_access_token -t ../templates/ -tags admin -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt


operator_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.SB3O36DLPJOH2SB1GLHYJQWR0NCT4S" \
        -d "client_secret=a70286f2a2cdf62d92fd5f353e76256771e582ca11" \
        -d "refresh_token=1000.635ca80ef86dfca4adef952046382462.25aa74198db86908c71f2a63db762b78"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')

echo "Executing Nuclei Automation for Operator..."
nuclei -u https://www.site24x7.in -var access_token=$operator_token -t ../templates/ -tags operator -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt


readonly_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.3UDLDAZD8716WFETHHYHWFZ9KO2OOZ" \
        -d "client_secret=c3582ca86d4f73d4b104812ed2d2b3231801b44604" \
        -d "refresh_token=1000.cc601ba574921ee58a14c39087221388.eff03c5582e77eeeea02c086c6083546"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')

echo "Executing Nuclei Automation for Readonly..."
nuclei -u https://www.site24x7.in -var access_token=$readonly_token -t ../templates/ -tags readonly -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt

billingcontact_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.0EUOP9TQIKM1E9MPKA2RN3L5MGQ87V" \
        -d "client_secret=3f977806c01f25e0824e620171d3a11711f614b6f6" \
        -d "refresh_token=1000.3e41a9159688fc74df3f45892898b901.614d9b5d63d1fdbea1300c473fe7a2c4"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')

echo "Executing Nuclei Automation for billing contact..."
nuclei -u https://www.site24x7.in -var access_token=$billingcontact_token -t ../templates/ -tags billingcontact -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt


spokesperson_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.O63P5CRM9GSOGCNUWF0FZLED8CJX1J" \
        -d "client_secret=b54416149e39ca8b72e2e73268e6edab855ff176f1" \
        -d "refresh_token=1000.1f4a4c520d70cf32ab1cbdbf1d7cbaaa.b4887b2d1857ce92b1abc233c159ba9f"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')
echo "Executing Nuclei Automation for SpokesPerson..."
nuclei -u https://www.site24x7.in -var access_token=$spokesperson_token -t ../templates/ -tags spokesperson -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt

hostingprovider_token=$(curl https://accounts.zoho.in/oauth/v2/token \
        -X POST \
        -d "client_id=1000.OPN7I4MXC22OI3RKV0KUW7A8XPLTOA" \
        -d "client_secret=b010e3e7dc6067173b152b5952a97b16a3e8b5c590" \
        -d "refresh_token=1000.5fe8b3ffbf74c10f4c274f92ebe6c4bb.8b8311f04b5f908d047062004b6ea9e7"\
        -d "grant_type=refresh_token" 2>/dev/null | jq -r '.access_token')
echo "Executing Nuclei Automation for Hostingprovider..."

nuclei -u https://www.site24x7.in -var access_token=$hostingprovider_token -t ../templates/ -tags hostingprovider -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt


echo "Executing Nuclei Automation for all the templates..."
nuclei -l urls.txt -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt


echo "Executing Nuclei Automation for all the location agent templates..."
nuclei -l location_agent_urls.txt -silent -p http://192.168.100.100:3128/ #>> ~/Documents/output.txt


