import requests
from requests.structures import CaseInsensitiveDict
import datetime
import time
from trigger.AutomationUI import Servlets
def Create_Reports(url,zdata,access_token,jid):
    #url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsPollerCVE"
    #url = "https://analyticsapi.zoho.com/api/site24x7-admin@services.zodoor.com/DailyActivities/SecurityIssueDetails"
    #console_url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.ef6c8100cbf8598c2a04093ad81e35fc.b829ca85234fadfc51daa091b8660bab&grant_type=refresh_token&client_id=1000.EWSII6LUAN9QPSWBG649ICPIKBVN5H&client_secret=30900f49cd0f57e8e37bd07dc4d779cb0ef3ae02d6&redirect_uri=analyticsapi.zoho.com"
    
    headers = CaseInsensitiveDict()
    headers["Authorization"] = "Zoho-oauthtoken "+access_token
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    #url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsPollerCVE"
    #url2 = "https://analyticsapi.zoho.com/api/site24x7-admin@services.zodoor.com/DailyActivities/Site24x7SecurityScore"
    resp = requests.post(url,headers=headers ,data=zdata)
    if resp.status_code == 401 or resp.status_code==400:
        print(resp.status_code)
        obj=Reports(jid)
        access_token=obj.access_token
        headers["Authorization"] = "Zoho-oauthtoken "+access_token
        resp = requests.post(url,headers=headers ,data=zdata)
        print(resp.text)
        
    else:
        print(resp.text)
    '''
    automation=sr.SecurityAtuomation()
    res=automation.getAndParseOutput(vulnerability)
    data = "ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=99&DATE="+self.Date+"&JOB_ID="+self.job_id+"&INFO="+str(info_count)+"&LOW="+str(res[3])+"&MEDIUM="+str(res[2])+"&HIGH="+str(res[1])+"&CRITICAL="+str(res[0])+"&SCORE="+str(res[4])+"&GRADE="+res[5]
    resp = requests.post(url2, headers=headers ,data=data)
    print(resp.text)
    '''


class Reports():
    def __init__(self,jid):
        year,month,date=str(datetime.date.today()).split("-")
        x = datetime.datetime(int(year),int(month),int(date))
        self.Date=x.strftime("%d %b %Y")
        self.job_id=jid
        console_url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.9da684246aa6ab606bbf6092b42fa42f.1f57fe17446b130919d3dcbc5bd49c4a&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=analyticsapi.zoho.com"
        r=requests.post(console_url)
        data = r.json()
        access_token=data["access_token"]
        self.access_token=access_token

    def LinPoller(self,type,data):
        servlets=data[0]
        if("Servlet" in type):
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/LinuxPollerServlets"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&SERVLETS="+servlets
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

        elif("Cve" in type):
            depend=data[0]
            cve=data[1]
            cwe=data[2]
            severity=data[3]
            score=data[4]
            type=data[5]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/LinuxPollerCVE"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&DEPENDENCY="+depend+"&CVE="+cve+"&CWE="+cwe+"&SEVERITY="+severity+"&SCORE="+score+"&TYPE="+type
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

        elif("Port" in type):
            ports=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/LinuxPollerPort"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&OPEN_PORT="+ports
            Create_Reports(url,data,self.access_token,self.job_id) 
            time.sleep(10)

    def WinPoller(self,type,data):
        
        if("Servlet" in type):
            servlets=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsPollerServlets"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&SERVLETS="+servlets
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

        elif("Cve" in type):
            depend=data[0]
            cve=data[1]
            cwe=data[2]
            severity=data[3]
            score=data[4]
            type=data[5]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsPollerCVE"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&DEPENDENCY="+depend+"&CVE="+cve+"&CWE="+cwe+"&SEVERITY="+severity+"&SCORE="+score+"&TYPE="+type
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

        elif("Port" in type):
            ports=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsPollerPort"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&OPEN_PORT="+ports
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

    def LinAgent(self,type,data):
        
        if("Servlet" in type):
            servlets=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/LinuxAgentServlet"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&SERVLETS="+servlets
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

        elif("Cve" in type):
            package=data[0]
            cur_ver=data[1]
            vuln_ver=data[2]
            cve=data[3]
            issue=data[4]
            
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/LinuxAgentCVE"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&PACKAGE="+package+"&CURR_VERSION="+cur_ver+"&VULN_VERSION="+vuln_ver+"&CVE="+cve
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

        elif("Port" in type):
            ports=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/LinuxAgentPort"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&OPEN_PORT="+ports
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)
    def WinAgent(self,type,data):
        
        if("Servlet" in type):
            servlets=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsAgentServlets"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&SERVLETS="+servlets
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)
        elif("Cve" in type):
            pass
        elif("Port" in type):
            ports=data[0]
            url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/WindowsAgentPort"
            data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&OPEN_PORT="+ports
            Create_Reports(url,data,self.access_token,self.job_id)
            time.sleep(10)

    def BlistIP(self,type,ip,blist):
        
        url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/BlacklistedIP"
        data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&IP="+ip+"&BLACKLISTER="+blist
        Create_Reports(url,data,self.access_token,self.job_id)
        time.sleep(10)
    def NucleiAutomation(self,type,issue,severity,urls):
        
        url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/NucleiAutomation"
        data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&ISSUE_TYPE="+issue+"&SEVERITY="+severity+"&URL="+urls
        Create_Reports(url,data,self.access_token,self.job_id)
        time.sleep(10)
    def Subdomain(self,type,data):
        domain=data[0]
        vuln=data[1]
        type=data[2]
        url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/Subdomain"
        data ="ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+self.Date+"&JOB_ID="+self.job_id+"&DOMAIN="+domain+"&VULNERABILITIES="+vuln+"&TYPES="+type
        Create_Reports(url,data,self.access_token,self.job_id)
        time.sleep(10)
    

