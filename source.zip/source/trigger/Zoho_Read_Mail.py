import trigger.Generate_accessToken as gen
import requests
import time
import trigger.Zoho_console_api as console
class Zoho_Mail:
   def __init__(self,s24x7_url,account_url,console_url):
      self.s24x7_url=s24x7_url
      self.account_url=account_url
      self.console_url=console_url
      self.client_id="1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO"
      self.client_secret="11fcd919188f3c0cf494bc79fa8957c69326964800"
      self.refresh_token="1000.40cbb30c154d8c7b89fa24e00ff7a751.a59cb05cfb2550c91197de0051e6a59a"
      self.access_token=gen.GetAdminaccess_token(self.client_id,self.client_secret,self.refresh_token)
      self.headers={"Authorization": "Zoho-oauthtoken "+self.access_token}
      self.headers_verify2 = {
       'Host': s24x7_url,
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
       'Referer': s24x7_url+'/login/success.jsp?urlpath=%2Fhome%2FacceptInvitation.do',
       'Content-Type': 'application/x-www-form-urlencoded'
       }
      self.verify_password={"confirmation":{"password":"Arjunvijay@123"}}
      self.verify_headers = {
                 "Content-Length": "46",
                 "Content-Type": "application/json",
                 "X-Http-Method-Override": "PUT",
                 "X-Requested-With": "XMLHttpRequest"
                }
      self.count=0
      
   
   def verify_superAdmin_mail(self,mail,resend_count):
      print("Verify Super Admin account.....")
      url_folder="http://mail.zoho.com/api/accounts/6508471000000008002/messages/view?folderId=6508471000000073001&start=1&limit=10"
      with requests.Session() as session:
         getFid=session.get(url_folder,headers=self.headers)
         json_data=getFid.json()
         #print(json_data)
         flag=False
         message_id=""

         if(self.count>6):
            print("resend the verify mail request....")
            time_mill=mail[mail.rfind("0")+1:mail.rfind("@")]
            self.count=0
            resend_count+=1
            console_api=console.ZohoConsole(self.s24x7_url,self.account_url,self.console_url)
            console_api.create_s247_account(time_mill,resend_count)

         self.count+=1
         if(resend_count>1):
            resend_count=0
            print("problem with sending mail...")
            return
         if(len(json_data['data'])!=0):
            for i in range(len(json_data['data'])):
               if(mail in json_data['data'][i]['toAddress'] ):
                  message_id=json_data['data'][i]['messageId']
                  flag=True
                  break
            if(flag==False):
               print("no confirmation mail found...")
               print("wait for 10sec...")
               time.sleep(10)
               return self.verify_superAdmin_mail(mail,resend_count)
               

            url_content="http://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073001/messages/"+message_id+"/content"
            getmsg=session.get(url_content,headers=self.headers)
            sind=getmsg.text.index("accounts")-8
            tmp=getmsg.text[sind::]
            eind=tmp.index("\\")
            agree_url=tmp[:eind]
            if("amp;" in agree_url):
               agree_url=agree_url.replace("amp;","")
            tmp=agree_url
            s=tmp.rfind("=")+1
            res=tmp[s::]
            verify_url= self.account_url+"/webclient/v1/confirmation/"
            verify_url+=res
            gets=session.get(agree_url)
            cookie=gets.headers['Set-Cookie']
            sind=cookie.index("iamcsr")+7
            csr=cookie[sind:]
            eind=csr.index(";")
            iamcsr=csr[:eind]
            self.verify_headers["Cookie"]="iamcsr="+iamcsr
            self.verify_headers["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
            self.verify_headers["Referer"]= self.account_url+"/confirm?DIGEST="+res
            post=session.post(verify_url,headers=self.verify_headers,json=self.verify_password)
            print(post.json()['localized_message'],"status........")
            time.sleep(3)
              
            #++++DELETE EMAIL++++++
            delete_url="https://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073001/messages/"+message_id
            delete_get=requests.delete(delete_url,headers=self.headers)
            time.sleep(3)
            if(post.json()['localized_message']=="Account verified"):
               return 
                  
         else:
            print("no confirmation mail found...")
            print("wait for 10sec...")
            time.sleep(10)
            return self.verify_superAdmin_mail(mail,resend_count)
           

   def verify_user_mail(self,user,mail,resend_count):
      tmp_cookies={}
      url_folder="http://mail.zoho.com/api/accounts/6508471000000008002/messages/view?folderId=6508471000000073012&start=1&limit=10"
      verify_user_info={"orguserinvitation":{"firstname":"test","lastname":"P","country":"IN","newsletter":"true","country_state":"Tamil Nadu","password":"Arjunvijay@123","account_type":"normal","tos":"true"}}
      message_id=""
      flag=False
      self.count+=1
      if(self.count>6):
         print("resend the invitation mail request....")
         time_mill=mail[mail.rfind("0")+1:mail.rfind("@")]
         self.count=0
         resend_count+=1
         console_api=console.ZohoConsole(self.s24x7_url,self.account_url,self.console_url)
         console_api.create_users(time_mill,resend_count)
      if(resend_count>1):
         resend_count=0
         print("problem with sending mail...")
         return
      with requests.Session() as session:
         getFid=session.get(url_folder,headers=self.headers)
         json_data=getFid.json()
         if(len(json_data['data'])!=0):
            for i in range(len(json_data['data'])):
               if(mail in json_data['data'][i]['toAddress'] ):
                  message_id=json_data['data'][i]['messageId']
                  flag=True
                  break
            if(flag==False):
                print("no invitation mail found...")
                print("wait for 10sec...")
                time.sleep(10)
                return self.verify_user_mail(user,mail,resend_count)
            

            url_content="http://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073012/messages/"+message_id+"/content"
            getmsg=session.get(url_content,headers=self.headers)
            sind=getmsg.text.index("accounts")-8
            tmp=getmsg.text[sind::]
            eind=tmp.index("\\")
            agree_url=tmp[:eind]
            if("amp;" in agree_url):
               agree_url=agree_url.replace("amp;","")
            tmp=agree_url
            print("verify url...")
            s=tmp.rfind("/")+1
            res=tmp[s::]
            #---------------------------------------------------
            verify_user= self.account_url+"/webclient/v1/orguserinvitation/"
            verify_user+=res
            print(verify_user)
            print("verify_user................")
            gets=session.get(agree_url)
            cookie=gets.headers['Set-Cookie']
            sind=cookie.index("iamcsr")+7
            csr=cookie[sind:]
            eind=csr.index(";")
            iamcsr=csr[:eind]
            self.verify_headers["Cookie"]="iamcsr="+iamcsr
            self.verify_headers["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
            self.verify_headers["Referer"]=self.account_url+"/invitation/org/user/"+res
            post=session.post(verify_user,headers=self.verify_headers,json=verify_user_info)
            time.sleep(3)
            
            print(post.json()['localized_message']+"for "+user+" role")
            #==============================================Verify accept and Allowed get request
            cookie=post.headers['Set-Cookie']
            sind=cookie.index("_iamadt")+8
            csr=cookie[sind:]
            eind=csr.index(";")
            iamadt=csr[:eind]
            cookie2=post.headers['Set-Cookie']
            sind=cookie.index("_iambdt")+8
            csr=cookie[sind:]
            eind=csr.index(";")
            iambdt=csr[:eind]
            tmp_cookies['_iamadt']=iamadt
            tmp_cookies['_iambdt']=iambdt
            response2 = requests.get(self.s24x7_url+'/home/acceptInvitation.do', cookies=tmp_cookies, headers=self.headers_verify2)
            #++++DELETE EMAIL++++++
            delete_url="https://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073012/messages/"+message_id
            delete_get=requests.delete(delete_url,headers=self.headers)
            time.sleep(3)
            if(post.json()['localized_message']=="Invitation accepted."):
               return 
            #print(delete_get.text);
         else:
            print("no invitation mail found...")
            print("wait for 10sec...")
            time.sleep(10)
            return self.verify_user_mail(user,mail,resend_count)



  
