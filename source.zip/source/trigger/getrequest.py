#importing the requests library
import requests
import json
from time import time
import time as tim
import trigger.Zoho_Read_Mail as mail
import trigger.Zoho_console_api as console
import ast
import trigger.Generate_accessToken as gen
import trigger.test as ts
import configparser
import trigger.mail_automation as auto
import argparse
import threading
import os
import junit_xml_output
cwd=os.getcwd()+"/trigger/"
def main(task_id,data,type="",plus_host="",mail="",ids=""):
        #try:
        print("started..")
        global cwd
        file=open(cwd+"nuclei_vulnerability.txt","r+")
        file.truncate(0)
        file2=open(cwd+"nuclei_info.txt","r+")
        file2.truncate(0)
        config = configparser.RawConfigParser()
        config.read(cwd+'config.ini')
        res=[]
        access_token=""
        tmp=config.sections()
        domain_list = [item for item in data.split(',')]
        domain_config_section = "us"
        for domain in domain_list:
            cur_s24x7_url = domain
            if "localsite24x7" in domain:
                domain_config_section = "local"
            elif "csez" in domain:
                domain_config_section = "csez"
            elif "eu" in domain:
                domain_config_section = "eu"
            elif "in" in domain:
                domain_config_section = "in"
            elif "au" in domain:
                domain_config_section = "au"
            elif "cn" in domain:
                domain_config_section = "cn"
            elif "jp" in domain:
                domain_config_section = "jp"

            print("creating user for "+domain_config_section+" region....")
            if("csez" not in domain and "localsite24x7" not in domain):
                plus_host=config.get(domain_config_section,'plus_host')
            cur_acc_url=config.get(domain_config_section,'accounts_url')
            cur_console_url=config.get(domain_config_section,'api_console_url')
            zoho_console=console.ZohoConsole(cur_s24x7_url,cur_acc_url,cur_console_url)
            zoho_console.create_s247_account()
            zoho_console.create_users()
            zoho_console.add_selfclient()
            users=zoho_console.users
            for curr_user in users:
                cid= curr_user. get_client_id()
                csecret=curr_user.get_client_secret()
                rtoken=curr_user.get_refresh_token()
                user=curr_user.get_user_role()
                email=curr_user.get_mail_id()
                access_token=gen.Getaccess_token(cid,csecret,rtoken,cur_acc_url)
                print("Nuclei Automation running for "+user+"......")
                print(plus_host)
                ts.Nuclei_Automation(type,task_id,access_token,cur_s24x7_url,[],user,cur_acc_url,email,plus_host,domain_config_section,ids)
        auto.Mail_automation(mail,task_id)
        '''except:
            print("error occured...")
            ts.Common_Nuclei_Automation(task_id,access_token,cur_s24x7_url)'''
   
  
    
    
    
    

