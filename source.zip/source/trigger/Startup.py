def main(ids):
    while(True):
        print(ids)
    
