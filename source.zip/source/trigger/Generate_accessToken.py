import requests
import json
from requests.structures import CaseInsensitiveDict
import configparser
import os
cwd=os.getcwd()+"/trigger/"
def Getaccess_token(clid,csecret,rtoken,account_url):
    jsonres={}
    url = account_url+"/oauth/v2/token?"
    print(clid,csecret,rtoken)
    data = "client_id="+clid+"&client_secret="+csecret+"&refresh_token="+rtoken+"&grant_type=refresh_token"
    resp = requests.post(url+data)
    jsonres=json.loads(resp.text)
    print(jsonres)
    res=jsonres['access_token']
    return res
def GetAdminaccess_token(clid,csecret,rtoken):
    url = "https://accounts.zoho.com/oauth/v2/token?"
    data = "client_id="+clid+"&client_secret="+csecret+"&refresh_token="+rtoken+"&grant_type=refresh_token"
    resp = requests.post(url+data)
    jsonres=json.loads(resp.text)
    print(jsonres)
    res=jsonres['access_token']
    return res



