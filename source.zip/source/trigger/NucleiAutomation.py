import subprocess
import requests
import mysql.connector
import trigger.Generate_Access_Token as gen
import server.db.Database as db
class NucleiAutomation():
    def __init__(self,result,jid,Type):
        self.curr_res=[]
        obj=db.Database()
        self.type=Type
        mydb=obj.CreateDatabase()
        res=obj.WriteDB(result,jid,None,mydb,None,self.type)
        self.UpdateConnect(res)
        
    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,curr_res):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        lif="<li>"
        lil="</li>"
        ulf="<ul>"
        ull="</ul>"
        con=olf
        title1=bf+"Nuclei Automation"+bl
        count=0
        content=""
        Refer="http://52.140.3.229:8080/show/automation/result?value=NUCLEI_AUTOMATION"
        for res in curr_res:
            r=res
            typ=r[0]
            severity=r[1]
            url=r[2]
            result=typ+" ["+severity+"] "+url
            con=con+lif+result+lil
            count+=1
        if(count!=0):
            content=title1+con+oll+bf+"Refer: "+Refer+bl
            url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Nuclei Automation Result" 
            #print(content)
            res=requests.post(url,headers=headers)
        
        

     

    
        



    
    
    
    




