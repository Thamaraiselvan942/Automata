#!/usr/bin/python3

import json
import subprocess

class SecurityAtuomation:
    def __init__(self) -> None:
        self.totalNumberOfTemplates = 0
        self.totalNumberOfPass = 0 
        self.totalNumberOfFailure = 0

        self.criticalSeverityChecksFailureCount = 0
        self.highSeverityChecksFailureCount = 0
        self.mediumSeverityChecksFailureCount = 0
        self.lowSeverityChecksFailureCount = 0


        self.numberOfHighSeverityChecks = 6
        self.numberOfMediumSeverityChecks = 2
        self.numberOfLowSeverityChecks = 3
        self.numberOfCriticalSeverityChecks = 1

        self.__criticalSeverityScore = 40
        self.__highSeverityScore = 30
        self.__mediumSeverityScore = 20
        self.__lowSeverityScore = 10

        self.outputFolder = "/home/site24x7/site24x7-output/"
    
    def printJson(self): 
        score = self.calculateScore()
        metric = {
            "high_issue" : self.highSeverityChecksFailureCount, 
            "medium_issue": self.mediumSeverityChecksFailureCount,
            "low_issue": self.lowSeverityChecksFailureCount, 
            "total_score": score,
            "grade": self.calculateGrade(score)
        }
        metricJson = json.dumps(metric)
        return metricJson
    
    def calculateGrade(self, score):
        grade = "A"
        if score > 95:
            grade = "A"
        elif 80 < score <= 95:
            grade = "B"
        elif 60 < score <= 80:
            grade = "C"
        elif 50 < score <= 60:
            grade = "D"
        elif 40 < score <= 50:
            grade = "E"
        else: 
            grade = "F"
        return grade

        
    def calculateScore(self):
        score = 0
        highScore =  self.__highSeverityScore - ((self.highSeverityChecksFailureCount * self.__highSeverityScore * 10)/self.numberOfHighSeverityChecks)
        if highScore > 0:
            score += highScore

        mediumScore = self.__mediumSeverityScore - ((self.mediumSeverityChecksFailureCount * self.__mediumSeverityScore * 5)/self.numberOfMediumSeverityChecks)
        if mediumScore > 0:
            score += mediumScore
            
        lowScore = self.__lowSeverityScore - ((self.lowSeverityChecksFailureCount * self.__lowSeverityScore)/self.numberOfLowSeverityChecks)
        if lowScore > 0:
            score += lowScore

        criticalScore = self.__criticalSeverityScore - ((self.criticalSeverityChecksFailureCount * self.__criticalSeverityScore)/self.numberOfCriticalSeverityChecks)
        if lowScore > 0:
            score += criticalScore
        
        return score
    
    def getAndParseOutput(self, content):
        #lines = content.split("\n")
        for line in content:
            if "high" in line:
                self.highSeverityChecksFailureCount += 1
            elif "medium" in line:
                self.mediumSeverityChecksFailureCount += 1
            elif "low" in line: 
                self.lowSeverityChecksFailureCount += 1
            elif "critical" in line:
                self.criticalSeverityChecksFailureCount += 1
        score=self.calculateScore()
        grade=self.calculateGrade(score)
        return [self.criticalSeverityChecksFailureCount,self.highSeverityChecksFailureCount,self.mediumSeverityChecksFailureCount,self.lowSeverityChecksFailureCount,score,grade]
        #print("high :" + str(self.highSeverityChecksFailureCount) + "\tmedium: "+ str(self.mediumSeverityChecksFailureCount) + "\tlow :" + str(self.lowSeverityChecksFailureCount))
        #print("*********************")
#### Site24x7 Domain #####
    def getOutput(self, workflowFileName, targetListFileName):
        p1 = subprocess.run(['/home/site24x7/nuclei', '-silent', '-w', workflowFileName, '-l', targetListFileName], stdout=subprocess.PIPE)
        content = p1.stdout.decode("utf-8")
        if content is not None and content != "":
            self.getAndParseOutput(content)
'''
#### Site24x7 Domain #####
    def getOutputForSite24x7Domain(self):
        self.numberOfHighSeverityChecks += (1 * 6)
        self.getOutput('/home/site24x7/site24x7-workflow/site24x7_domain_workflow.yaml', '/home/site24x7/site24x7-target/site24x7_domains.txt')

#### Site24x7 App #####
    def getOutputForSite24x7App(self):
        self.numberOfHighSeverityChecks += (2 * 6)
        self.getOutput('/home/site24x7/site24x7-workflow/site24x7_app_workflow.yaml', '/home/site24x7/site24x7-target/site24x7_domains.txt')

#### Location Agent ####
    def getOutputForLocationAgent(self):
        self.numberOfHighSeverityChecks += (3 * 483) 
        self.numberOfMediumSeverityChecks += (1 * 483)
        self.getOutput('/home/site24x7/site24x7-workflow/location_agent_workflow.yaml', '/home/site24x7/site24x7-target/location_agent_urls.txt')

def main():
    secAutomation = SecurityAtuomation()
    #print("starting automation")
    #print("*************************")
    #print("Running Site24x7 Domain")
    secAutomation.getOutputForSite24x7Domain()
    #print("Running Site24x7 App")
    secAutomation.getOutputForSite24x7App()
    #print("Running Site24x7 Location Agent")
    secAutomation.getOutputForLocationAgent()
    #print("*************************")
    #print("starting automation")
    #print("Calculating Security Score")
    #print("Site24x7 Security Score is " , str(secAutomation.calculateScore()))
    #print("Sitet24x7 Grade : ", str(secAutomation.calculateGrade(secAutomation.calculateScore())))
    secAutomation.calculateGrade(secAutomation.calculateScore())
    print(secAutomation.printJson())

if __name__ == "__main__":
    main()
'''
