import subprocess
import requests
import mysql.connector
import trigger.Generate_Access_Token as gen
import server.db.Database as db
import trigger.ConnectReports as con
class ServletScan():
    def __init__(self,result,jid,Type):
        self.curr_res=[]
        obj=db.Database()
        self.type=Type
        mydb=obj.CreateDatabase()
        self.count=0
        for key,val in result.items():
            tmp=[]
            for r in val:
                if("?" in r):
                    ind=r.index("?")
                    rs=r[:ind]
                    if(rs not in tmp):
                        #print(rs)
                        tmp.append(rs)
                        res=obj.WriteDB(val,jid,key,mydb,None,self.type)
                        #self.curr_res.extend(res)
                        self.count+=res
                else:
                    res=obj.WriteDB(val,jid,key,mydb,None,self.type)
                    self.count+=res
                    #self.curr_res.extend(res)
                    #print(r)
        obj=con.Report()
        obj.UpdateConnect(Type,self.count)        
        ''''
            for r in val:
                if("sct" in r):
                    s=r.index("sct=")+4
                    e=r[s:].index("&")
                    #print(s,s+e)
                    v=r[s:s+e]
                    #print(v)
                    r=r.replace(v,"")
                    #print(r)

                if("timeStamp" in r):
                    s=r.index("timeStamp=")+10
                    e=r[s:].index("&")
                    #print(s,s+e)
                    v=r[s:s+e]
                    #print(v)
                    r=r.replace(v,"")
                if("Application_" in r):
                    s=r.index("Application_")+12
                    e=r[s:].index(".")
                    #print(s,s+e)
                    v=r[s:s+e]
                    #print(v)
                    r=r.replace(v,"")

                
                if(r not in tmp):
                    tmp.append(r)
            '''
            
        #self.UpdateConnect(self.curr_res)
        
    #CREATE DATABASE
    '''
    def Database(self):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Arjun@123",
        )
        mycursor = mydb.cursor()
        mycursor.execute("CREATE DATABASE IF NOT EXISTS SERVLET_CALLS")
        mycursor.execute("USE SERVLET_CALLS")
        mycursor.execute("CREATE TABLE IF NOT EXISTS SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,Type VARCHAR(40),CONSTRAINT PK_SERVLETS PRIMARY KEY (Job_Id,Servlets(200)))")
        return mydb
     '''
    #READ Data FROM TABLE
    def ReadDB(self,mydb):
            mycursor = mydb.cursor()
            sql = "SELECT Servlets from SERVLETS" 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            r=set(res)
            rs=[]
            for i in list(r):
                res=list(i)[0]
                if("?" in res):
                    ind=res.index("?")
                    res=res[:ind]
                rs.append(res)
            return rs
    def ReadDBConnect(self,mydb):
            mycursor = mydb.cursor()
            sql = "SELECT * from SERVLETS" 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            poller=[]
            winserver=[]
            linserver=[]
            dct2={"POLLER":poller,"POLLER_Count":0,"WIN_SERVER_MON_AGENT":winserver,"WIN_SERVER_MON_AGENT_Count":0,"LIN_SERVER_MON_AGENT":linserver,"LIN_SERVER_MON_AGENT_Count":0}
            ls=list(res)
            for ls in list(res):
                if(ls[2]=="POLLER"):
                   dct2["POLLER_Count"]+=1
                   dct2["POLLER"].append(ls[1])
                elif(ls[2]=="WIN_SERVER_MON_AGENT"):
                    dct2["WIN_SERVER_MON_AGENT_Count"]+=1
                    dct2["WIN_SERVER_MON_AGENT"].append(ls[1])
                elif(ls[2]=="LIN_SERVER_MON_AGENT"):
                    dct2["LIN_SERVER_MON_AGENT_Count"]+=1
                    dct2["LIN_SERVER_MON_AGENT"].append(ls[1])
                
                        
            dct2["POLLER_Count"]=dct2["POLLER_Count"]
            dct2["WIN_SERVER_MON_AGENT_Count"]=dct2["WIN_SERVER_MON_AGENT_Count"]
            dct2["LIN_SERVER_MON_AGENT_Count"]=dct2["LIN_SERVER_MON_AGENT_Count"]
            print(dct2)
            return dct2
    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,curr_res):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        lif="<li>"
        lil="</li>"
        ulf="<ul>"
        ull="</ul>"
        #title=bf+"DependencyName"+(" "*10)+"CVE"+(" "*10)+"CWE"+(" "*50)+"CVSS_Severity"+(" "*10)+"CVSS_Score"+(" "*10)+"Type"+bl
        title1=bf+"Total Servlets For "
        title2=bf+"New Servlets For "
        obj=db.Database()
        mydb=obj.CreateDatabase()
        r=obj.ReadDBConnect(mydb,self.type)
        lis=["POLLER","WIN_SERVER_MON_AGENT","LIN_SERVER_MON_AGENT"]
        for val in lis:
            count=0
            con=olf
            c=0
            for v in r[val]:
                c+=1
                if(c==400):
                    break
                Servlets=v.replace("&","$")
                if("?" in Servlets):
                    ind=Servlets.index("?")
                    Servlets=Servlets[:ind]
                if(Servlets!=""):
                    if(Servlets  in curr_res):
                        con=con+bf+lif+Servlets+lil+bl
                        count+=1
            con+=oll
            if(count!=0):
                #+ulf+lif+str(curr_count)+lil+ull
                content=title1+val+bl+ulf+lif+str(r[val+"_Count"])+lil+ull+title2+val+bl+con
            else:
                content=title1+val+bl+olf+lif+str(r[val+"_Count"])+lil+oll+title2+val+bl+olf+lif+str(count)+lil+oll
            url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Security Automation Results for SERVLETS" 
            print(content)
            res=requests.post(url,headers=headers)
            print(res.text)
            #=================================
        

           
    def WriteDB(self,typ,mydb,res,jid):
        for api in res:
            res=self.ReadDB(mydb)
            res2=api
            if("?" in api):
                ind=res2.index("?")
                res2=res2[:ind]
            if(res2 not in res and api!=""):
                mycursor = mydb.cursor()
                sql = "INSERT INTO SERVLETS(Job_Id,Servlets,Type) VALUES (%s,%s,%s)"
                val = api
                mycursor.execute(sql, (jid,val,typ))
                mydb.commit()
                print(mycursor.rowcount, "record inserted.")
                self.curr_res.append(res2)

    
        



    
    
    
    




