#!/bin/bash
nuclei -u https://www.site24x7.in -var access_token=$super_admin_access_token -t ../templates/ -tags all -silent -p http://192.168.100.100:3128/ #> ~/Documents/test_output.txt

