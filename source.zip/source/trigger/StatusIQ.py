#!/usr/bin/python3

import requests
import shutil
import random
import time
import json
import sys
import datetime

class Component:
    def __init__(self):
        self.owasp={'Broken_Authentication': 101000000005145, 'Brute_Force': 101000001164243, 'Cleartext_Sensitive_Data': 101000001064049, 'Clickjacking': 101000001064045, 'XSSI': 101000001064047, 'XSS_DOM': 101000001064033, 'XSS_Reflected': 101000001064031, 'XSS_Self': 101000001101417, 'XSS_Stored': 101000001064029, 'CSRF': 101000000005053, 'DOS': 101000001064043, 'Directory_Listing': 101000001064051, 'LFI': 101000001064027, 'Hardcoded_Credentials': 101000001064057, 'HTML_Injection': 101000001314065, 'HTTP_Response_Manipulation': 101000001064053, 'Inadequate_Encryption_Strength': 101000001064035, 'Information_Disclosure': 101000000005003, 'Injection': 101000000005121, 'Insecure_Deserialization': 101000001064001, 'IDOR': 101000000005057,'Insecure_Data_Storage': 101000000005129,'Missing_Function_Level_Access_Control': 101000000005047, 'Others': 101000000005019, 'Path_Traversal': 101000001064041, 'RCE': 101000001064021, 'Security_Misconfiguration': 101000000005013, 'Sensitive_Data_Exposure': 101000000005039, 'Sensitive_Information_Logged': 101000001155151, 'SSRF': 101000001064037, 'Spam/Phishing': 101000001639549, 'SQL_Injection': 101000001064023, 'Tabnabbing': 101000001064059, 'Default_Credentials': 101000001064055, 'XXE': 101000001064025}
        #BugBounty
        #Linux/Windows Agent Poller CVE's
        self.Site24x7Plus="101000000047745"
        #Nuclei/Subdomain
        self.Site24x7="101000000005089"
        self.Site24X7_StatusPages="101000001397317"
        #StatusIQ 
        self.Site24x7_StatusIQ="205319000039847019"
        self.Site24x7_Onpermise_Poller="205319000040592003"
        self.Site24x7_Linux_Agent="205319000040592001"
        self.Site24x7_Windows_Agent="205319000039847039"
        self.Site24x7_AppLogs="205319000039847031"
        self.Site24x7_Global_Monitoring_Location="205319000040592007"
        self.Site24x7_GoogleDorks="205319000040592019"
        self.Site24x7_PlusServer="205319000039847027"
        self.Site24x7_RestApi="205319000040592017"
        self.Site24x7_CloudSpend="205319000039847025"
        self.Site24x7_Community="205319000039847023"
        self.Site24x7_Github="205319000040592021"
        self.Site24x7_Webclient="205319000039847048"
        self.Site24x7_SubDomains="205319000040592005"
        self.Site24x7_Website="205319000039847017"
        #Severity
        self.severity_low="101000000004021"
        self.severity_medium="101000000004019"
        self.severity_high="101000000004017"
        #Difficculty 
        self.difficult="101000000004013"
        self.easy="101000000004011"
        #bugbounty token
        self.bclient_id = "1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO"
        self.bclient_secret ="11fcd919188f3c0cf494bc79fa8957c69326964800"
        self.brefresh_token="1000.ce3d938e8a22ffcab69e88f197e03fde.bf21165221594634fbd5e49bc11b087d"
        #statuspage token
        self.client_id = "1000.EWSII6LUAN9QPSWBG649ICPIKBVN5H"
        self.client_secret ="30900f49cd0f57e8e37bd07dc4d779cb0ef3ae02d6"
        self.refresh_token="1000.cfcadbd7be01df3ea1a66af312a21d19.66d9a7f48cc252245fbd161df483183d"


       
       
    def generateAccessToken(self,domain, client_id, client_secret, refresh_token,file):
        url = (domain + "/oauth/v2/token?client_id={client_id}&client_secret={client_secret}&refresh_token={refresh_token}&grant_type=refresh_token").format(client_id=client_id, client_secret=client_secret, refresh_token=refresh_token)
        response = requests.post(url)
        json_data = json.loads(response.text)
        print(json_data)
        accessToken = json_data["access_token"]
        self.storeAccessToken(accessToken,file)
        return accessToken

    def storeAccessToken(self,accessToken,file):
        with open(file, "w") as f:
            f.write(accessToken)

    def retriveAccessToken(self,file):
        with open(file, "r") as f:
            accessToken = str(f.readline()).strip()
            return accessToken
    def headers(self,file):
        accessToken = self.retriveAccessToken(file)
        authHeader = "Zoho-oauthtoken " + accessToken
        headers = {
            "Authorization": authHeader,
            "Content-Type": "application/json;charset=UTF-8"
        }
        return headers

    def BugPost(self,service,severity,description,title):
        #url="https://bugs.zohosecurity.com/api/v1/bug"
        #url="https://bugs.zohosecurity.com/api/v1/bug/submitformdetails"
        #res=requests.get(url,headers=headers)
        #rs=json.loads(res.text)
        #rs[9]["value"]
        #print(rs)
        
        file="bugbounty_access_token"
        headers=self.headers(file)
        service_id=""
        if(severity=="medium"):
            severity_id=self.severity_medium
        elif(severity=="high"):
            severity_id=self.severity_high
        else:
            severity_id=self.severity_low
        if(service=="site24x7"):
            service_id=self.Site24x7
        elif(service=="site24x7_plus"):
            service_id=self.Site24x7Plus
        elif(service=="site24x7_statusIQ"):
            service_id=self.Site24X7_StatusPages
        

        url="https://bugs.zohosecurity.com/api/v1/bug"
        params={"service_id":service_id,"severity_id":severity_id,"difficulty_id":self.easy,"owasp_id":self.owasp["Others"],"description":"Automation Result For "+description,"title":title}
        res=requests.post(url,headers=headers,params=params)
        #print(res.content)
        if res.status_code == 401 or res.status_code==400:
            accessToken = self.generateAccessToken("https://accounts.zoho.com", self.bclient_id, self.bclient_secret, self.brefresh_token,file)
            headers=self.headers(file)
            res=requests.post(url,headers=headers,params=params)
            print(res)
        
    def StatusPost(self,titl,description,ids):
        file="access_token"
        def notify(title, description):
            headers=self.headers(file)
            body = {
                "incident_title": title,
                "incident_desc": description,
                "incident_severity_id":5,
                "incident_status_id":10,
                "incident_affected_components": [ids],
                "notify_email_subscribers": "true",
                "notify_sms_subscribers": "true"
            }
            url = "https://www.site24x7.com/sp/api/statuspages/205319000039847003/incidents/active"
            res = requests.post(url, headers=headers, json=body)
            #res=requests.get(url,headers=headers)
            rs=res.json()
            if res.status_code == 401:
                accessToken = self.generateAccessToken("https://accounts.zoho.com", self.client_id, self.client_secret, self.refresh_token,file)
                headers=self.headers(file)
                res = requests.post(url, headers=headers, json=body)
                print(res.text)
        notify(titl,description)
    
    def updateStatus(self):
        result=""
        file="bugbounty_access_token"
        headers=self.headers(file)
        url='https://bugs.zohosecurity.com/api/v1/bug'
        res = requests.get(url, headers=headers)
        
        if res.status_code == 401 or res.status_code==400:
                accessToken = self.generateAccessToken("https://accounts.zoho.com", self.bclient_id, self.bclient_secret, self.brefresh_token,file)
                headers=self.headers(file)
                res = requests.get(url, headers=headers,params={"limit":70})
                result=json.loads(res.text)
        else:
            result=json.loads(res.text)
        res=result["value"]
        curr_year,curr_month,curr_date=str(datetime.date.today()).split("-")
        #obj=Component()
        for i in res:
            severity=i["severity"]["severity_name"]
            service_name=i["service"]["service_name"]
            title=""
            ftime=i["filed_time"]
            if("title" in i.keys()):
                title=i["title"]
            bug_id=i["bug_id"]
            year,month,date=str(datetime.datetime.fromtimestamp(ftime/1000)).split(" ")[0].split("-")
            flag=False
            if(year==curr_year and month==curr_month and date==curr_date):
                flag=True
            if(flag==True):
                print(service_name)
                description="SEVERITY: "+severity+" REFER: https://bugs.zohosecurity.com/bb/#/bug/"+str(bug_id)
                if(service_name=="Site24x7"):
                    if("Nuclei" in title):
                        self.StatusPost(title,description,self.Site24x7_Webclient)
                    elif("Subdomain" in title):
                        self.StatusPost(title,description,self.Site24x7_SubDomains)
                    else:
                        self.StatusPost(title,description,self.Site24x7_Webclient)
                elif(service_name=="Site24X7_StatusPages"):
                    self.StatusPost(title,description,self.Site24X7_StatusPages)
                elif(service_name=="Site24x7 Plus"):
                    if(title!=""):
                        if("Poller" in title):
                            self.StatusPost(title,description,self.Site24x7_Onpermise_Poller)
                        elif("Linux Agent" in title):
                            self.StatusPost(title,description,self.Site24x7_Linux_Agent)
                        elif("Blacklisted" in title):
                            self.StatusPost(title,description,self.Site24x7_Global_Monitoring_Location)
                
                        
                        
    
"""def GetIncidents(header):
    url="https://www.site24x7.com/sp/api/statuspages/205319000039847003/incidents/active"
    res=requests.get(url,headers=header)
    print(res.text)
"""
#print(res.content, res.status_code)
'''

params = {
    'bug_category': 'All',
    'limit': '70',
    'offset': '0',
}

response = requests.get('https://bugs.zohosecurity.com/getrecentbugs', params=params, cookies=cookies, headers=headers, verify=False)
res=json.loads(response.text)
print(type(res))
res=res["value"]
obj=Component()
for i in res:
    severity=i["severity"]["severity_name"]
    service_name=i["service"]["service_name"]
    title=""
    if("title" in i.keys()):
        title=i["title"]
    bug_id=i["bug_id"]
    description="SEVERITY: "+severity+" REFER: https://bugs.zohosecurity.com/bb/#/bug/"+str(bug_id)
    if(service_name=="Site24x7"):
        StatusPost(title,description,obj.Site24x7_Webclient)
    elif(service_name=="Site24X7_StatusPages"):
        StatusPost(title,description,obj.Site24X7_StatusPages)
    elif(service_name=="Site24x7 Plus"):
        StatusPost(title,description,obj.Site24x7_PlusServer)
'''
bj=Component()
bj.updateStatus()

