import subprocess
import requests
import mysql.connector
import server.db.Database as db
import trigger.Generate_Access_Token as gen
#import ServletScanner as sc
#CREATE DATABASE
class SCodeAnalyse():
    def __init__(self,ls,jid,Type):
        self.curr_res=[]
        self.res=ls
        self.type=Type
        ValList=[]
        if(Type=="Lin_Agent_Code_Analyse"):
                ValList=self.res
                obj=db.Database()
                mydb=obj.CreateDatabase()
                mydb1=obj.Automation()
                mydb=[mydb,mydb1]
                res=obj.WriteDB(ValList,jid,None,mydb,None,self.type)
                #self.curr_res.extend(res)
       

    def UpdateConnect(self,curr_res):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        ulf="<ul>"
        ull="</ul>"
        lif="<li>"
        lil="</li>"
        #title=bf+"DependencyName"+(" "*10)+"CVE"+(" "*10)+"CWE"+(" "*50)+"CVSS_Severity"+(" "*10)+"CVSS_Score"+(" "*10)+"Type"+bl
        title1=bf+"Total Vulnerable Jar Files For "
        title2=bf+"New Vulnerable Jar Files For "
        obj=db.Database()
        mydb=obj.CreateDatabase()
        r=obj.ReadDBConnect(mydb,self.type)
        
        lis=["POLLER","NetworkPlus"]
        for val in lis:
            count=0
            con=olf
            c=0
            for k,v in r[val].items():
                c+=1
                if(c==51):
                    break
                Dname=k
                cve=v
                if(Dname in curr_res):
                    count+=1
                    con=con+bf+lif+Dname+" - [ "+cve+" ]"+lil+bl 
                     
            con+=oll
            if(count!=0):
                #+ulf+lif+str(curr_count)+lil+ull
                content=title1+val+bl+ulf+lif+str(r[val+"_Count"])+lil+ull+title2+val+bl+con
            else:
                content=title1+val+bl+olf+lif+str(r[val+"_Count"])+lil+oll+title2+val+bl+olf+lif+str(count)+lil+oll
            print(content)
            url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Security Automation Results For Vulnerable Jar" 
            #res=requests.post(url,headers=headers)
            #print(res.text)
        #self.UpdateConnect(self.curr_res)