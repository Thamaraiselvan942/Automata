from itertools import count
import subprocess
import requests
import mysql.connector
import server.db.Database as db
import trigger.Generate_Access_Token as gen
import trigger.ConnectReports as con
#import ServletScanner as sc
#CREATE DATABASE
class VulnerableJAR():
    def __init__(self,ls,jid,Type):
        self.curr_res=[]
        self.res=ls
        self.type=Type
        ValList=[]
        self.count=0
        if(Type=="Lin_Agent_Cve"):
                ValList=self.res
                obj=db.Database()
                mydb=obj.CreateDatabase()
                mydb1=obj.Automation()
                mydb=[mydb,mydb1]
                res=obj.WriteDB(ValList,jid,None,mydb,None,self.type)
                #self.curr_res.extend(res)
                self.count=res
                
        else:
            for key,val in self.res.items():
                ValList=val
                obj=db.Database()
                mydb=obj.CreateDatabase()
                mydb1=obj.Automation()
                mydb=[mydb,mydb1]
                res=obj.WriteDB(ValList,jid,key,mydb,None,self.type)
                self.count+=res
        #self.UpdateConnect(self.curr_res,Type)
        obj=con.Report()
        obj.UpdateConnect(Type,self.count)

        
    '''
    #READ Data FROM TABLE
    def ReadDB(self,mydb):
            mycursor = mydb.cursor()
            sql = "SELECT DependencyName  from CVE" 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            r=set(res)
            rs=[]
            for i in list(r):
                res=list(i)[0]
                rs.append(res)
            return rs
    '''
            
            
    ''' 
    def ReadDBConnect(self,mydb):
            mycursor = mydb.cursor()
            sql = "SELECT DependencyName,CVE ,Type from CVE" 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            poller={}
            netw={}
            dct2={"POLLER":poller,"POLLER_Count":0,"NetworkPlus":netw,"NetworkPlus_Count":0}
            ls=list(res)
            for ls in list(res):
                if(ls[2]=="POLLER"):
                    if(ls[0] in poller.keys()):
                        poller[ls[0]]=poller[ls[0]]+","+ls[1]
                    else:
                        poller[ls[0]]=ls[1]
                        
                elif(ls[2]=="NetworkPlus"):
                    if(ls[0] in netw.keys()):
                        netw[ls[0]]=netw[ls[0]]+","+ls[1]
                    else:
                        netw[ls[0]]=ls[1]
                        
            dct2["POLLER_Count"]=len(poller.keys())
            dct2["NetworkPlus_Count"]=len(netw.keys())
            #print(dct2)
            return dct2
            '''
    
                
            
    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,curr_res,typ):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        ulf="<ul>"
        ull="</ul>"
        lif="<li>"
        lil="</li>"
        
        #title=bf+"DependencyName"+(" "*10)+"CVE"+(" "*10)+"CWE"+(" "*50)+"CVSS_Severity"+(" "*10)+"CVSS_Score"+(" "*10)+"Type"+bl
        title1=bf+"Total Vulnerable Jar Files For "
        title2=bf+"New Vulnerable Jar Files For "
        title3=bf+"Refer --> "+"http://192.168.43.100:8080/"
        obj=db.Database()
        mydb=obj.CreateDatabase()
        r=obj.ReadDBConnect(mydb,typ)
        total=str(list(r[0])[0])
        #lis=["POLLER","NetworkPlus"]
        count=0
        content=""
        dt={"RealBrowser":[],"POLLER":[],"NetworkPlus":[]}
        val="Poller"
        res=""
        count=0
        for valu in curr_res:
            typs=valu[2]
            dt[typs].append(valu)
        for key,value in dt.items():
            dct={}
            con=olf
            if(len(value)>0):
                for valu in value:
                    dname=valu[0]
                    cve=valu[1]
                    if(dname not in dct.keys()):
                        dct[dname]=[cve]
                    else:
                        dct[dname].append(cve)
                    count+=1
                for dname,cve in dct.items():
                    if(len(cve)>5):
                        con=con+lif+dname+"-"+str(cve[:5])+" "+lil
                    else:
                        con=con+lif+dname+"-"+str(cve)+" "+lil

                con+=oll
                res+=title2+key+bl+con

        if(count!=0):
            content=title1+val+bl+olf+lif+total+lil+oll+res+title3
            #content=title1+val+bl+olf+lif+str("9")+lil+oll+title2+val+bl+olf+lif+str(count)+lil+oll
            url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Security Automation Results For "+typ 
            res=requests.post(url,headers=headers)
            #print(res.text)
            #self.UpdateConnect(self.curr_res)