import subprocess
import requests
import mysql.connector
import trigger.Generate_Access_Token as gen
import server.db.Database as db
import trigger.ZohoAnalytics as za
import trigger.StatusIQ as sq
class SubdomainScan():
    def __init__(self,result,jid,Type):
        self.curr_res=[]
        obj=db.Database()
        self.type=Type
        mydb=obj.CreateDatabase()
        mydb1=obj.Automation()
        mydb=[mydb,mydb1]
        zobj=za.Reports(jid)
        fres=""
        c=1
        if(Type=="Domain"):
            domain=result[0]
            for key,val in domain.items():   #key:value={key:[]}
                r=obj.WriteDB(val,jid,key,mydb,zobj,self.type)
            nmap=result[1]
            for key,val in nmap.items():   #key:value={key:[]}
                r=obj.WriteDB(val,jid,key,mydb,zobj,"Nmap")
        else:
            for key,val in result.items():   #key:value={key:[]}
                r=obj.WriteDB(val,jid,key,mydb,zobj,self.type)
                res=r[0]
                content=r[1]
                flg=r[2]
                if(flg>0):
                    self.UpdateConnect(content,key)
                    
                if(res!=""):
                    fres+=str(c)+".) "+res+"\n"
            sqobj=sq.Component()
            if(fres!=""):
                sqobj.BugPost("site24x7","low","Subdomain Vulnerability Scanning\n\n"+fres+"\n\n"+"#site24x7automation","Site24x7 Subdomain Vulnerabilities")
                
        
       
        
  
   
    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,content,title):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        lif="<li>"
        lil="</li>"
        ulf="<ul>"
        ull="</ul>"
       
        url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Security Automation Results for "+ title
        res=requests.post(url,headers=headers)
        print(res.text)
            
        

           
   
        



    
    
    
    




