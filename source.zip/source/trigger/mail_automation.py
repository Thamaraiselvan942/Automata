#!/bin/python
import requests
import base64
import json
import os
import re

domain="http://172.24.226.43:8080/"
class Automation:
    def Nuclei(self,cwd):
        ls=[]
        file1=open(cwd+"nuclei_vulnerability.txt","r")
        while True:
            line = file1.readline()
            if("http" in line and "] [" in line):
                ls.append(line.replace("\n",""))
            if not line:
                break
        return ls

    def StatusUpdate(self,api,data):
        r=requests.post(api,json=data)
        r=r.json()
        if(r["status"]=="updated"):
            print("removing the task id")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task finished")
        else:
            api=api.replace("Finished","Failed")
            r=requests.get(api)
            r=r.json()
            print(r)
            print("Task failed")

cwd=os.getcwd()+"/trigger/"
def Mail_automation(mail):
    url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.40cbb30c154d8c7b89fa24e00ff7a751.a59cb05cfb2550c91197de0051e6a59a&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=https://zylkerapps.com/oauth2callback&scope=ZohoMail.messages.ALL"
    r=requests.post(url)
    data = r.json()
    access_token='Zoho-oauthtoken '
    access_token+=data['access_token']
    store_headers={"Content-Type":"application/octet-stream","Authorization":access_token}
    store_url="https://mail.zoho.com/api/accounts/6508471000000008002/messages/attachments?fileName=nuclei_vulnerablities"
    file_name=cwd+"nuclei_vulnerability.txt"
    temp = ""
    with open(cwd+"nuclei_vulnerability.txt", "r") as f:
        temp = f.read().rstrip()
    print(temp)
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    temp = ansi_escape.sub('', temp)
    test_file = open(file_name, "w")
    test_file.write(temp)
    test_file.close()
    test_file = open(file_name, "rb")
    store_name=requests.post(store_url,headers=store_headers,files= {'upload_file':test_file})
    result=store_name.json()
    storeName=result['data']['storeName']
    attachmentPath=result['data']['attachmentPath']
    attachmentName=result['data']['attachmentName']
    default_mail="thamaraiselvan.pc@zohocorp.com,"+mail
    #print(storeName,attachmentPath,attachmentName)
    url2="https://mail.zoho.com/api/accounts/6508471000000008002/messages"
    payload = {"fromAddress": "thamaraiselvan.pc@zohocorp.com","toAddress": default_mail,"subject": "Email - Site24x7 Security Automation Result","content": "Nuclei Automation Script run successfully  "+temp, "attachments": [{"storeName":storeName,"attachmentName":attachmentName,"attachmentPath":attachmentPath}]}
    headers = {'Content-Type': 'application/json','Authorization':access_token}
    res = requests.post(url2, json=payload, headers=headers)
    data=res.json()
    print(data)

    #========================================================================================================================================
    nuclei_api=domain+"api/job/job_status_check?type=NucleiAutomation"
    r=requests.get(nuclei_api)
    r=r.json()
    nuclei_id=r["job_id"]
    print("nuclei_ID:",nuclei_id)
    nuclei_status=domain+"api/job/status_complete?type=NucleiAutomation&status=Finished&id="+nuclei_id
    nuclei_start=domain+"api/job/status_complete?type=NucleiAutomation&status=Started&id="+nuclei_id
    if(nuclei_id!=""):
        obj=Automation()
        data=obj.Nuclei(cwd)
        data={"Nuclei":data}
        obj.StatusUpdate(nuclei_status,data)
    else:
        print("Task not assigned...")
    


