import Generate_accessToken as gen
import requests
import json
import time
import configparser
import configparser

def Main():
   global verify_headers,verify_password,verify_url,account_url,console_url,s24x7_url,verify_url,verify_headers,verify_user_info,headers_verify2,verify_user,headers
   clid="1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO"
   csecret="11fcd919188f3c0cf494bc79fa8957c69326964800"
   file=open("refresh_token.txt","r")
   refresh_token=file.readline()
   access_token=gen.GetAdminaccess_token(clid,csecret,refresh_token)
   headers={
    "Authorization": "Zoho-oauthtoken "+access_token
    }
   config = configparser.RawConfigParser()
   config.read('config.properties.txt')
   s24x7_url=config.get('current','sit24x7_url')
   account_url=config.get('current','accounts_url')
   console_url=config.get('current','api_console_url')
   #------------------------------------------------------
   verify_url= account_url+"/webclient/v1/confirmation/"
   verify_user= account_url+"/webclient/v1/orguserinvitation/"
   verify_headers = {
                 "Content-Length": "46",
                 "Content-Type": "application/json",
                 "X-Http-Method-Override": "PUT",
                 "X-Requested-With": "XMLHttpRequest"
                }
   headers_verify2 = {
    'Host': s24x7_url,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Referer': s24x7_url+'/login/success.jsp?urlpath=%2Fhome%2FacceptInvitation.do',
    'Content-Type': 'application/x-www-form-urlencoded'
    }
   get_verify=""
   verify_password={"confirmation":{"password":"Arjunvijay@123"}}
   verify_user_info={"orguserinvitation":{"firstname":"test","lastname":"P","country":"EU","newsletter":"true","country_state":"Tamil Nadu","password":"Arjunvijay@123","account_type":"normal"}}


def Verify_Mail():
   global verify_headers,verify_password,verify_url,account_url,console_url,s24x7_url,verify_url,verify_headers,verify_user_info,headers_verify2,verify_user,headers
   Main()
   print("Verify Super Admin account.....")
   url_folder="http://mail.zoho.com/api/accounts/6508471000000008002/messages/view?folderId=6508471000000073001&start=1&limit=1"
   #6508471000000073001
   #===========================================================================
   with requests.Session() as session:
      getFid=session.get(url_folder,headers=headers)
      json_data=getFid.json()
      if(len(json_data['data'])!=0):
         message_id=json_data['data'][0]['messageId']
         url_content="http://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073001/messages/"+message_id+"/content"
         getmsg=session.get(url_content,headers=headers)
         sind=getmsg.text.index("accounts.zoho")-8
         tmp=getmsg.text[sind::]
         eind=tmp.index("\\")
         agree_url=tmp[:eind]
         if("amp;" in agree_url):
            agree_url=agree_url.replace("amp;","")
         tmp=agree_url
         s=tmp.rfind("=")+1
         res=tmp[s::]
         verify_url+=res;
         print(verify_url)
         #print(verify_url)
         gets=session.get(agree_url)
         cookie=gets.headers['Set-Cookie']
         sind=cookie.index("iamcsr")+7
         csr=cookie[sind:]
         eind=csr.index(";")
         iamcsr=csr[:eind]
         verify_headers["Cookie"]="iamcsr="+iamcsr
         verify_headers["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
         verify_headers["Referer"]= account_url+"/confirm?DIGEST="+res
         post=session.post(verify_url,headers=verify_headers,json=verify_password)
         print(post.json()['localized_message'])  
         print()
         #++++DELETE EMAIL++++++
         delete_url="https://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073001/messages/"+message_id
         delete_get=requests.delete(delete_url,headers=headers)
         #print(delete_get.text);
      else:
         print("no confirmation mail found")


#===========================================================================================================================================================
def Verify_User(user):
   global verify_headers,verify_password,verify_url,account_url,console_url,s24x7_url,verify_url,verify_headers,verify_user_info,headers_verify2,verify_user,headers
   Main()
   tmp_cookies={}
   url_folder="http://mail.zoho.com/api/accounts/6508471000000008002/messages/view?folderId=6508471000000073012&start=1&limit=1"
   #6508471000000073001
   #===========================================================================
   with requests.Session() as session:
      getFid=session.get(url_folder,headers=headers)
      json_data=getFid.json()
      if(len(json_data['data'])!=0):
         message_id=json_data['data'][0]['messageId']
         url_content="http://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073012/messages/"+message_id+"/content"
         getmsg=session.get(url_content,headers=headers)
         sind=getmsg.text.index("accounts.zoho")-8
         tmp=getmsg.text[sind::]
         eind=tmp.index("\\")
         agree_url=tmp[:eind]
         if("amp;" in agree_url):
            agree_url=agree_url.replace("amp;","")
         tmp=agree_url
         s=tmp.rfind("/")+1
         res=tmp[s::]
         #---------------------------------------------------
         verify_user+=res;
         print("verify_user................")
         gets=session.get(agree_url)
         cookie=gets.headers['Set-Cookie']
         sind=cookie.index("iamcsr")+7
         csr=cookie[sind:]
         eind=csr.index(";")
         iamcsr=csr[:eind]
         verify_headers["Cookie"]="iamcsr="+iamcsr
         verify_headers["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
         verify_headers["Referer"]=account_url+"/invitation/org/user/"+res
         post=session.post(verify_user,headers=verify_headers,json=verify_user_info)
         print(post.json()['localized_message']+"for "+user+" role")
         #==============================================Verify accept and Allowed get request
         cookie=post.headers['Set-Cookie']
         sind=cookie.index("_iamadt")+8
         csr=cookie[sind:]
         eind=csr.index(";")
         iamadt=csr[:eind]
         cookie2=post.headers['Set-Cookie']
         sind=cookie.index("_iambdt")+8
         csr=cookie[sind:]
         eind=csr.index(";")
         iambdt=csr[:eind]
         tmp_cookies['_iamadt']=iamadt
         tmp_cookies['_iambdt']=iambdt
         response2 = requests.get(s24x7_url+'/home/acceptInvitation.do', cookies=tmp_cookies, headers=headers_verify2)
         #++++DELETE EMAIL++++++
         delete_url="https://mail.zoho.com/api/accounts/6508471000000008002/folders/6508471000000073012/messages/"+message_id
         delete_get=requests.delete(delete_url,headers=headers)
         time.sleep(3)
         #print(delete_get.text);
      else:
         print("no confirmation mail found")





