class User:
    def __init__(self,user_role,mail_id,client_id,client_secret,refresh_token):
        self.user_role=user_role
        self.mail_id=mail_id
        self.client_id=client_id
        self.client_secret=client_secret
        self.refresh_token=refresh_token

    def __init__(self,user_role,mail_id):
        self.user_role=user_role
        self.mail_id=mail_id
    
    def get_user_role(self):
        return self.user_role

    def get_mail_id(self):
        return self.mail_id

    def get_client_id(self):
        return self.client_id

    def get_client_secret(self):
        return self.client_secret

    def get_refresh_token(self):
        return self.refresh_token

    def set_client_id(self,client_id):
        self.client_id=client_id

    def set_client_secret(self,client_secret):
        self.client_secret=client_secret

    def set_refresh_token(self,refresh_token):
        self.refresh_token=refresh_token
        
    
    
