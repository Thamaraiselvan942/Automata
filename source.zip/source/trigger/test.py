import os
import subprocess
import redis
import re
import requests
import json
from requests.structures import CaseInsensitiveDict
import datetime
import trigger.Score_Reports as sr
from trigger.__init__ import JunitXml, TestCase
import traceback


cwd=os.getcwd()+"/trigger/"
def Create_Reports(domain ,vulnerability ,job_id ,info_count):
    #url = "https://analyticsapi.zoho.com/api/thamaraiselvan.pc@zohocorp.com/S247Automation/Automation_Demo3"
    url = "https://analyticsapi.zoho.com/api/site24x7-admin@services.zodoor.com/DailyActivities/SecurityIssueDetails"
    #console_url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.9da684246aa6ab606bbf6092b42fa42f.1f57fe17446b130919d3dcbc5bd49c4a&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=analyticsapi.zoho.com"
    console_url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.ef6c8100cbf8598c2a04093ad81e35fc.b829ca85234fadfc51daa091b8660bab&grant_type=refresh_token&client_id=1000.EWSII6LUAN9QPSWBG649ICPIKBVN5H&client_secret=30900f49cd0f57e8e37bd07dc4d779cb0ef3ae02d6&redirect_uri=analyticsapi.zoho.com"
    r=requests.post(console_url)
    print(r)
    data = r.json()
    access_token=data["access_token"]
    headers = CaseInsensitiveDict()
    headers["Authorization"] = "Zoho-oauthtoken "+access_token
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    url2 = "https://analyticsapi.zoho.com/api/site24x7-admin@services.zodoor.com/DailyActivities/Site24x7SecurityScore"

    year,month,date=str(datetime.date.today()).split("-")
    x = datetime.datetime(int(year),int(month),int(date))
    Date=x.strftime("%d %b %Y")
    print(Date)
    severity=""
    for val in vulnerability:
        if("high" in val):
            severity="HIGH"
        elif("low" in val):
            severity="LOW"
        elif("medium" in val):
            severity="MEDIUM"
        elif("critical" in val):
            severity="CRITICAL"
        data = "ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=999&DATE="+Date+"&JOB_ID="+job_id+"&SEVERITY="+severity+"&DATA_CENTER="+domain.upper()+"&DESCRIPTION="+val
        resp = requests.post(url,headers=headers ,data=data)
        print(resp.text)
        print(resp.status_code)
    automation=sr.SecurityAtuomation()
    res=automation.getAndParseOutput(vulnerability)
    data = "ZOHO_ACTION=ADDROW&ZOHO_OUTPUT_FORMAT=XML&ZOHO_ERROR_FORMAT=XML&ZOHO_API_VERSION=1.0&Id=99&DATE="+Date+"&JOB_ID="+job_id+"&INFO="+str(info_count)+"&LOW="+str(res[3])+"&MEDIUM="+str(res[2])+"&HIGH="+str(res[1])+"&CRITICAL="+str(res[0])+"&SCORE="+str(res[4])+"&GRADE="+res[5]
    resp = requests.post(url2, headers=headers ,data=data)
    print(resp.text)


def Nuclei_Automation(types,task_id,access_token,s247_url,roles ,user ,account_url ,email, plus_host, domain,ids):
    global cwd
    try:
        #access_token="access_token= "+access_token
        #account_url="accounts_url="+account_url
        sind=s247_url.index(".")
        #email="email="+email
        tags=user
        #/media/sf_Workspace/red-team-scripts/source
        #/home/test/automation/redteam-scripts/
        whoami=os.system("whoami")
        redteam_script_root_folder = "/home/"+whoami+"/ASM/redteam-scripts/" + os.listdir("/home/"+whoami+"test/ASM/redteam-scripts/")[0]
        TEMPLATES_FOLDER = redteam_script_root_folder + "/source/nuclei_templates"
        temp1=TEMPLATES_FOLDER+"/zve/"
        temp2=TEMPLATES_FOLDER+"/zve/Add_monitor_Delay/"
        file1=open(cwd+"output.txt", "w")
        resout=cwd+"output.txt"
        vulnres=cwd+"nuclei_vulnerability.txt"
        open(cwd+"nuclei_vulnerability.txt", "w")
        if(ids!=""):
            p1 =os.system("nuclei -u "+s247_url+" -var access_token="+access_token+" -t "+temp1+" -id "+ ids+"  -p http://192.168.100.100:3128/  -nc -v >> "+vulnres+" 2>> "+resout)
        else:
            p1 =os.system("nuclei -u "+s247_url+" -var access_token="+access_token+" -t "+temp1+" -tags common_checks  -p http://192.168.100.100:3128/  -nc -v >> "+vulnres+" 2>> "+resout)
            p2 = os.system("nuclei -u "+s247_url+" -var access_token="+access_token+" -t "+temp1+" -etags delay"+" -tags "+ tags+" -var plus_host="+plus_host+" -var email="+email+" -var accounts_url="+ account_url+"  -p http://192.168.100.100:3128/ -nc -headless -v >> "+vulnres+" 2>> "+resout)
            p3 = os.system("nuclei -u "+s247_url+" -var access_token="+access_token+" -t "+temp2+" -tags "+ tags+" -rlm 3 "+ "-var plus_host="+ plus_host+" -var email="+email+" -var accounts_url="+ account_url+" -headless   -p http://192.168.100.100:3128/ -nc -v >> "+vulnres+" 2>> "+resout)
        tmp=[]
        info_count=0
        count=0
        file1=open(cwd+"output.txt", "a+")
        file2=open(cwd+"nuclei_vulnerability.txt","r")
        file1.write(file2.read())
        file1.seek(0)
        #open(cwd+"nuclei_vulnerability.txt","w")
        
        s=set()
        dic={}
        while True:
            count += 1
            # Get next line from file
            line = file1.readline()
            if("http" in line and "] [" in line):
                #print(line)
                temp=line
                sind=temp.index("] [")
                res2=temp[sind+3:]
                eind=res2.index("]")
                res=res2[:eind]
                dic[res]=line
            # if line is empty
            # end of file is reached
            if not line:
                break

        #==========================================================
        type=""
        print(dic)
        test=[]
        for key,val in dic.items():
                if("info" in val ):
                    #file=open(cwd+"nuclei_info.txt","a")
                    #file.write(val)
                    info_count+=1
                    type=""
                    test.append(TestCase(key ,str(val), type,"com.zoho.test.NucleiAutomation") )
                    
                elif("low" in val or "high" in val or "medium" in val or "critical" in val):
                    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
                    temp = ansi_escape.sub( "",str(val))
                    type="failure"
                    test.append(TestCase(key ,str(val) , type,"com.zoho.test.NucleiAutomation") )
                    tmp.append(temp)
                    #file=open(cwd+"nuclei_vulnerability.txt","a")
                    #file.write(val)
                else:
                    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
                    temp = ansi_escape.sub("" ,str(val))
                    type=""
                    test.append(TestCase(key ,str(val) ,type,"com.zoho.test.NucleiAutomation") )
                    

    except:
        traceback.print_exc()
        print("exception occured...")
        test=[]
    finally:
        junit_xml = JunitXml("Nuclei_Automation"+task_id,test)
        with open(cwd+"TESTS-TestSuites.xml" , "w") as f:
            f.write(junit_xml.dump())
        os.system("sshpass  -p 'Qazxsw#2!' scp -o StrictHostKeyChecking=no -P 22 "+cwd+"TESTS-TestSuites.xml test@172.24.145.164:/home/test/Automation/node1/workspace/QA-security")
        r=redis.Redis()
        r.set("s247_automation"+task_id,str(tmp))
        if(types!="qa_automation"):
            Create_Reports(domain,tmp ,task_id ,info_count)
#=====================================================================================================================================
def Common_Nuclei_Automation(task_id ,access_token ,s247_url):
    global cwd
    try:
        #access_token="access_token= "+access_token
        #account_url="accounts_url="+account_url
        sind=s247_url.index(".")
        tags="common_checks"
        redteam_script_root_folder = "" 
        whoami=os.system("whoami")
        redteam_script_root_folder = "/home/"+whoami+"/automation/redteam-scripts/" + os.listdir("/home/"+whoami+"/automation/redteam-scripts/")[0]
        TEMPLATES_FOLDER = redteam_script_root_folder + "/source/nuclei_templates"
        temp1=TEMPLATES_FOLDER+"/zve/"
        file1=open(cwd+"output.txt", "w")
        resout=cwd+"output.txt"
        vulnres=cwd+"nuclei_vulnerability.txt"
        open(cwd+"nuclei_vulnerability.txt", "w")
        p1 =os.system("nuclei -u "+s247_url+" -var access_token="+access_token+" -t "+temp1+" -tags common_checks -p http://192.168.100.100:3128/ -nc -v >> "+vulnres+" 2>> "+resout)
        tmp=[]
        info_count=0
        count=0
        file1=open(cwd+"output.txt", "a+")
        file2=open(cwd+"nuclei_vulnerability.txt","r")
        file1.write(file2.read())
        file1.seek(0)
        open(cwd+"nuclei_vulnerability.txt","w")
        s=set()
        dic={}
        while True:
            count += 1
            # Get next line from file
            line = file1.readline()
            if("http" in line and "] [" in line):
                #print(line)
                temp=line
                sind=temp.index("] [")
                res2=temp[sind+3:]
                eind=res2.index("]")
                res=res2[:eind]
                dic[res]=line
                s.add(res)
            # if line is empty
            # end of file is reached
            if not line:
                break

        #==========================================================
        type=""
        test=[]
        for key,val in dic.items():
                if("info" in val ):
                    file=open(cwd+"nuclei_info.txt" "a")
                    file.write(val+"\n")
                    info_count+=1
                    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
                    temp = ansi_escape.sub("" ,str(val))
                    type=""
                    test.append(TestCase(key ,str(val), type,"com.zoho.test.NucleiAutomation") )
                    
                elif("low" in val or "high" in val or "medium" in val or "critical" in val):
                    ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
                    temp = ansi_escape.sub(  str(val))
                    type="failure"
                    test.append(TestCase(key ,str(val) , type,"com.zoho.test.NucleiAutomation") )
                    tmp.append(temp)
                    file=open(cwd+"nuclei_vulnerability.txt" "a")
                    file.write(val+"\n")
                else:
                    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
                    temp = ansi_escape.sub("" ,str(val))
                    type=""
                    test.append(TestCase(key ,str(val) ,type,"com.zoho.test.NucleiAutomation") )
                    
    except:
        traceback.print_exc()
        print("exception occured...")
    finally:
        junit_xml = JunitXml("Nuclei_Automation"+task_id ,test)
        with open(cwd+"TESTS-TestSuites.xml","w") as f:
            f.write(junit_xml.dump())
        os.system("sshpass  -p 'Qazxsw#2!' scp -o StrictHostKeyChecking=no -P 22 "+cwd+"TESTS-TestSuites.xml test@172.24.145.164:/home/test/Automation/node1/workspace/QA-security")
    
#data=["[2022-06-28 06:53:59] [Inadequate-Encryption-Strength] [http] [critical] https://www.site24x7.com/api/users" "[2022-06-28 06:54:00] [Information-Disclosure] [http] [low] https://www.site24x7.com/api/json/listmonitors?apikey=us_9ca87c9361f17e3d24ba89b067f95e6b [agent=Zapier]" "[2022-06-28 06:58:01] [add_ping_monitor] [http] [high] https://www.site24x7.com/app/api/monitors/status/443529000000025066 [access_token= host=www.site24x7.com]"]
#Create_Reports("us" data "job_id978764676788" 2) 
  
#Nuclei_Automation("guhu","iuhgyug","1000.3b11211fa82301759d11a0b4752874f4.ff1bfef74cf31a5c0c51e10addd5fd9e", "https://www.site24x7.com", ["admin"] ,"admin", "https://accounts.zoho.com", "thamaraiselvan.pc+t01655294731289@zohotest.com","plus","com")
#nuclei -t ./ -tags admin -u  https://www.site24x7.eu -var access_token="1000.a912d1cac23858e17b0910c7d67eef95.6be1d865944dcaa6c1ec3edda95bfa78" -var plus_host="plus.site24x7.eu" -var accounts_url="https://accounts.zoho.eu" -var email="thamaraiselvan.pc+t01655294731289@zohotest.com" -headless -sb -p  http://192.168.100.100:3128 -v
#Common_Nuclei_Automation("65676r6f","ihuighyhvhj","https://www.site24x7.com")