import server.db.Database as db
#READ Data FROM TABLE
def ReadDB(mydb,sql):
    rs=[]
    query=sql
    mycursor = mydb.cursor()
    mycursor.execute(query)
    res=mycursor.fetchall()
    rs=res
    return rs

    '''
     if(type in ["Lin_Poller_Cve","Win_Poller_Cve","Lin_Agent_Cve","Win_Agent_Cve","Lin_Poller_Port","Lin_Agent_Port","Win_Poller_Port","Win_Agent_Port","Lin_Poller_Servlet","Lin_Agen_Servlet","Win_Poller_Servlet","Win_Agent_Servlet"]  ):
      
    '''

class CVE:
    def __init__(self,type):
        self.table=type
        obj=db.Database()
        mydb=obj.CreateDatabase()
        self.res=[]
        if("POLLER_CVE" in type ):
            sql="SELECT DependencyName,CVE,CWE,CVSS_Severity,CVSS_Score,Type,date from "+self.table
            res=ReadDB(mydb,sql)
            rs=[]
            for i in res:
                rs.append(list(i))
            self.res=rs
        if("LINUX_AGENT_CVE" in type ):
            sql="SELECT Package,Curr_version,Vuln_version,CVE,Issue,date from "+self.table
            res=ReadDB(mydb,sql)
            rs=[]
            for i in res:
                rs.append(list(i))
            self.res=rs
        elif(type=="WIN_AGENT_CVE"):
            pass
class CodeAnalyse:
    def __init__(self,type):
        self.table=type
        obj=db.Database()
        mydb=obj.CreateDatabase()
        self.res=[]
        if(type=="LINUX_AGENT_CODE_ANALYSE"):
            #print("********************************88")
            sql="SELECT Code,CWE,Severity,Issue,Filename,LineNum,date from "+self.table
            res=ReadDB(mydb,sql)
            rs=[]
            for i in res:
                rs.append(list(i))
            self.res=rs

class Subdomain:
    def __init__(self):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql="SELECT Domain,Vulnerabilities,Type,date from SUBDOMAIN"
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs
class Domain:
    def __init__(self):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql="SELECT DISTINCT Domain,date from DOMAIN"
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs

class Sub_Domain:
    def __init__(self,domain):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql="SELECT Subdomain from DOMAIN where Domain="+'"'+domain+'"'
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs

class NucleiAutomation:
    def __init__(self):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql="SELECT IssueType,Severity,Url,date from NucleiAutomation"
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs
        

class BLacklistedIP:
    def __init__(self):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql="SELECT IP,BlackLister,date from Blacklisted_IP"
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs
class OpenPorts:
    def __init__(self,type):
        self.table=type
        obj=db.Database()
        mydb=obj.CreateDatabase()
        self.res=[]
        if("PORT" in type):
            sql=sql = "SELECT port,service,date from "+self.table 
            res=ReadDB(mydb,sql)
            rs=[]
            for i in res:
                rs.append(list(i))
            self.res=rs

class Servlets:
    def __init__(self,type):
        self.table=type
        obj=db.Database()
        mydb=obj.CreateDatabase()
        self.res=[]
        if("SERVLET" in type):
            sql=sql = "SELECT Servlets,date from "+self.table
            res=ReadDB(mydb,sql)
            rs=[]
            #timeStamp,sct
            tmp=[]
            tmp2=[]
            for i in res:
                r=list(i)
                if("sct=" in r[0]):
                    s=r[0].index("sct=")+4
                    if("&" in r[0][s:]):
                        e=r[0][s:].index("&")
                        #print(s,s+e)
                        v=r[0][s:s+e]
                        #print(v)
                        r[0]=r[0].replace(v,"")
                        #print(r[0])

                if("timeStamp=" in r[0]):
                    s=r[0].index("timeStamp=")+10
                    if("&" in r[0][s:] ):
                        e=r[0][s:].index("&")
                        #print(s,s+e)
                        v=r[0][s:s+e]
                        #print(v)
                        r[0]=r[0].replace(v,"")
                        print(r[0])
                
                if(r[0] not in tmp):
                    tmp.append(r[0])
                    tmp2.append(r)

            for i in tmp2:
                rs.append(list(i))
            self.res=rs
    
class ScheduledJobs:
    def __init__(self):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql=sql = "SELECT * from Job_Schedule"
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs
class JobStatus:
    def __init__(self):
        obj=db.Database()
        mydb=obj.CreateDatabase()
        sql=sql = "SELECT  * from Task_Status"
        res=ReadDB(mydb,sql)
        rs=[]
        for i in res:
            rs.append(list(i))
        self.res=rs
