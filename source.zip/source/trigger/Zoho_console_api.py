import requests
import json
import time
import trigger.Zoho_Read_Mail as rm

#S247_USER_ROLES={'Admin': 2,'SuperAdmin': 1,'Operator': 3,'BillingContact': 4,'SpokesPerson': 5,'Hosting Provider': 6,'Read Only': 10}
S247_USER_ROLES={'Admin': 2}
class User:
    def __init__(self,user_role,mail_id,client_id,client_secret,refresh_token):
        self.user_role=user_role
        self.mail_id=mail_id
        self.client_id=client_id
        self.client_secret=client_secret
        self.refresh_token=refresh_token
       
        

    def __init__(self,user_role,mail_id):
        self.user_role=user_role
        self.mail_id=mail_id
    
    def get_user_role(self):
        return self.user_role

    def get_mail_id(self):
        return self.mail_id

    def get_client_id(self):
        return self.client_id

    def get_client_secret(self):
        return self.client_secret

    def get_refresh_token(self):
        return self.refresh_token

    def set_client_id(self,client_id):
        self.client_id=client_id

    def set_client_secret(self,client_secret):
        self.client_secret=client_secret

    def set_refresh_token(self,refresh_token):
        self.refresh_token=refresh_token
        
    
    

class ZohoConsole:
    def __init__(self,s24x7_url,account_url,console_url):
        self.s24x7_url=s24x7_url
        self.account_url=account_url
        self.console_url=console_url
        self.super_admin=None
        self.super_admin_cookies={}
        self.super_admin_headers={}
        self.users=[]


    def create_s247_account(self,time_mill="",resend_count=0):
        Url= self.account_url+"/accounts/register.ac"
        Agreeurl= self.s24x7_url+"/login/success.jsp?pack=44&l=en&frompage=signup.jsp&page=signup&zohouser="
        headers = {"Content-Type": "application/x-www-form-urlencoded",
            "Accept-Language": "en-US,en;q=0.5",
            "Origin": self.s24x7_url
            }
        if(time_mill==""):
            time_mill=str(int(time.time()*1000))
        super_admin_mail="thamaraiselvan.pc+t0"+time_mill
        signup_data ="email=thamaraiselvan.pc%2Bt0"+time_mill+"%40zohotest.com&password=Arjunvijay%40123&country_code=EU&r_address%2F2.phone=&s247-phone=&country=US&country_state=alabama&tos=false&r_account.account_name=thamaraiselvan.pc%2Bt0"+time_mill+"+-+Site24x7&accountType=ORG&s247_country_code=&l=en&pack=44&landingpage=-1&serviceurl="+self.s24x7_url.replace("://","%3A%2F%2F")+"%2Flogin%2Fsuccess.jsp%3Fpack%3D44%26l%3Den%26frompage%3Dsignup.jsp%26page%3Dsignup%26zohouser%3D&servicename=Site24x7&service_language=en&is_ajax=true&_pmsg=true"
        login_data="mode=primary&cli_time=1654521332458&servicename=Site24x7&serviceurl="+self.s24x7_url.replace("://","%3A%2F%2F")+"%2Flogin%2Fsuccess.jsp&service_language=en&signupurl="+self.s24x7_url.replace("://","%3A%2F%2F")+"%2Fsignup.html%3Fpack%3D44%26l%3Den"
        login_headers = {
                    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                    "Accept-Language": "en-US,en;q=0.5",
                    "Origin": self.account_url
                    }
        flag=False
        _iamadt=""
        _iambdt=""
        cookies = {
            '_iamadt': '',
            '_iambdt': '',
            }
        #================================================================================================
        Add_user= self.s24x7_url+"/app/api/users"
        user_headers={}
        user_cookies={}
        #=================================================================================================
        with requests.Session() as session:
            post=session.post(Url,headers=headers,data=signup_data)
            status=post.status_code
            cookie=post.headers['Set-Cookie']
            sind=cookie.index("iamcsr")+7
            csr=cookie[sind:]
            eind=csr.index(";")
            iamcsr=csr[:eind]
            #print("iamcsr",iamcsr)
            login_headers["Cookie"]="iamcsr="+iamcsr
            login_headers["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
            #print(flag)
            #print(post.text)
            if("_iamadt" in post.cookies):
                _iamadt=post.cookies['_iamadt']
                _iambdt=post.cookies['_iambdt']
                flag=True
            if(flag==True):
                file = open('userid.txt','w')
                file.write(_iamadt+"\n")
                file.write(_iambdt)
                file.close()
                cookies['_iamadt']=_iamadt
                cookies['_iambdt']=_iambdt
                print(cookies)
                get1=session.get(Agreeurl,cookies=cookies)
                print(get1)
                s247cname=get1.cookies['s247cname']
                self.super_admin_cookies['_iamadt']=_iamadt.replace("\n","")
                self.super_admin_cookies['_iambdt']=_iambdt
                self.super_admin_cookies['s247cname']=s247cname
                print("Sending Mail.......")
                time.sleep(10)
                Verify_Mail=rm.Zoho_Mail(self.s24x7_url,self.account_url,self.console_url)
                Verify_Mail.verify_superAdmin_mail(super_admin_mail,resend_count)
                time.sleep(10)
                #verify the super_admin account
                self.super_admin_headers = {
                    'Host': self.s24x7_url.replace("https://",""),
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Content-Type': 'application/json;charset=utf-8'
                    }
                self.super_admin_headers["X-Zcsrf-Token"]="s247pname="+s247cname

    def create_users(self,time_mill="",resend_count=0):
        json_data = {'selection_type': 0,'monitors': [],'monitor_groups': [],'user_role': 0,'alert_settings': {'email_format': 1,'alerting_period': {'start_time': '00:00','end_time': '00:00',},'down': [],'critical': [],'trouble': [],'up': [],'applogs': [],'anomaly': [],},'display_name': 'test','email_address': '','notify_medium': [1,],}

        for key, val in S247_USER_ROLES.items():
            print("Adding "+key+".............")
            json_data['user_role']=val
            if(time_mill==""):
                time_mill=str(int(time.time()*100))
            mail='thamaraiselvan.pc+t0'+time_mill+'@zohotest.com'
            json_data['email_address']=mail
            json_data['display_name']="test"
            response = requests.post(self.s24x7_url+'/app/api/users', headers=self.super_admin_headers, json=json_data,cookies=self.super_admin_cookies)
            print("create user status..",response.text)
            print(mail)
            time.sleep(15)
            user=User(key,mail)
            self.users.append(user)
            Verify_Mail=rm.Zoho_Mail(self.s24x7_url,self.account_url,self.console_url)
            Verify_Mail.verify_user_mail(key,mail,resend_count)
        
        

    def getrefresh_token(self,clid,csecret,code,user):
        url = self.account_url+"/oauth/v2/token"
        headers = {}
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        jsonres={}
        data = "client_id="+clid+"&client_secret="+csecret+"&code="+code+"&grant_type=authorization_code"
        resp = requests.post(url, headers=headers, data=data)
        jsonres=json.loads(resp.text)
        res=jsonres['refresh_token']
        print("refresh_token created for "+user+": ",res)
        return res

    def add_selfclient(self):
        for user in self.users:
            zohoapi_url=self.account_url
            postmail= self.account_url+"/signin/v2/lookup/"+user.get_mail_id()
            body="mode=primary&cli_time=1654755935614&servicename=AaaServer&serviceurl="+self.account_url.replace("://","%3A%2F%2F")+"%2Flogin%3Fserviceurl%3D%252Fclient%252F1000.058JNBTWOGAIZ7YBZSPSMTBSC6QXQU"
            headers={
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                "Origin": self.account_url}
            headers2=headers
            passwd_body={"passwordauth":{"password":"Arjunvijay@123"}}
            cookies={}
            with requests.Session() as session:
                #======================================Zoho console Login=========================================
                get=session.get(zohoapi_url)
                cookie=get.headers['Set-Cookie']
                sind=cookie.index("iamcsr")+7
                csr=cookie[sind:]
                eind=csr.index(";")
                iamcsr=csr[:eind]
                headers["Cookie"]="iamcsr="+iamcsr
                headers2["Cookie"]="iamcsr="+iamcsr
                headers["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
                post1=session.post(postmail,headers=headers,data=body)
                tmp=post1.text
                dct=json.loads(tmp)
                digest=dct['lookup']['digest']
                identifier=dct['lookup']['identifier']
                signin= self.account_url+"/signin/v2/primary/"+identifier+"/password?digest="+digest+"&cli_time=1654759591&servicename=AaaServer&serviceurl="+self.account_url.replace("://","%3A%2F%2F")+"%2Flogin"
                post2=session.post(signin,headers=headers2,json=passwd_body)
                #set cookies for selfclient
                tmp_cookie=post2.headers['Set-Cookie']
                sind=tmp_cookie.index("_iamadt")+8
                iam=tmp_cookie[sind:]
                eind=iam.index(";")
                _iamadt=iam[:eind]

                #-------------------------
                tmp_cookie=post2.headers['Set-Cookie']
                sind=tmp_cookie.index("_iambdt")+8
                iam=tmp_cookie[sind:]
                eind=iam.index(";")
                _iambdt=iam[:eind]
                cookies['_iamadt']=_iamadt
                cookies['_iambdt']=_iambdt
                #print(cookies)
                #====================================Zoho selfClient setup==========================================
                tmp=session.get(self.console_url)
                temp2=tmp.headers['Set-Cookie']
                sind=temp2.index("iamcsr")+7
                res=temp2[sind:]
                eind=res.index(";")
                iamcsr=res[:eind]
                client_head={
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "Origin": "https://api-console.zoho.in"
                }
                client_head["X-Zcsrf-Token"]="iamcsrcoo="+iamcsr
                cookies['iamcsr']=iamcsr

                selfclient=self.console_url+"/oauthapi/v1/selfclient"
                client_body={"selfclient":{"enable":"true"}}
                client_post=session.post(selfclient,headers=client_head,json=client_body,cookies=cookies)
                reslt=json.loads(client_post.text)
                res1=reslt['selfclient']
                href=res1['href']
                client_secret=res1['client_secret']
                client_id=res1['client_id']
                user.set_client_id(client_id)
                user.set_client_secret(client_secret)

                #======================================Generate Grant Token===========================================
                granturl=self.console_url+"/oauthapi/v1/selfclient/"+client_id+"/granttoken"
                grant_req={"granttoken":{"scope":["Site24x7.Admin.All","Site24x7.Account.All","Site24x7.Operations.All","Site24x7.Reports.All","Site24x7.Internal.All","Site24x7.DCMigration.All"],"expiry":3,"description":"test"}}
                resp=session.post(granturl,headers=client_head,json=grant_req,cookies=cookies)
                result2=json.loads(resp.text)
                grant_token=result2['granttoken']['Grant_token']
            

                #===========Generate RefreshToken
                refresh_token=self.getrefresh_token(client_id,client_secret,grant_token,user.get_user_role())
                user.set_refresh_token(refresh_token)




    

            

    

    
    
    
    
    
    
    
    

    
    
    
