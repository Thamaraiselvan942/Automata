import requests
import json
def Getaccess_token():
    clid="1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO"
    csecret="11fcd919188f3c0cf494bc79fa8957c69326964800"
    rtoken="1000.b901b8e58ca180f0c876d3235322ae4c.229b7931169416f36ab47ec2de56afb7"
    account_url="https://accounts.zoho.com"
    jsonres={}
    url = account_url+"/oauth/v2/token?"
    print(clid,csecret,rtoken)
    data = "client_id="+clid+"&client_secret="+csecret+"&refresh_token="+rtoken+"&grant_type=refresh_token"
    resp = requests.post(url+data)
    jsonres=json.loads(resp.text)
    print(jsonres)
    res=jsonres['access_token']
    return res

'''
def GenerateAccesstokenConnect():
        #Spreadsheet Refresh token
        #url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.d183e616a9aa754cb38fb1573e067daa.fe53ed8e489c98b719203bafe24ce8a5&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=https://www.zylker.com/oauthredirect"
        #Connect Refresh token
        url ="https://accounts.zoho.com/oauth/v2/token?refresh_token=1000.b901b8e58ca180f0c876d3235322ae4c.229b7931169416f36ab47ec2de56afb7&grant_type=refresh_token&client_id=1000.17UTMKVH0HOVA9P77KUHNB3NUY1JEO&client_secret=11fcd919188f3c0cf494bc79fa8957c69326964800&redirect_uri=https://www.zylker.com/oauthredirect"
        r=requests.post(url)
        data = r.json()
        print(data)
        access_token='Zoho-oauthtoken '
        access_token+=data['access_token']
        return access_token
'''