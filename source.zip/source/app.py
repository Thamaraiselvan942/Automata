from ast import arg
from crypt import methods
from importlib.metadata import requires
from logging import critical
from multiprocessing import connection
from pickletools import read_string1
import subprocess
import os
from distutils.log import debug
from turtle import delay
from flask import Flask,render_template,url_for,request,redirect
import sys
from h11 import Data
import os
import redis
from rq import Queue
import trigger.getrequest as gt
import trigger.CVEDatabase as cvedb
import trigger.OpenPortScanner as portscn
import trigger.ServletScanner as sc
import trigger.SubdomainScanner as sd
import trigger.BlacklistedIP as bl
import trigger.NucleiAutomation as nu
import trigger.StaticCodeAnalyse as stc
from concurrent.futures import ThreadPoolExecutor
import time
import json
import mysql.connector
import re
import trigger.Startup as st
import trigger.job_scheduler as js
import server.db.Database as db
import schedule as sh
import requests
import trigger.AutomationUI as au
import trigger.StatusIQ as sq
app=Flask(__name__)
r=redis.Redis()
q=Queue(connection=r)
tmp=""
class User:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/view/option',methods=["GET","POST"])
def option():
    if(request.method=="GET"):
        value=request.args.get("value")
        if(value=="WINDOWS_AGENT"):
            val="WINDOWS_AGENT"
        elif(value=="LINUX_AGENT"):
            val="LINUX_AGENT"
        elif(value=="WINDOWS_POLLER"):
            val="WINDOWS_POLLER"
        elif(value=="LINUX_POLLER"):
            val="LINUX_POLLER"
        return render_template('ShowOptions.html',val=val)

            
            
@app.route('/show/automation/result',methods=["GET","POST"])
def result():
    if(request.method=="GET"):
        value=request.args.get("value")
        if(value=="NUCLEI_AUTOMATION"):
            obj=au.NucleiAutomation()
            nuclei=obj.res
            return render_template('NucleiAutomation.html', title='NucleiAutomation Scanning Result',nuclei=nuclei)
        if(value=="SUBDOMAIN"):
            obj=au.Subdomain()
            subdomain=obj.res
            return render_template('Subdomain.html', title='Subdomain Scanning Result',subdomain=subdomain)
        if("CODE_ANALYSE" in value ):
            type=""
            '''
            if(value=="Win_Poller_Cve"):
                type="WIN_POLLER_CVE"
            elif(value=="Lin_Poller_Cve"):
                type="LINUX_POLLER_CVE"
            elif(value=="Win_Agent_Cve"):
                type="WIN_AGENT_CVE"
            elif(value=="Lin_Agent_Cve"):
                type="LINUX_AGENT_CVE"
                '''
            obj=au.CodeAnalyse(value)
            stcode=obj.res
            return render_template('StaticCodeAnalysis.html', title='CVE Scanning Result',stcode=stcode)
        
        if("CVE" in value ):
            type=""
            '''
            if(value=="Win_Poller_Cve"):
                type="WIN_POLLER_CVE"
            elif(value=="Lin_Poller_Cve"):
                type="LINUX_POLLER_CVE"
            elif(value=="Win_Agent_Cve"):
                type="WIN_AGENT_CVE"
            elif(value=="Lin_Agent_Cve"):
                type="LINUX_AGENT_CVE"
                '''
            obj=au.CVE(value)
            cves=obj.res
            if(value=="WIN_POLLER_CVE" or value=="LINUX_POLLER_CVE"):
                return render_template('data.html', title='CVE Scanning Result',cves=cves)
            elif(value=="LINUX_AGENT_CVE"):
                return render_template('LinuxAgentCVE.html', title='CVE Scanning Result',cves=cves)

        if(value=="BLACKLISTED_IP"):
            obj=au.BLacklistedIP()
            Blacklist=obj.res
            return render_template('BlacklistedIP.html', title='BlacklistedIP Scanning Result',Blacklist=Blacklist)
        if("SERVLET" in value):
            type=""
            '''
            if(value=="Win_Poller_Servlet"):
                type="WIN_POLLER_SERVLETS"
            elif(value=="Lin_Poller_Servlet"):
                type="LINUX_POLLER_SERVLETS"
            elif(value=="Lin_Agent_Servlet"):
                type="LINUX_AGENT_SERVLETS"
            elif(value=="Win_Agent_Servlet"):
                type="WIN_AGENT_SERVLETS"'''
            obj=au.Servlets(value)
            Servlets=obj.res
            return render_template('Servlets.html', title='Servlets Scanning Result',Servlets=Servlets)
        if("PORT" in value):
            type=""
            '''
            if(value=="Win_Poller_Port"):
                type="WIN_POLLER_PORT"
            elif(value=="Lin_Poller_Port"):
                type="LINUX_POLLER_PORT"
            elif(value=="Lin_Agent_Port"):
                type="LINUX_AGENT_PORT"
            elif(value=="Win_Agent_Port"):
                type="WIN_AGENT_PORT"'''
            obj=au.OpenPorts(value)
            Port=obj.res
            return render_template('Openport.html', title='OpenPort Scanning Result',Port=Port)
        if(value=="SCHEDULED_JOBS"):
            obj=au.ScheduledJobs()
            ScheduledJobs=obj.res
            return render_template('ScheduledJob.html', title='All ScheduledJobs ',ScheduledJobs=ScheduledJobs)
        if(value=="JOB_STATUS"):
            obj=au.JobStatus()
            status=obj.res
            return render_template('JobStatus.html', title='JobStatus ',status=status)
        if(value=="VIEW_TERMINAL"):
            return  redirect("http://172.24.239.250:8085/", code=302)
            

'''
@app.route('/api/job/start',methods=["POST"])
def data():
    global tmp
    print(request.form["domain"])
    if request.method=="POST":
        form_data = request.form
        tmp=request.form["domain"]
        job=q.enqueue(gt.main,args=(tmp,),job_timeout=3600)
        q_len=len(q)
        #return "Automation started successfully..."
        return f"Task {job.id} added queue at {job.enqueued_at} . {q_len}"        
        #return f"The URL /data is accessed directly. Try going to '/' to submit form"
'''
@app.route('/update_role',methods=["GET","POST"])
def reset_password():
    if request.method=="GET":
        args = request.args
        code=args.get("code")
        url="https://accounts.zoho.com/oauth/v2/token"
        parm={"code":code,
              "grant_type":"authorization_code",
              "client_id":"1000.G88QCGDK3PSXD8H7C0WV2YL5IH1J2M",
              "client_secret":"46fe69b19220d02b9718a24cdbcb3a8095a3f00615",
              "redirect_uri":"http://172.24.225.246:8080/update_role",
              "scope":"ZohoMail.accounts.ALL"
        }
        req=requests.post(url,params=parm)
        #print(req.text)
    return redirect("https://support.site24x7.com/agent/site24x7", code=302)

@app.route('/api/job/start',methods=["GET"])
def query_data():
    if request.method=="GET":
        args = request.args
        url= args.get("url")
        plus_host=args.get("plus_host")
        to_email=args.get("to_email")
        result={"url":url,"to_email":to_email,"plus_host":plus_host}
        type=args.get("type")
        ids=args.get("id")
        if(type==None):
            type=""
        if(ids==None):
            ids=""
        #plus_result={"plus_host":plus_host,"to_email":to_email}
        #print(result)
        if(None not in (url, to_email,plus_host)):
            print("first")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,plus_host,to_email,ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"

        elif(None not in (url,plus_host)):
            print("second")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,plus_host,"",ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
        elif(None not in (url,to_email)):
            print("third")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,"",to_email,ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
        elif(url!=None):
            print("fourth")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,"","",ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
        

def results(type,id):
    while(True):
        pass
#CREATE DATABASE
#Start the Vulnerability scanning
@app.route('/api/job/vulnerability_scan',methods=["GET","POST"])
def Vulnerability_Scann():
    if request.method=="GET":
        args = request.args
        type=args.get("type")
        result={"type":type}
        #type=SubdomainScanning
        #type=VulnerabilityScanning
        if(type==None):
            type=""
        #plus_result={"plus_host":plus_host,"to_email":to_email}
        #print(result)
        if(type=="StatusIQ"):
            sqobj=sq.Component()
            sqobj.updateStatus()
            return {"status":"success"}
        elif(type!=None):
            id=type+str(int(time.time()*1000))
            job=q.enqueue(results,args=(type,id,),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_VulnerabilityScan_Automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
            '''response_object = {"status": "error"}
            print(response_object)
        return response_object'''
        return {"status":"failed"}
    
     

#Job Status Check every 5min by python agent
@app.route('/api/job/job_status_check',methods=["GET","POST"])
def Check_Job_Status():
    if request.method=="GET":
        args = request.args
        types=args.get("type")
        rs=q.job_ids
        if(types==None):
            return {"job_id":rs}
        if(len(rs)>0):
            for val in rs:
                if(types in val):
                    obj=db.Database()
                    mydb=obj.CreateDatabase()
                    #print(val)
                    res=obj.WriteDB(None,val,"Started",mydb,None,"status")
                    return  {"job_id":val}

        return {"job_id":""}
        

@app.route('/api/job/job_schedule',methods=["GET","POST"])
def JobSchedule():
    if request.method=="GET":
            args = request.args
            type=args.get("type")
            time=args.get("time")
            day=args.get("day")
            hour=args.get("hour")
            minute=args.get("minute")
            everyday=args.get("everyday")
            if(minute!=None):
                res=js.ScheduleJobs(type,day,time,hour,int(minute),everyday)
            else:
                res=js.ScheduleJobs(type,day,time,hour,minute,everyday)
                
            obj=db.Database()
            mydb=obj.CreateDatabase()
            if(hour==None):
                hour="null"
            if(minute==None):
                minute="null"
            if(day==None):
                day="null"
            if(time==None):
                time="null"
            if(everyday==None):
                everyday="null"
            hour=hour+"&"+minute
            tim_ever=time+"&"+everyday

            try:
                obj.WriteDB(tim_ever,day,type,mydb,hour,"job_schedule")
            except:
                return {"job_schedule_status":"Already Found"}

            return {"job_schedule_status":"Success"}
        
            #return  {"job_schedule_status":"Failed"}
#Job Completed So Dqueue the Jobid
@app.route('/api/job/status_complete',methods=["GET","POST"])
def StatusUpdate():
    if request.method=="GET":
        try:
            args = request.args
            type=args.get("type")
            jid=args.get("id")
            status=args.get("status")
            obj=db.Database()
            mydb=obj.CreateDatabase()
            
            obj.WriteDB(None,jid,status,mydb,None,"status")
            #res=WriteDB(jid,mydb,status)
            q.remove(jid)
            rs=q.job_ids
            return  {"job_id":rs}
        except:
            return  {"job_id":rs}

    if request.method=="POST":
            #try:
            
            args = request.args
            type=args.get("type")
            jid=args.get("id")
            
            res=request.get_json()
            #res=request.data
            #print(res)
            
            if("Cve" in type):
                cve=res["CVE"]
                obj=cvedb.VulnerableJAR(cve,jid,type)
            if("Analyse" in type):
                stcode=res["STCODE"]
                obj=stc.SCodeAnalyse(stcode,jid,type)
            if("Port" in type):
                port=res["Ports"]
                obj2=portscn.OpenPortScan(port,jid,type)
            if("Servlet" in type):
                servlets=res["Servlets"]
                obj3=sc.ServletScan(servlets,jid,type)
            if(type=="BlacklistIPScanning"):
                blacklisted_ip=res["BlacklistedIP"]
                obj4=bl.BlacklistedIP(blacklisted_ip,jid,"BLACKLISTEDIP")
            if(type=="SubdomainScanning"):
                subdomain=res["Subdomain"]
                obj=sd.SubdomainScan(subdomain,jid,"SUBDOMAIN")
            if(type=="NucleiAutomation"):
                nuclei=res["Nuclei"]
                obj=nu.NucleiAutomation(nuclei,jid,"NucleiAutomation")
            

            
            return {"status":"updated"}
            #except:
            #return {"status":"not updated"}
        

@app.route('/api/job/status',methods=["GET","POST"])
def job_status():
    cwd=os.getcwd()+"/trigger/"
    if request.method=="GET":
        args = request.args
        task_id=args.get("id")
        task = q.fetch_job(task_id)
        
        
        '''
        with open(cwd+"nuclei_vulnerability.txt", "r") as f:
            temp = f.read().rstrip()
            #res.append(temp)
            r.set("s247_automation"+task.id,str(temp))
            ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
            tmp_res=str(r.get("s247_automation"+task.id))
            temp = ansi_escape.sub('', tmp_res)'''
        result=str(r.get("s247_automation"+task_id))
        low=result.count("low")
        medium=result.count("medium")
        high=result.count("high")
        critical=result.count("critical")
        if task:
            response_object = {
                "status": "success",
                "data": {
                    "task_id": task.get_id(),
                    "task_status": task.get_status(),
                    "s247_automation"+task_id: result,
                    "low": low,
                    "medium": medium,
                    "high": high,
                    "critical": critical
                }
            }
        else:
            response_object = {"status": "error"}
        #print(response_object)
        return response_object
def UpdateJobSchedule():
    print("Add All Scheduled Jobs to Scheduler...")
    obj=db.Database()
    mydb=obj.CreateDatabase()
    obj=au.ScheduledJobs()
    Jobs=obj.res
    for job in Jobs:
        Job_Type=job[0]
        Scheduled_day=job[1]
        Scheduled_time=job[2]
        Scheduled_hour=job[3]
        Scheduled_minute=job[4]
        Scheduled_everyday=job[5]
        if(Scheduled_day=="null"):
            Scheduled_day=""
        if(Scheduled_time=="null"):
            Scheduled_time=""
        if(Scheduled_hour=="null"):
            Scheduled_hour=""
        if(Scheduled_everyday=="null"):
            Scheduled_everyday=""
        if(Scheduled_minute=="null"):
            Scheduled_minute=""
        else:
            Scheduled_minute=int(Scheduled_minute)
        res=js.ScheduleJobs(Job_Type,Scheduled_day,Scheduled_time,Scheduled_hour,Scheduled_minute,Scheduled_everyday)
    #print("All current jobs in a Schedule Queue...",print(sh.jobs))

UpdateJobSchedule()    
if __name__  == "__main__":
    app.run(debug=True)