import subprocess
import os
#p1 = subprocess.run(['nuclei', '-u', 'http://www.site24x7.com', '-t','./','-tags','common_checks','-v','-p',' http://192.168.100.100:3128/'],stdout=f)
#os.system("nuclei -u http://www.site24x7.com -t ./ -tags common_checks -silent -p http://192.168.100.100:3128/ 2>> output.txt")
#content = p1.stdout.decode("utf-8")
#print(content
count=0
file1=open("output.txt", "r")
s=set()
dic={}
print(len(file1.read()))
while True:
    count += 1
    # Get next line from file
    line = file1.readline()
    if("http" in line and "] [" in line):
        #print(line)
        temp=line
        sind=temp.index("] [")
        res2=temp[sind+3:]
        eind=res2.index("]")
        res=res2[:eind]
        dic[res]=line
        s.add(res)
    # if line is empty
    # end of file is reached
    if not line:
        break
for k,v in dic.items():
    print(k," :",v)
print(count)
'''
file=open("output.txt","r")
res=file.readline()
print(res)
'''
