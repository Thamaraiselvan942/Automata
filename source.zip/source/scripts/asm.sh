#!/bin/bash

#Execute this bash with sudo Permission

DOMAIN=$1
mkdir -p /home/site24x7/automation/$DOMAIN-"`date +"%d-%m-%Y"`"
OUTPUT_DIR="/home/site24x7/automation/$DOMAIN-"`date +"%d-%m-%Y"`""

echo "Updating Nuclei & Templates"
sudo nuclei -update -silent

echo "Running Assetfinder for the Domain $DOMAIN"
assetfinder --subs-only $DOMAIN > $OUTPUT_DIR/$1-assetfinder_domains.txt

echo "Running subfinder for the Domain $DOMAIN"
subfinder -d $DOMAIN -silent -config config.yaml -recursive -all > $OUTPUT_DIR/$1-subfinder_domains.txt

echo "Running findomain for the Domain $DOMAIN"
findomain -t $DOMAIN --quiet > $OUTPUT_DIR/$1-findomain_domains.txt

echo "Running sublister for the Domain $DOMAIN"
sublist3r -d $DOMAIN -o $OUTPUT_DIR/$1-sublister_domains.txt

echo "Running amass scan for the Domain $DOMAIN"
amass enum -d $DOMAIN -o $OUTPUT_DIR/$1-amass_domains.txt

echo "Finding subdomains from crt.sh for the domain $DOMAIN"
curl "https://crt.sh/?q=$DOMAIN&output=json" > $OUTPUT_DIR/crt.sh_output
jq -r ".[] | .name_value" $OUTPUT_DIR/crt.sh_output |sort| uniq > $OUTPUT_DIR/$1-crtsh_domains.txt ; rm $OUTPUT_DIR/crt.sh_output

echo "Finding subdomains from sonar for the domain $DOMAIN"
curl -k -s https://sonar.omnisint.io/subdomains/$DOMAIN | jq -r '.[]' | sort -u > $OUTPUT_DIR/$1-sonar_domains.txt

#echo "Finding subdomains from gobuster for the domain $DOMAIN"
#gobuster dns -d $DOMAIN -w subdomains.txt --quiet | awk '{print $2}' > $OUTPUT_DIR/$1-gobuster_domains.txt

echo "Finding subdomains from wayback archive for the domain $DOMAIN"
waybackurls $DOMAIN | unfurl -u domains | sort -u > $OUTPUT_DIR/$1-wayback_domains.txt
gauplus -t 5 -random-agent -subs $DOMAIN |  unfurl -u domains | anew -q $OUTPUT_DIR/$1-wayback_domains.txt

echo "Finding subdomains from crobat for the domain $DOMAIN"
crobat -s $DOMAIN > $OUTPUT_DIR/$1-crobat_domains.txt

echo "Finding subdomains from github for the domain $DOMAIN"
github-subdomains -d $DOMAIN -t tokens.txt -o $OUTPUT_DIR/$1-github_domains.txt

echo "Saving all the outputs to a file"
cat $OUTPUT_DIR/*_domains.txt | anew -q $OUTPUT_DIR/$1_domains.txt

echo "Gathering the subdomains IPs"
cat $OUTPUT_DIR/$1_domains.txt | httpx -ip | awk '{print $2}' | sed 's/\[//;s/\]//' | anew -q $OUTPUT_DIR/$1_ips.txt

#cat $OUTPUT_DIR/$1_domains.txt $OUTPUT_DIR/$1_ips.txt > $OUTPUT_DIR/tmp.txt

#echo "Scanning for Ports"
#rustscan -a '$OUTPUT_DIR/tmp.txt' -r 1-65535 | egrep -iv '(80|443)' | grep Open | sed 's/Open //' | anew -q $OUTPUT_DIR/$1-ports.txt
#rm $OUTPUT_DIR/tmp.txt

echo "Probing the IPs and Domains"
cat $OUTPUT_DIR/$1_domains.txt $OUTPUT_DIR/$1_ips.txt $OUTPUT_DIR/$1_ports.txt | sort -u | httpx -silent > $OUTPUT_DIR/$1_alives.txt

echo "Detecting New Hosts"
cat $OUTPUT_DIR/$1_alives.txt | anew $OUTPUT_DIR-05-09-2022/$1_alives.txt | anew $OUTPUT_DIR/$1-new_hosts.txt

echo "Detecting Logins"
cat $OUTPUT_DIR/$1_alives.txt | httpx -fr -title | grep -i 'admin\|login\|dashboard\|portal\|Accounts' | awk '{print $1}' | anew -q $OUTPUT_DIR/$1-auth_pages.txt

echo "Executing Nuclei"
nuclei -silent -l $OUTPUT_DIR/$1_alives.txt -t ~/nuclei-templates -es info -o $OUTPUT_DIR/$1_nuclei_results.txt

echo "Detecting Pre"
cat $OUTPUT_DIR/$1_alives.txt | grep pre | tee  $OUTPUT_DIR/$1-predomains.txt

echo "Notifying the customer on cliq"

new=$(cat $OUTPUT_DIR/$1-new_hosts.txt | tr "\n" ",")
res=$(cat $OUTPUT_DIR/$1_nuclei_results.txt | awk '{print $3,$6}' | tr "[]" "()" | tr "\n" "," | tr " " "-")
countage=$(cat $OUTPUT_DIR/$1_alives.txt | wc -l)
priviledge=$(cat $OUTPUT_DIR/$1-auth_pages.txt | tr "\n" ",")
pre=$(cat $1-predomains.txt | tr "\n" ",")

curl -X POST "https://cliq.zoho.com/api/v2/bots/securitytest/incoming?zapikey=1001.a043170293eab351f9e0d4d9c89514ad.2b502792c12d604ec999101b4123a40a" \
-H 'Content-Type: text/plain' \
-d '{
    "domain_name":"'$1'",
    "new_subdomains_list":['$new'],
    "vulnerabilities_list": ['$res'],
    "count": ['$countage'],
    "priviledged_domains": ['$priviledge'],
    "predomains": ['$pre']
}'

echo "Notifying the customer on Connect"

access_token=$(curl --silent -X POST "https://accounts.zoho.com/oauth/v2/token?client_id=1000.YOOSS054X5TTKH19NEIVREBBG7CAQG&grant_type=refresh_token&client_secret=fbc8b696d71c116f51acf1077c7800e6c8acf69326&refresh_token=1000.e012b2c2e78c4168c2ef437a6f245bd8.3b1d5b16f1e41cfd390ff80c8a69b37e" | jq -r '.access_token')

wc=$(cat $OUTPUT_DIR/$1_alives.txt | wc -l | sed 's/^/<li>/;s/$/<\/li>/' | tr "\n" "+")
nhost=$(cat $OUTPUT_DIR/$1-new_hosts.txt | sed 's/^/<li>/;s/$/<\/li>/' | tr "\n" "+")
phost=$(cat $OUTPUT_DIR/$1-auth_pages.txt | sed 's/^/<li>/;s/$/<\/li>/' | tr "\n" "+")
scan=$(cat $OUTPUT_DIR/$1_nuclei_results.txt | awk '{print $3,$6}' | sed 's/^/<li>/;s/$/<\/li>/' | tr " " "+" | tr "\n" "+")

curl -X POST https://connect.zoho.com/pulse/api/v2/addStream \
-H "Authorization: Zoho-oauthtoken $access_token" \
-d 'scopeID=105000017039001&partitionID=105000666512885&streamTitle=Security Automation Results for '$1'&streamContent=<b>Total+Hosts+Found</b>+'$wc'<b>New+Hosts</b>+<ol>'$nhost'</ol><b>Priviledge+Hosts</b>+<ol>'$phost'</ol><b>Vulnerabilities</b>+<ol>'$scan'</ol>'


#find $OUTPUT_DIR/ -type f -empty -print -delete

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

: '
echo "Gathering URLs of $DOMAIN"
cat $OUTPUT_DIR/$1_domains.txt | waybackurls | tee -a $OUTPUT_DIR/$1_urls.txt;

echo "Searching for Open Redirect"
cat $OUTPUT_DIR/$1_urls.txt | qsreplace "http://example.com/" | httpx -fr -title -ms 'Example Domain' > $OUTPUT_DIR/$1_redirects.txt

#echo "Detecting Second Order Domains"
#cat $OUTPUT_DIR/$1_alives.txt | while read HOST ; do ( wget -qO- "$HOST" | grep -Eoi '<a [^>]+>' | grep -Eo 'href="[^\"]+"' | grep -Eo '(http|https)://[^/"]+' | sort -u | anew -q $OUTPUT_DIR/$1_secondary_domains.txt ) ; done

echo "Executing Directory search"
cat $OUTPUT_DIR/$1_alives.txt | dirsearch --stdin -w paths.txt -r -e .* -i 200 -q -o $OUTPUT_DIR/$1_diresults.txt

#echo "Finding Sensitive Files"
cat $OUTPUT_DIR/$1_urls.txt | grep -i "\.log$\|\.bak\|\.xlsx\|\.env\|\.py\|\.xml\|\.properties\|\.conf\|\.config\|\.json\|\.xml\|\.pem\|\.DS_Store\|\.php$\|\.yaml\|\.yml\|\.ts" | anew $OUTPUT_DIR/$1_sensitive.txt

echo "Nuclei Exection"
nuclei -l $OUTPUT_DIR/$1_alives.txt -t ~/nuclei-templates -es info -o $OUTPUT_DIR/$1_nuclei_outputs.txt '

#cat $OUTPUT_DIR/$1_domains.txt | anew $OUTPUT_DIR/$1_domains.txt | xargs -I {} -n 1 -p 1 bash -c 'sudo mkdir -p $OUTPUT_DIR/NEW ; echo "New Domain Found {}" ; echo {} | anew -q $OUTPUT_DIR/NEW/new_domain_details.txt ; echo "Finding Ip of the host {}" ; dig +short A {} | anew -q $OUTPUT_DIR/NEW/new_domain_details.txt ; echo "Executing Naabu for port scan" ; naabu -list $OUTPUT_DIR/NEW/new_domain_details.txt -p - | anew $OUTPUT_DIR/NEW/new_domain_port_details.txt ; cat $OUTPUT_DIR/NEW/new_domain_port_details.txt | anew -q $OUTPUT_DIR/NEW/new_domain_details.txt ; rm $OUTPUT_DIR/NEW/new_domain_port_details.txt ; echo "Probing the new domains" ; cat $OUTPUT_DIR/NEW/new_domain_details.txt | httpx -silent | anew -q $OUTPUT_DIR/NEW/new_alive_domain_details.txt ; echo "Executing Nuclei" ; nuclei -l $OUTPUT_DIR/NEW/new_alive_domain_details.txt -t ~/nuclei-templates -es info -o $OUTPUT_DIR/NEW/new_domain_nuclei_details.txt ;  echo "Executing dirsearch for new domains" ; cat $OUTPUT_DIR/NEW/new_alive_domain_details.txt | dirsearch --stdin -w /usr/share/wordlists/dirb/big.txt -r -e .* -i 200 -q -o $OUTPUT_DIR/NEW/new_domain_dir_results.txt'
#find $OUTPUT_DIR/ -type f -empty -print -delete

#echo "Executing Shodan"
#shodan download --limit -1 TEST "Ssl.Cert.Subject.CN:*.site24x7.com" &> /dev/null ; zcat TEST.json.gz | jq -r '.ip_str' > site24_ips.txt ; rm TEST.json.gz
