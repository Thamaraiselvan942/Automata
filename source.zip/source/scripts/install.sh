sudo apt-get update

wget https://go.dev/dl/go1.19.linux-amd64.tar.gz
tar -xvzf go1.19.linux-amd64.tar.gz
sudo mv go /usr/local/
echo "export PATH=$PATH:/usr/local/go/bin" >> ~/.bashrc
source ~/.bashrc
rm go1.19.linux-amd64.tar.gz
sudo apt-get -y install python3-pip

go install -v github.com/tomnomnom/waybackurls@latest
go install -v github.com/bp0lr/gauplus@latest
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/OWASP/Amass/v3/...@master
go install -v github.com/cgboal/sonarsearch/cmd/crobat@latest
go install -v github.com/gwen001/github-subdomains@latest
go install -v github.com/tomnomnom/anew@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
go install -v github.com/OJ/gobuster/v3@latest
go install -v github.com/tomnomnom/unfurl@latest
sudo mv ~/go/bin/* /usr/local/bin/
sudo nuclei -ut

sudo apt-get install jq
pip3 install -v sublist3r
pip3 install -v uro
pip3 install -v dirsearch

sudo apt install cargo
git clone https://github.com/findomain/findomain.git
cd findomain
cargo build --release
sudo cp target/release/findomain /usr/local/bin/
cd ..
rm -rf findomain

git clone https://github.com/RustScan/RustScan.git
cd RustScan
cargo build --release
sudo cp target/release/rustscan /usr/local/bin/
cd ..
rm -rf RustScan
