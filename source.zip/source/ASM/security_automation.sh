#!/bin/bash
killall -9 /usr/bin/redis-server
killall -9 /usr/bin/python3
path=$(pwd)
echo test | sudo -S rm -rf $path/redteam-scripts
echo test | sudo -S rm -rf $path/redteam-scripts.tar.gz
python3 $path/automation.py 

