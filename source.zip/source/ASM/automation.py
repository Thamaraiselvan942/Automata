import os
import stat
import requests
import tarfile

APP_FOLDER = os.getcwd()+"/"
os.system("cd "+APP_FOLDER+"& rm -rf redteam-scripts& rm -rf redteam-scripts.tar.gz")
response = requests.get("https://git.csez.zohocorpin.com/api/v4/projects/12645/repository/archive?private_token=kMj2SMV7nwD1jf-BbKuy")
#print(response.text)
open(APP_FOLDER + "redteam-scripts.tar.gz", "wb").write(response.content)

#open file
file = tarfile.open(APP_FOLDER + 'redteam-scripts.tar.gz')

#extracting file
file.extractall(APP_FOLDER + 'redteam-scripts/')

file.close()

redteam_script_root_folder = APP_FOLDER + "redteam-scripts/" + os.listdir(APP_FOLDER+"/redteam-scripts/")[0]

SOURCE_FOLDER = redteam_script_root_folder + "/source/"
TEMPLATES_FOLDER = redteam_script_root_folder + "/source/teamplates"


autosh_file = SOURCE_FOLDER+"app.py"
st = os.stat(autosh_file)
os.chmod(autosh_file, st.st_mode | stat.S_IEXEC)
os.chdir(SOURCE_FOLDER)
print(os.getcwd())
os.system("pip3 install -r requirements.txt")
os.system("python3 -m  pip install mysql-connector-python")
os.system("flask run -h 0.0.0.0  -p 8080 &")
os.system("rq worker &")
print(autosh_file)
print(SOURCE_FOLDER)
print(TEMPLATES_FOLDER)

