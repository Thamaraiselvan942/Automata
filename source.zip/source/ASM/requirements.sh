#proxy for internal environment
#export http_proxy=http://192.168.100.100:3128
#export https_proxy=http://192.168.100.100:3128

sudo -E apt-get update;
yes Y | sudo -E apt-get install python3;
yes Y | sudo -E apt install python3-pip;
yes Y | sudo -E apt-get install mysql-server;
yes Y | sudo -E apt-get install net-tools;
#p="$(pwd)/source/requirements.txt";
#echo "Installing pip requirements";
#sudo pip install -r $p;
sudo systemctl start mysql.service;
#sudo -h localhost -y root -p
#ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Arjun@123'
yes Y | sudo -E apt-get install redis;
yes Y | sudo -E apt-get install python3-tk;
yes Y | sudo -E apt-get install python3-rq;
yes Y | sudo -E apt-get install python3-flask;
yes Y | sudo -E apt-get install curl;
yes Y | sudo -E apt-get install wget;
wget https://go.dev/dl/go1.19.linux-amd64.tar.gz;
sudo tar -C /usr/local -xvzf go1.19.linux-amd64.tar.gz;
export PATH=$PATH:/usr/local/go/bin;
source $HOME/.profile;
go version;
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest;
sudo mv ~/go/bin/nuclei /usr/local/bin/
nuclei -ut;
./security_automation.sh
