var app = angular.module('asm.app', ['ui.router', 'chart.js']); 

app.config(['$stateProvider', '$urlRouterProvider','ChartJsProvider', function($stateProvider, $urlRouterProvider, ChartJsProvider){ 
	(function (ChartJsProvider) {
  		ChartJsProvider.setOptions({ colors : [ '#803690', '#00ADF9', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'] });
	}); 

	$urlRouterProvider.when('', '/domains/list');//NO I18N
  var domainState = {
    name: 'domains',
    url: '/domains/list',
    templateUrl: 'templates/domains.html'
  }

  var addDomainState = {
    name: 'add-domain',
    url: '/domains/add',
    templateUrl: 'templates/add-domain.html',
    controller: "AddDomainController"
  }

  var domainDetails = {
  	name: 'domain-details',
    url: '/domains/:domain_id',
    templateUrl: 'templates/domain-details.html',
    controller: "DomainDetailsController"
  }

  var addSubscriberState = {
  	name: 'add-subscriber',
    url: '/subscribers/add',
    templateUrl: 'templates/add-subscribers.html',
    controller: "AddSubscriberController"
  }

  var subscribersListState = {
  	name: 'list-subscriber',
    url: '/subscribers/list',
    templateUrl: 'templates/subscribers-list.html',
    controller: "ListSubscriberController"
  }



  $stateProvider.state(domainState);
  $stateProvider.state(domainDetails);
  $stateProvider.state(addDomainState);
  $stateProvider.state(addSubscriberState);
  $stateProvider.state(subscribersListState);
}]);


app.controller('AppController', ['$scope', '$stateParams', '$http', function($scope, $stateParams, $http) {
	$scope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];

  $scope.title = "Domains secured by Site24x7 EASM";
  $scope.sub_title = "Secure your Domain by adding it to our EASM";
  $scope.action_link = "/index.html#!/domains/add";
  $scope.action_text = "Add a Domain";

	$scope.processing = true;
	$http.get('http://52.140.3.229:8080/api/domain/list').then(function(response){
		$scope.processing = false;
         //handle your response here
         $scope.domains = response.data.result;
    });

	// $scope.domain_details = {
	// 	"domain_id": 1, 
	// 	"domain_name": "site24x7.com", 
	// 	"repetition": "Everyday at 10 AM",
	// 	"subdomain_count": 10,
	// 	"alive_count": 5,
	// 	"ports_count": 100,
	// 	"vulnerabilities":{
	// 		"info": 1,
	// 		"low": 2,
	// 		"medium": 3, 
	// 		"high": 4, 
	// 		"critical": 5
	// 	},
	// 	"vulnerability_details":[
	// 		{
	// 			"vuln_asset": "https://www.site24x7.jp", 
	// 			"vuln_severiy": "info", 
	// 			"vuln_protocol": "http",
	// 			"vuln_name": "openssl-detect", 
	// 			"vuln_service": "OpenSSL/1.0.2k"
	// 		},
	// 		{
	// 			"vuln_asset": "https://18.140.106.135", 
	// 			"vuln_severiy": "info", 
	// 			"vuln_protocol": "http",
	// 			"vuln_name": "apache-detect", 
	// 			"vuln_service": "Apache"
	// 		}
	// 	],
	// 	"port_details":[
	// 		{
	// 		  "ip": "117.20.43.49",
	// 		  "port": 443,
	// 		  "service": "https",
	// 		  "version": "Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.4.9"
	// 		}
	// 	], 
	// 	"histogram":[
	// 		""
	// 	]
	// }
 //  $scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
 //  $scope.series = ['Series A', 'Series B'];
 //  $scope.data = [
 //    [65, 59, 80, 81, 56, 55, 40],
 //    [28, 48, 40, 19, 86, 27, 90]
 //  ];
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  $scope.options = {
    scales: {
      yAxes: [
        {
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left'
        },
        {
          id: 'y-axis-2',
          type: 'linear',
          display: true,
          position: 'right'
        }
      ]
    }
  };


  $scope.pie_labels =["Critical", "High", "Medium", "Low", "Info"];

  $scope.pie_data = [
    [1, 2, 3, 4, 5]
  ];


}]);

app.controller('DomainDetailsController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
  //$scope.domain_name = "";

  $scope.processing = true;
  var domain_id = $stateParams.domain_id
  $http.get('http://52.140.3.229:8080/api/assets/' + domain_id).then(function(response){
      $scope.processing = false;
      console.log(response.data);
      $scope.result = response.data;      
      $scope.domain_name = $scope.result.domain_name;
      $scope.last_run = $scope.result.last_run;
      $scope.port_details = $scope.result.port_details;
      $scope.sub_domains = $scope.result.sub_domains;
      $scope.vuln_detials = $scope.result.vuln_detials;
      $scope.vulnerabilitiesCount = $scope.result.vulnerabilities;
      $scope.repetition = $scope.result.repetition;
      $scope.labels = $scope.result.asset_history.label;
      $scope.series = $scope.result.asset_history.series;
      $scope.data = $scope.result.asset_history.data;

      $scope.title = "Attack Surface of " + $scope.result.domain_name

    });
  $scope.addDomain = function(domain_name){
    postdata = {"domain-name": domain_name};
    $scope.processing = true;
    $http.post('http://52.140.3.229:8080/api/add-domain', postdata).then(function(response){
      $scope.processing = false;
          alert(response.data.status);
      });
  }

}]);

app.controller('AddDomainController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
	//$scope.domain_name = "";
	$scope.processing = false;
	$scope.addDomain = function(domain_name){
		postdata = {"domain-name": domain_name};
		$scope.processing = true;
		$http.post('http://52.140.3.229:8080/api/add-domain', postdata).then(function(response){
			$scope.processing = false;
	        alert(response.data.status);
    	});
	}

}]);


app.controller('AddSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
	//$scope.domain_name = "";
	$scope.processing = false;
  $http.get('http://52.140.3.229:8080/api/domain/list').then(function(response){
    $scope.processing = false;
         //handle your response here
         $scope.domains = response.data.result;
    });

  $scope.addSubscriber= function(mobile, selected_domains, selected_categories){
    alert(mobile, selected_domains, selected_categories)
  }


	$scope.addDomain = function(domain_name){
		postdata = {"domain-name": domain_name};
		$scope.processing = true;
		$http.post('http://52.140.3.229:8080/api/add-domain', postdata).then(function(response){
			$scope.processing = false;
	        alert(response.data.status);
    	});
	}

}]);
