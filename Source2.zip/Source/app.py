from ast import arg
from crypt import methods
from importlib.metadata import requires
from logging import critical
from multiprocessing import connection
from pickletools import read_string1
import subprocess
import os
from distutils.log import debug
from turtle import delay
from flask import Flask,render_template,url_for,request,redirect
import sys
from h11 import Data
import os
import redis
from rq import Queue
import trigger.getrequest as gt
import trigger.CVEDatabase as cvedb
import trigger.OpenPortScanner as portscn
import trigger.ServletScanner as sc
import trigger.SubdomainScanner as sd
import trigger.BlacklistedIP as bl
import trigger.NucleiAutomation as nu
import trigger.StaticCodeAnalyse as stc
from concurrent.futures import ThreadPoolExecutor
import time
import json
import trigger.Startup as st
import trigger.job_scheduler as js
import Server.db.Database2 as db2
import trigger.AutomationUI as au
import trigger.StatusIQ as sq
import schedule as sh
import mysql.connector
import re
import requests
import Server.db.Database as db
#import trigger.Domain as dm
app=Flask(__name__,static_folder="ASM", static_url_path="/ASM")
r=redis.Redis()
q=Queue(connection=r)
tmp=""
obj=db.Database()
obj.CreateDatabase()
url_domain="http://172.20.10.4:8080"
class User:
    def __init__(self,name,age):
        self.name=name
        self.age=age

@app.route('/')
def index():
    return render_template('ASM/index.html')

@app.route('/domains/list')
def domin_list():
    return render_template('domains.html')
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@app.route('/post_data/github',methods=["GET","POST"])
def Github():
    if request.method=="POST":
            args = request.args
            res=request.get_json()
            obj=db.Database()
            table="Github"
            result=obj.WriteDB("1",res,table)
            return {"status":"success"}

@app.route('/get_data/github',methods=["GET","POST"])
def ReadGithubData():
    if request.method=="GET":
            args = request.args
            obj=db.Database()
            result=obj.Github("1")
            return result

#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

@app.route('/post_data/dorks',methods=["GET","POST"])
def Dorks():
    if request.method=="POST":
            args = request.args
            jid=args.get("id")
            res=request.get_json()
            obj=db.Database()
            table="Dorks"
            result=obj.WriteDB(jid,res,table)
            return {"status":"success"}

@app.route('/get_data/dorks',methods=["GET","POST"])
def ReadDorksData():
    if request.method=="GET":
            args = request.args
            obj=db.Database()
            jid=args.get("id")
            print(jid)
            result=obj.Dorks(jid)
            return result

#--------------------------------------------------------------------------------------ASMINT--------------------------------------------------------------------------------
@app.route('/show/automation/result',methods=["GET","POST"])
def result():
    if(request.method=="GET"):
        #assert value == request.args.get['value']
        value=request.args.get("value")
        if(value=="NUCLEI_AUTOMATION"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            nuclei=""
            if(alldate=="true"):
                obj=au.NucleiAutomation(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.NucleiAutomation(date)
                nuclei=obj.res
            else:
                obj=au.NucleiAutomation()
                nuclei=obj.res
            return render_template('NucleiAutomation.html', title='NucleiAutomation Scanning Result',nuclei=nuclei)
        if(value=="SUBDOMAIN"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            subdomain=""
            if(alldate=="true"):
                obj=au.Subdomain(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.Subdomain(date)
                subdomain=obj.res
            else:
                obj=au.Subdomain()
                subdomain=obj.res
            return render_template('Subdomain.html', title='Subdomain Scanning Result',subdomain=subdomain)
        if(value=="DOMAIN"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            domain=""
            if(alldate=="true"):
                obj=au.Domain(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.Domain(date)
                domain=obj.res
            else:
                obj=au.Domain()
                domain=obj.res
            return {"data":domain}
            #return render_template('Domain.html', title='Domain Scanning Result',domain=domain)
        if(value=="NMAP"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            nmap=""
            if(alldate=="true"):
                obj=au.Nmap(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.Nmap(date)
                nmap=obj.res
            else:
                obj=au.Nmap()
                nmap=obj.res
            return render_template('Nmap.html', title='Nmap Scanning Result',nmap=nmap)
        if(value=="SUB_DOMAIN"):
            domain=request.args.get("domain")
            obj=au.Sub_Domain(domain)
            domain=obj.res
            return {"res":domain}
        if("CODE_ANALYSE" in value ):
            type=""
            '''
            if(value=="Win_Poller_Cve"):
                type="WIN_POLLER_CVE"
            elif(value=="Lin_Poller_Cve"):
                type="LINUX_POLLER_CVE"
            elif(value=="Win_Agent_Cve"):
                type="WIN_AGENT_CVE"
            elif(value=="Lin_Agent_Cve"):
                type="LINUX_AGENT_CVE"
                '''
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            stcode=""
            if(alldate=="true"):
                obj=au.CodeAnalyse(value,alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.CodeAnalyse(value,date)
                stcode=obj.res
            else:
                obj=au.CodeAnalyse(value)
                stcode=obj.res
            return render_template('StaticCodeAnalysis.html', title='CVE Scanning Result',stcode=stcode)

        if("CVE" in value ):
            type=""
            '''
            if(value=="Win_Poller_Cve"):
                type="WIN_POLLER_CVE"
            elif(value=="Lin_Poller_Cve"):
                type="LINUX_POLLER_CVE"
            elif(value=="Win_Agent_Cve"):
                type="WIN_AGENT_CVE"
            elif(value=="Lin_Agent_Cve"):
                type="LINUX_AGENT_CVE"
                '''
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            cves=""
            if(alldate=="true"):
                obj=au.CVE(value,alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.CVE(value,date)
                cves=obj.res
            else:
                obj=au.CVE(value)
                cves=obj.res
            if(value=="WIN_POLLER_CVE" or value=="LINUX_POLLER_CVE"):
                return {"data":cves}
                #return render_template('data.html', title='CVE Scanning Result',cves=cves)
            elif(value=="LINUX_AGENT_CVE" or value=="WIN_AGENT_CVE"):
                return {"data":cves}
                #return render_template('LinuxAgentCVE.html', title='CVE Scanning Result',cves=cves)

        if(value=="BLACKLISTED_IP"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            Blacklist=""
            if(alldate=="true"):
                obj=au.BLacklistedIP(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.BLacklistedIP(date)
                Blacklist=obj.res
            else:
                obj=au.BLacklistedIP()
                Blacklist=obj.res
            return render_template('BlacklistedIP.html', title='BlacklistedIP Scanning Result',Blacklist=Blacklist)
        if(value=="BLACKLISTED"):
            ip=request.args.get("ip")

            obj=au.BLacklisted(ip)
            Blacklist=obj.res
            return {"res":Blacklist}
        if("SERVLET" in value):
            type=""
            '''
            if(value=="Win_Poller_Servlet"):
                type="WIN_POLLER_SERVLETS"
            elif(value=="Lin_Poller_Servlet"):
                type="LINUX_POLLER_SERVLETS"
            elif(value=="Lin_Agent_Servlet"):
                type="LINUX_AGENT_SERVLETS"
            elif(value=="Win_Agent_Servlet"):
                type="WIN_AGENT_SERVLETS"'''
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            Servlets=""
            if(alldate=="true"):
                obj=au.Servlets(value,alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.Servlets(value,date)
                Servlets=obj.res
            else:
                obj=au.Servlets(value)
                Servlets=obj.res
            return {"data":Servlets}
            #return render_template('Servlets.html', title='Servlets Scanning Result',Servlets=Servlets)
        if("PORT" in value):
            type=""
            '''
            if(value=="Win_Poller_Port"):
                type="WIN_POLLER_PORT"
            elif(value=="Lin_Poller_Port"):
                type="LINUX_POLLER_PORT"
            elif(value=="Lin_Agent_Port"):
                type="LINUX_AGENT_PORT"
            elif(value=="Win_Agent_Port"):
                type="WIN_AGENT_PORT"'''
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            Port=""
            if(alldate=="true"):
                obj=au.OpenPorts(value,alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.OpenPorts(value,date)
                Port=obj.res
            else:
                obj=au.OpenPorts(value)
                Port=obj.res
            return render_template('Openport.html', title='OpenPort Scanning Result',Port=Port)
        if(value=="SCHEDULED_JOBS"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            ScheduledJobs=""
            if(alldate=="true"):
                obj=au.ScheduledJobs(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.ScheduledJobs(date)
                ScheduledJobs=obj.res
            else:
                obj=au.ScheduledJobs()
                ScheduledJobs=obj.res
            return render_template('ScheduledJob.html', title='All ScheduledJobs ',ScheduledJobs=ScheduledJobs)
        if(value=="JOB_STATUS"):
            date=request.args.get("date")
            alldate=request.args.get("alldate")
            status=""
            if(alldate=="true"):
                obj=au.JobStatus(alldate)
                adate=obj.res
                return {"res":adate}
            if(date!="" and date!=None):
                obj=au.JobStatus(date)
                status=obj.res
                #print(status)

            else:
                obj=au.JobStatus()
                status=obj.res

            return render_template('JobStatus.html', title='JobStatus ',status=status)
#---------------------------------------------------------------------------------------------START----------------------------------------------------------------------------------------------
@app.route('/api/job/start',methods=["GET"])
def query_data():
    if request.method=="GET":
        args = request.args
        url= args.get("url")
        plus_host=args.get("plus_host")
        to_email=args.get("to_email")
        result={"url":url,"to_email":to_email,"plus_host":plus_host}
        type=args.get("type")
        ids=args.get("id")
        if(type==None):
            type=""
        if(ids==None):
            ids=""
        #plus_result={"plus_host":plus_host,"to_email":to_email}
        #print(result)
        if(None not in (url, to_email,plus_host)):
            print("first")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,plus_host,to_email,ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"

        elif(None not in (url,plus_host)):
            print("second")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,plus_host,"",ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
        elif(None not in (url,to_email)):
            print("third")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,"",to_email,ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
        elif(url!=None):
            print("fourth")
            id='my_job_id'+str(int(time.time()*1000))
            job=q.enqueue(gt.main,args=(id,url,type,"","",ids),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"


def results(type,id):
    while(True):
        pass
#CREATE DATABASE
#Start the Vulnerability scanning
@app.route('/api/job/vulnerability_scan',methods=["GET","POST"])
def Vulnerability_Scann():
    if request.method=="GET":
        args = request.args
        type=args.get("type")
        result={"type":type}
        #type=SubdomainScanning
        #type=VulnerabilityScanning
        if(type==None):
            type=""
        #plus_result={"plus_host":plus_host,"to_email":to_email}
        #print(result)
        if(type=="StatusIQ"):
            sqobj=sq.Component()
            sqobj.updateStatus()
            return {"status":"success"}
        elif(type!=None):
            id=type+str(int(time.time()*1000))
            job=q.enqueue(results,args=(type,id,),job_timeout=3600,job_id=id)
            q_len=len(q)
            r.set("s247_VulnerabilityScan_Automation"+job.id,"")
            return f"Task {job.id} added queue at {job.enqueued_at} . {q_len},{result},{type}"
            '''response_object = {"status": "error"}
            print(response_object)
        return response_object'''
        return {"status":"failed"}



#Job Status Check every 5min by python agent
@app.route('/api/job/job_status_check',methods=["GET","POST"])
def Check_Job_Status():
    if request.method=="GET":
        args = request.args
        types=args.get("type")
        rs=q.job_ids
        if(types==None):
            return {"job_id":rs}
        if(len(rs)>0):
            for val in rs:
                if(types in val):
                    obj=db2.Database()
                    mydb=obj.CreateDatabase()
                    mydb1=obj.Automation()
                    mydb=[mydb,mydb1]
                    #print(val)
                    res=obj.WriteDB(None,val,"Started",mydb,None,"status")
                    return  {"job_id":val}

        return {"job_id":""}


@app.route('/api/job/job_schedule',methods=["GET","POST"])
def JobSchedule():
    if request.method=="GET":
            args = request.args
            type=args.get("type")
            time=args.get("time")
            day=args.get("day")
            hour=args.get("hour")
            minute=args.get("minute")
            everyday=args.get("everyday")
            if(minute!=None):
                res=js.ScheduleJobs(type,day,time,hour,int(minute),everyday)
            else:
                res=js.ScheduleJobs(type,day,time,hour,minute,everyday)
            obj=db2.Database()
            mydb=obj.CreateDatabase()
            mydb1=obj.Automation()
            mydb=[mydb,mydb1]
            if(hour==None):
                hour="null"
            if(minute==None):
                minute="null"
            if(day==None):
                day="null"
            if(time==None):
                time="null"
            if(everyday==None):
                everyday="null"
            hour=hour+"&"+minute
            tim_ever=time+"&"+everyday

            try:
                obj.WriteDB(tim_ever,day,type,mydb,hour,"job_schedule")
            except:
                return {"job_schedule_status":"Already Found"}

            return {"job_schedule_status":"Success"}

            #return  {"job_schedule_status":"Failed"}
#Job Completed So Dqueue the Jobid
@app.route('/api/job/status_complete',methods=["GET","POST"])
def StatusUpdate():
    if request.method=="GET":
        try:
            args = request.args
            type=args.get("type")
            jid=args.get("id")
            status=args.get("status")
            obj=db2.Database()
            mydb=obj.CreateDatabase()
            mydb1=obj.Automation()
            mydb=[mydb,mydb1]

            obj.WriteDB(None,jid,status,mydb,None,"status")
            #res=Writedb2(jid,mydb2,status)
            q.remove(jid)
            rs=q.job_ids
            return  {"job_id":rs}
        except:
            return  {"job_id":rs}

    if request.method=="POST":
            #try:
            args = request.args
            type=args.get("type")
            jid=args.get("id")
            res=request.get_json()
            #res=request.data
            #print(res)

            if("Cve" in type):
                cve=res["CVE"]
                obj=cvedb.VulnerableJAR(cve,jid,type)
            if("Analyse" in type):
                stcode=res["STCODE"]
                obj=stc.SCodeAnalyse(stcode,jid,type)
            if("Port" in type):
                port=res["Ports"]
                obj2=portscn.OpenPortScan(port,jid,type)
            if("Servlet" in type):
                servlets=res["Servlets"]
                obj3=sc.ServletScan(servlets,jid,type)
            if(type=="BlacklistIPScanning"):
                blacklisted_ip=res["BlacklistedIP"]
                obj4=bl.BlacklistedIP(blacklisted_ip,jid,"BLACKLISTEDIP")
            if(type=="SubdomainScanning"):
                subdomain=res["Subdomain"]
                obj=sd.SubdomainScan(subdomain,jid,"SUBDOMAIN")
            if(type=="NucleiAutomation"):
                nuclei=res["Nuclei"]
                obj=nu.NucleiAutomation(nuclei,jid,"NucleiAutomation")
            if(type=="Domain"):
                domain=res["Domain"]
                obj=sd.SubdomainScan(domain,jid,"Domain")

            return {"status":"updated"}
            #except:
            #return {"status":"not updated"}


@app.route('/api/job/status',methods=["GET","POST"])
def job_status():
    cwd=os.getcwd()+"/trigger/"
    if request.method=="GET":
        args = request.args
        task_id=args.get("id")
        task = q.fetch_job(task_id)

        '''
        with open(cwd+"nuclei_vulnerability.txt", "r") as f:
            temp = f.read().rstrip()
            #res.append(temp)
            r.set("s247_automation"+task.id,str(temp))
            ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
            tmp_res=str(r.get("s247_automation"+task.id))
            temp = ansi_escape.sub('', tmp_res)'''
        result=str(r.get("s247_automation"+task_id))
        low=result.count("low")
        medium=result.count("medium")
        high=result.count("high")
        critical=result.count("critical")
        if task:
            response_object = {
                "status": "success",
                "data": {
                    "task_id": task.get_id(),
                    "task_status": task.get_status(),
                    "s247_automation"+task_id: result,
                    "low": low,
                    "medium": medium,
                    "high": high,
                    "critical": critical
                }
            }
        else:
            response_object = {"status": "error"}
        #print(response_object)
        return response_object
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def isValidDomain(str):
    regex = "^((?!-)[A-Za-z0-9-]" +"{1,63}(?<!-)\\.)" +"+[A-Za-z]{2,6}"
    p = re.compile(regex)
    if(str.count(".")<=2):
        if (str == None):
            return False
        if(re.search(p, str)):
            return True
        else:
            return False
#============================================================================UPLOAD IMAGE======================================
@app.route('/upload', methods=['POST'])
def upload():
    # Get the image data from the request body
    image_data = request.data
    img_name=request.args.get("img_name")
    fold=request.args.get("fold")
    id=request.args.get("id") 
    url=request.args.get("url")
    os.system("mkdir -p /home/site24x7/Source/Screenshot/"+fold)
    # Save the image data to a file or process it in some other way
    with open("/home/site24x7/Source/Screenshot/"+fold+"/"+img_name, 'wb') as f:
        f.write(image_data)
    obj=db.Database()
    table="Upload"
    res=[img_name,url,image_data]
    result=obj.WriteDB(id,res,table)
    return result

@app.route('/api/add-domain',methods=["GET","POST"])
def Add_domain():
    if request.method=="POST":
        args = request.args
        res=request.get_json()

    if(res!=None and res!={}):
        k=res.keys()
        ln=len(k)
        if((ln==1 or ln==2) and ("domain-name" in k )):
            flg=isValidDomain(res["domain-name"])
            if(flg):
                id='job_id'+str(int(time.time()*1000))
                #check Database 
                obj=db.Database()
                obj.CreateDatabase()
                table="Domains"
                result=obj.WriteDB(id,res,table)
                '''domain=res["domain-name"]
                freq=1
                if("freq" in k):
                    freq=res["freq"]

                job=q.enqueue(dm.addDomain,args=(domain,freq,id),job_timeout=3600,job_id=id)
                q_len=len(q)
                r.set("Domain"+job.id,"")'''
                return result
            else:
                return  {"status":"Invalid Domain"}
        else:
            return {"status":"invalid data",
                    "data":{"add-domain":"","freq":""
                    }}

    return {"status":"Invalid Data"}

@app.route('/api/get-summary',methods=["GET","POST"])
def Get_Summary():
    if request.method=="GET":
        args = request.args
        code=args.get("code")

@app.route('/api/result',methods=["GET","POST"])
def StatusUpdate2():
    if request.method=="POST":
            args = request.args
            type=args.get("type")
            jid=args.get("id")
            res=request.get_json()
            print("true")
            if("Domain" in type):
                res=res["Domain"]
                obj=db.Database()
                table="StoreDB"
                result=obj.WriteDB(jid,res,table)
            return {"status":"success"}
    else:
        return {"status":"GET"}
                
@app.route('/api/job/getID',methods=["GET","POST"])
def getID():
    if request.method=="GET":
            args = request.args
            domain=args.get("domain")
            obj=db.Database()
            table="GetID"
            print(domain)
            id=obj.ReadDB(domain,table)
            
    return {"ID":id}

@app.route('/api/job/getCron',methods=["GET","POST"])
def getCron():
    if request.method=="GET":
            args = request.args
            obj=db.Database()
            table="GetCron"
            data=obj.ReadDB("",table)

    return {"data":data}

@app.route('/api/domain/list',methods=["GET","POST"])
def getSummary():
    if request.method=="GET":
            args = request.args
            obj=db.Database()
            table="Summary"
            result=obj.ReadDB("",table)
    return {"result":result}

@app.route('/api/assets/<section>',methods=["GET","POST"])
def Assets(section):
    if request.method=="GET":
            assert section == request.view_args['section']
            job_id=section
            obj=db.Database()
            table="Assets"
            print(job_id)
            result=obj.ReadDB(job_id,table)
    return result

@app.route('/api/add/subscribe',methods=["GET","POST"])
def addSubscriber():
    if request.method=="POST":
            args = request.args
            res=request.get_json()
            data=res
            print(res)
            obj=db.Database()
            table="Subscriber"
            result=obj.WriteDB("",data,table)

    return {"result":result}
@app.route('/api/agent',methods=["GET","POST"])
def Agent():
    if request.method=="GET":
            data={}
            args = request.args
            type=args.get("type")
            if(type=="LinuxAgent"):
                cve_url=url_domain+"/show/automation/result?value=LINUX_AGENT_CVE"
                req=requests.get(cve_url)
                cve_data=req.text
                #cve_data=result("LINUX_AGENT_CVE")
                #print("cve_data....",cve_data)
                servlet_url=url_domain+"/show/automation/result?value=LINUX_AGENT_SERVLETS"
                req=requests.get(servlet_url)
                servlet_data=req.text
                data["cve"]=cve_data
                data["servlet"]=servlet_data
            if(type=="LinuxPoller"):
                cve_url=url_domain+"/show/automation/result?value=LINUX_POLLER_CVE"
                req=requests.get(cve_url)
                cve_data=req.text
                servlet_url=url_domain+"/show/automation/result?value=LINUX_POLLER_SERVLETS"
                req=requests.get(servlet_url)
                servlet_data=req.text
                data["cve"]=cve_data
                data["servlet"]=servlet_data
            if(type=="WindowsPoller"):
                cve_url=url_domain+"/show/automation/result?value=WIN_POLLER_CVE"
                req=requests.get(cve_url)
                cve_data=req.text
                servlet_url=url_domain+"/show/automation/result?value=WIN_POLLER_SERVLETS"
                req=requests.get(servlet_url)
                servlet_data=req.text
                data["cve"]=cve_data
                data["servlet"]=servlet_data
            if(type=="WindowsAgent"):
                cve_url=url_domain+"/show/automation/result?value=WIN_AGENT_CVE"
                req=requests.get(cve_url)
                cve_data=req.text
                servlet_url=url_domain+"/show/automation/result?value=WIN_AGENT_SERVLETS"
                req=requests.get(servlet_url)
                servlet_data=req.text
                data["cve"]=cve_data
                data["servlet"]=servlet_data
            return data

@app.route('/api/get/subscribe',methods=["GET","POST"])   
def getSubscriber():
    if request.method=="GET":
        obj=db.Database()
        table="GetSubscriber"
        result=obj.ReadDB("",table)
    return {"data":result}

def UpdateJobSchedule():
    print("Add All Scheduled Jobs to Scheduler...")
    obj=db2.Database()
    mydb=obj.CreateDatabase()
    mydb1=obj.Automation()
    mydb=[mydb,mydb1]
    obj=au.ScheduledJobs()
    Jobs=obj.res
    for job in Jobs:
        Job_Type=job[0]
        Scheduled_day=job[1]
        Scheduled_time=job[2]
        Scheduled_hour=job[3]
        Scheduled_minute=job[4]
        Scheduled_everyday=job[5]
        if(Scheduled_day=="null"):
            Scheduled_day=""
        if(Scheduled_time=="null"):
            Scheduled_time=""
        if(Scheduled_hour=="null"):
            Scheduled_hour=""
        if(Scheduled_everyday=="null"):
            Scheduled_everyday=""
        if(Scheduled_minute=="null"):
            Scheduled_minute=""
        else:
            Scheduled_minute=int(Scheduled_minute)
        res=js.ScheduleJobs(Job_Type,Scheduled_day,Scheduled_time,Scheduled_hour,Scheduled_minute,Scheduled_everyday)


UpdateJobSchedule()

if __name__  == "__main__":
    app.run(debug=True)
