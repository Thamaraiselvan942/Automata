from turtle import title
import mysql.connector
import datetime
import trigger.Generate_Access_Token as gen
import requests
import Server.db.Database2 as db2
class Report():
    def ReadDBConnect(self,mydb,sql):
            mycursor = mydb.cursor() 
            mycursor.execute(sql)
            res=mycursor.fetchall()
            return list(res[0])[0]
    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,typ,newtag):
        access_token=gen.Getaccess_token()
        self.date=str(datetime.date.today())
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        ulf="<ul>"
        ull="</ul>"
        lif="<li>"
        lil="</li>"
        cve=""
        port=""
        servlet=""

        #new_cve=""
        #new_port=""
        #new_servlet=""

        obj=db2.Database()
        mydb=obj.CreateDatabase()
        tag=""
        ntag=""
        tmp=""
        Refer=""
        if(typ=="Win_Poller_Cve"):
            cve=self.ReadDBConnect(mydb,"select count(*) from  WIN_POLLER_CVE")
            #new_cve=self.ReadDBConnect(mydb,"select count(*) from  WIN_POLLER_CVE where date="+'"'+self.date+'"')
            tag="Total CVE: "+str(cve)
            tmp="Windows Poller"
            Refer="http://52.140.3.229:8080/show/automation/result?value=WIN_POLLER_CVE"
            ntag="New CVE: "+str(newtag)
        elif(typ=="Win_Poller_Servlet"):
            servlet=self.ReadDBConnect(mydb,"select count(*) from  WIN_POLLER_SERVLETS")
            #new_servlet=self.ReadDBConnect(mydb,"select count(*) from  WIN_POLLER_SERVLETS where date="+'"'+self.date+'"')
            tag="Total Servlets: "+str(servlet)
            tmp="Windows Poller"
            Refer="http://52.140.3.229:8080/show/automation/result?value=WIN_POLLER_SERVLETS"
            ntag="New Servlets: "+str(newtag)
        elif(typ=="Win_Poller_Port"):
            port=self.ReadDBConnect(mydb,"select count(*) from  WIN_POLLER_OPENPORT")
            #new_port=self.ReadDBConnect(mydb,"select count(*) from  WIN_POLLER_OPENPORT where date="+'"'+self.date+'"')
            tag="Total Ports: "+str(port)
            tmp="Windows Poller"
            Refer="http://52.140.3.229:8080/show/automation/result?value=WIN_POLLER_OPENPORT"
            ntag="New Ports: "+str(newtag)
        #--------------------------------------------------------------------------------------
        elif(typ=="Lin_Poller_Cve"):
            cve=self.ReadDBConnect(mydb,"select count(*) from  LINUX_POLLER_CVE")
            #new_cve=self.ReadDBConnect(mydb,"select count(*) from  LINUX_POLLER_CVE where date="+'"'+self.date+'"')
            tag="Total CVE: "+str(cve)
            tmp="Linux Poller"
            Refer="http://52.140.3.229:8080/show/automation/result?value=LINUX_POLLER_CVE"
            ntag="New CVE: "+str(newtag)
        elif(typ=="Lin_Poller_Servlet"):
            servlet=self.ReadDBConnect(mydb,"select count(*) from  LINUX_POLLER_SERVLETS")
            #new_servlet=self.ReadDBConnect(mydb,"select count(*) from  LINUX_POLLER_SERVLETS where date="+'"'+self.date+'"')
            tag="Total Servlets: "+str(servlet)
            tmp="Linux Poller"
            Refer="http://52.140.3.229:8080/show/automation/result?value=LINUX_POLLER_SERVLETS"
            ntag="New Servlets: "+str(newtag)
        elif(typ=="Lin_Poller_Port"):
            port=self.ReadDBConnect(mydb,"select count(*) from  LINUX_POLLER_OPENPORT")
            #new_port=self.ReadDBConnect(mydb,"select count(*) from  LINUX_POLLER_OPENPORT where date="+'"'+self.date+'"')
            tag="Total Ports: "+str(port)
            tmp="Linux Poller"
            Refer="http://52.140.3.229:8080/show/automation/result?value=LINUX_POLLER_OPENPORT"
            ntag="New Ports: "+str(newtag)
        
        #---------------------------------------------------------------------------------------
        elif(typ=="Win_Agent_Cve"):
            cve=self.ReadDBConnect(mydb,"select count(*) from  WIN_AGENT_CVE")
            #new_cve=self.ReadDBConnect(mydb,"select count(*) from  WIN_Agent_CVE where date="+'"'+self.date+'"')
            tag="Total CVE: "+str(cve)
            tmp="Windows Agent"
            Refer="http://52.140.3.229:8080/show/automation/result?value=WIN_Agent_CVET"
            ntag="New CVE: "+str(newtag)
        elif(typ=="Win_Agent_Servlet"):
            servlet=self.ReadDBConnect(mydb,"select count(*) from  WIN_AGENT_SERVLETS")
            #new_servlet=self.ReadDBConnect(mydb,"select count(*) from  WIN_AGENT_SERVLETS where date="+'"'+self.date+'"')
            tag="Total Servlets: "+str(servlet)
            tmp="Windows Agent"
            Refer="http://52.140.3.229:8080/show/automation/result?value=WIN_AGENT_SERVLETS"
            ntag="New Servlets: "+str(newtag)
        elif(typ=="Win_Agent_Port"):
            port=self.ReadDBConnect(mydb,"select count(*) from  WIN_AGENT_OPENPORT")
            #new_port=self.ReadDBConnect(mydb,"select count(*) from  WIN_AGENT_OPENPORT where date="+'"'+self.date+'"')
            tag="Total Ports: "+str(port)
            tmp="Windows Agent"
            Refer="http://52.140.3.229:8080/show/automation/result?value=WIN_AGENT_OPENPORT"
            ntag="New Ports: "+str(newtag)

        #--------------------------------------------------------------------------------------
        elif(typ=="Lin_Agent_Cve"):
            cve=self.ReadDBConnect(mydb,"select count(*) from  LINUX_AGENT_CVE")
            #new_cve=self.ReadDBConnect(mydb,"select count(*) from  LINUX_AGENT_CVE where date="+'"'+self.date+'"')
            tag="Total CVE: "+str(cve)
            tmp="Linux Agent"
            Refer="http://52.140.3.229:8080/show/automation/result?value=LINUX_AGENT_CVE"
            ntag="New CVE: "+str(newtag)
        elif(typ=="Lin_Agent_Servlet"):
            servlet=self.ReadDBConnect(mydb,"select count(*) from  LINUX_AGENT_SERVLETS")
            #new_servlet=self.ReadDBConnect(mydb,"select count(*) from  LINUX_AGENT_SERVLETS where date="+'"'+self.date+'"')
            tag="Total Servlets: "+str(servlet)
            tmp="Linux Agent"
            Refer="http://52.140.3.229:8080/show/automation/result?value=LINUX_AGENT_SERVLETS"
            ntag="New Servlets: "+str(newtag)
        elif(typ=="Lin_Agent_Port"):
            port=self.ReadDBConnect(mydb,"select count(*) from  LINUX_AGENT_OPENPORT")
            #new_port=self.ReadDBConnect(mydb,"select count(*) from  LINUX_AGENT_OPENPORT where date="+'"'+self.date+'"')
            tag="Total Ports: "+str(port)
            tmp="Linux Agent"
            Refer="http://52.140.3.229:8080/show/automation/result?value=LINUX_AGENT_OPENPORT"
            ntag="New Ports: "+str(newtag)
        

        res=""
        if(newtag!=0):
            title=bf+tmp+bl
            res=title+olf+lif+tag+lil+lif+ntag+lil+oll+bf+"Refer: "+Refer+bl
        if(res!=""):
            url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+res+"&streamTitle=Security Automation Results For "+tmp
            res=requests.post(url,headers=headers)
       
            
