import subprocess
import requests
import mysql.connector
import trigger.Generate_Access_Token as gen
import Server.db.Database2 as db2
class BlacklistedIP():
    
    def __init__(self,blacklistedIp,jid,Type):
        self.blacklistedIP=blacklistedIp
        self.new_res={}
        self.type=Type
        obj=db2.Database()
        mydb=obj.CreateDatabase()
        mydb1=obj.Automation()
        mydb=[mydb,mydb1]
        res=obj.WriteDB(self.blacklistedIP,jid,None,mydb,None,self.type)
        self.new_res=res
        self.UpdateConnect(self.new_res)
        

    #UPDATE THE RESULT IN CONNECT
    def UpdateConnect(self,new_res):
        access_token=gen.Getaccess_token()
        access_token="Zoho-oauthtoken "+access_token
        headers = {'Content-Type': 'application/json','Authorization':access_token}
        bf="<b>"
        bl="</b>"
        olf="<ol>"
        oll="</ol>"
        lif="<li>"
        lil="</li>"
        ulf="<ul>"
        ull="</ul>"
        #title=bf+"DependencyName"+(" "*10)+"CVE"+(" "*10)+"CWE"+(" "*50)+"CVSS_Severity"+(" "*10)+"CVSS_Score"+(" "*10)+"Type"+bl
        title1=bf+"Total Blacklisted IP"
        title2=bf+"New Blacklisted IP"
        obj=db2.Database()
        mydb=obj.CreateDatabase()
        r=obj.ReadDBConnect(mydb,self.type)
        c=0
        exist_count=list(r[0])[0]
        curr_count=len(new_res.keys())
        new_ip=new_res.keys()
        new_blis=new_res.values()
        fres=""
        con=""
        for ip,blis in new_res.items():
            c+=1
            if(c==400):
                break
            con=bf+ulf+lif+ip+lil+ull+bl #bold ip
            rs=olf
            for bls in blis:
                rs=rs+lif+bls+lil
            rs+=oll
            fres=fres+con+rs
        if(curr_count!=0):
            content=title1+bl+ulf+lif+str(exist_count)+lil+ull+title2+bl+fres
            #content=title1+bl+olf+lif+str(exist_count)+lil+oll+title2+bl+olf+lif+str(curr_count)+lil+oll
            url="https://connect.zoho.com/pulse/api/v2/addStream?scopeID=105000017039001&partitionID=105000666512885&streamContent="+content+"&streamTitle=Security Automation Results For Blacklisted_IP Scanning" 
            print(content)
            res=requests.post(url,headers=headers)
            print(res.text)
        



    



                
