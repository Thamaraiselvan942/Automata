var app = angular.module('asm.app', ['ui.router', 'chart.js']); 
var url_domain="http://172.20.10.4:8080"
app.config(['$stateProvider', '$urlRouterProvider','ChartJsProvider', function($stateProvider, $urlRouterProvider, ChartJsProvider){ 
	(function (ChartJsProvider) {
  		ChartJsProvider.setOptions({ colors : [ '#803690', '#00ADF9', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'] });
	});

	$urlRouterProvider.when('', '/domains/list');//NO I18N

  var domainState = {
    name: 'domains',
    url: '/domains/list',
    templateUrl: 'templates/domains.html'
  }

  var addDomainState = {
    name: 'add-domain',
    url: '/domains/add',
    templateUrl: 'templates/add-domain.html',
    controller: "AddDomainController"
  }

  var domainDetails = {
  	name: 'domain-details',
    url: '/domains/:domain_id',
    templateUrl: 'templates/domain-details.html',
    controller: "DomainDetailsController"
  }

  var addSubscriberState = {
  	name: 'add-subscriber',
    url: '/subscribers/add',
    templateUrl: 'templates/add-subscribers.html',
    controller: "AddSubscriberController"
  }

  var subscribersListState = {
  	name: 'list-subscriber',
    url: '/subscribers/list',
    templateUrl: 'templates/subscribers-list.html',
    controller: "ListSubscriberController"
  }
 var linuxagent = {
    name: 'linuxagent',
    url: '/linuxagent/list',
    templateUrl: 'templates/lin-agent.html',
    controller: "LinuxAgentController"
  }
  var windowsagent = {
    name: 'windowsagent',
    url: '/windowsagent/list',
    templateUrl: 'templates/win-agent.html',
    controller: "WindowsAgentController"
  }
var linuxpoller = {
    name: 'linuxpoller',
    url: '/linuxpoller/list',
    templateUrl: 'templates/lin-poller.html',
    controller: "LinuxPollerController"
  }
var windowspoller = {
    name: 'windowspoller',
    url: '/windowspoller/list',
    templateUrl: 'templates/win-poller.html',
    controller: "WindowsPollerController"
  }
 var gitasset = {
    name: 'gitasset',
    url: '/git_assets/list',
    templateUrl: 'templates/gitassets.html',
    controller: "GitController"
  }
 var gdorks = {
    name: 'gdorks',
    url: '/gdorks/<img src=x>',
    templateUrl: 'templates/gdorks.html',
    controller: "GDorksController"
  }
  $stateProvider.state(domainState);
  $stateProvider.state(domainDetails);
  $stateProvider.state(addDomainState);
  $stateProvider.state(addSubscriberState);
  $stateProvider.state(subscribersListState);
  $stateProvider.state(linuxagent);
  $stateProvider.state(linuxpoller);
  $stateProvider.state(windowsagent);
  $stateProvider.state(windowspoller);
  $stateProvider.state(gitasset);
  $stateProvider.state(gdorks);
}]);


app.controller('AppController', ['$scope', '$stateParams', '$http', function($scope, $stateParams, $http) {
	$scope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];

  $scope.title = "Domains secured by Site24x7 EASM";
  $scope.sub_title = "Secure your Domain by adding it to our EASM";
  $scope.action_link = "/index.html#!/domains/add";
  $scope.action_text = "Add a Domain";

	$scope.processing = true;
	$http.get(url_domain+'/api/domain/list').then(function(response){
		$scope.processing = false;
         //handle your response here
         $scope.domains = response.data.result;
    });

	// $scope.domain_details = {
	// 	"domain_id": 1, 
	// 	"domain_name": "site24x7.com", 
	// 	"repetition": "Everyday at 10 AM",
	// 	"subdomain_count": 10,
	// 	"alive_count": 5,
	// 	"ports_count": 100,
	// 	"vulnerabilities":{
	// 		"info": 1,
	// 		"low": 2,
	// 		"medium": 3, 
	// 		"high": 4, 
	// 		"critical": 5
	// 	},
	// 	"vulnerability_details":[
	// 		{
	// 			"vuln_asset": "https://www.site24x7.jp", 
	// 			"vuln_severiy": "info", 
	// 			"vuln_protocol": "http",
	// 			"vuln_name": "openssl-detect", 
	// 			"vuln_service": "OpenSSL/1.0.2k"
	// 		},
	// 		{
	// 			"vuln_asset": "https://18.140.106.135", 
	// 			"vuln_severiy": "info", 
	// 			"vuln_protocol": "http",
	// 			"vuln_name": "apache-detect", 
	// 			"vuln_service": "Apache"
	// 		}
	// 	],
	// 	"port_details":[
	// 		{
	// 		  "ip": "117.20.43.49",
	// 		  "port": 443,
	// 		  "service": "https",
	// 		  "version": "Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.4.9"
	// 		}
	// 	], 
	// 	"histogram":[
	// 		""
	// 	]
	// }
 //  $scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
 //  $scope.series = ['Series A', 'Series B'];
 //  $scope.data = [
 //    [65, 59, 80, 81, 56, 55, 40],
 //    [28, 48, 40, 19, 86, 27, 90]
 //  ];
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  $scope.options = {
    scales: {
      yAxes: [
        {
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left'
        },
        {
          id: 'y-axis-2',
          type: 'linear',
          display: true,
          position: 'right'
        }
      ]
    }
  };


  $scope.pie_labels =["Critical", "High", "Medium", "Low", "Info"];

  $scope.pie_data = [
    [1, 2, 3, 4, 5]
  ];


}]);

app.controller('DomainDetailsController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
  //$scope.domain_name = "";

  $scope.processing = true;
  var domain_id = $stateParams.domain_id
  $http.get(url_domain+'/api/assets/' + domain_id).then(function(response){
      $scope.processing = false;
      console.log(response.data);
      $scope.result = response.data;
      $scope.domain_name = $scope.result.domain_name;
      $scope.last_run = $scope.result.last_run;
      $scope.port_details = $scope.result.port_details;
      $scope.port_count = $scope.result.port_count;
      $scope.dork_count = $scope.result.dorks_count;
      $scope.sub_domains = $scope.result.sub_domains;
      $scope.vuln_detials = $scope.result.vuln_detials;
      $scope.fuzzing= $scope.result.fuzz_details;
      $scope.vulnerabilitiesCount = $scope.result.vulnerabilities;
      $scope.repetition = $scope.result.repetition;
      $scope.labels = $scope.result.asset_history.label;
      $scope.series = $scope.result.asset_history.series;
      $scope.data = $scope.result.asset_history.data;

      $scope.title = "Attack Surface of " + $scope.result.domain_name

    });
  $scope.addDomain = function(domain_name){
    postdata = {"domain-name": domain_name};
    $scope.processing = true;
    $http.post(url_domain+'/api/add-domain', postdata).then(function(response){
      $scope.processing = false;
          alert(response.data.status);
      });
}
  $http.get(url_domain+'/get_data/dorks?id='+domain_id).then(function(response){
    $scope.processing = false;
    $scope.dorks = response.data["dork"]
   });


}]);

app.controller('AddDomainController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
	//$scope.domain_name = "";
	$scope.processing = false;
	$scope.addDomain = function(domain_name){
		postdata = {"domain-name": domain_name};
		$scope.processing = true;
		$http.post(url_domain+'/api/add-domain', postdata).then(function(response){
			$scope.processing = false;
	        alert(response.data.status);
    	});
	}

}]);


app.controller('AddSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
	//$scope.domain_name = "";
	$scope.processing = false;
  $http.get(url_domain+'/api/domain/list').then(function(response){
    $scope.processing = false;
         //handle your response here
         $scope.domains = response.data.result;
    });

  $scope.addSubscriber= function(mobile, selected_domains, selected_categories){
   //postdata = {"mobile":mobile,"domains":selected_domains,"categories":selected_categories };
   postdata={"Phone":mobile,"Subscribe":[]}
   var arr=[];
   //var obj={"domain":"","asset":0,"low":0,"info":0,"high":0,"medium":0,"critical":0}
    var asset=0;
    var low=0;
    var medium=0;
    var critical=0;
    var high=0;
    var info=0;
   if (selected_categories.indexOf('New Asset') > -1) {
         asset=1;

    }
   if (selected_categories.indexOf('New High Vulnrability') > -1) {
         high=1;

   }
   if (selected_categories.indexOf('New Medium Vulnrability') > -1) {
         medium=1;

    }
   if (selected_categories.indexOf('New Critical Vulnrability') > -1) {
         critical=1;

    }
   if (selected_categories.indexOf('New Low Vulnrability') > -1) {
         low=1;

    }
   if (selected_categories.indexOf('New Info Vulnrability') > -1) {
         info=1;

    }


   for (var domain of selected_domains) {
         var obj={"domain":domain,"asset":asset,"low":low,"info":info,"high":high,"medium":medium,"critical":critical};
         arr.push(obj);

  }
postdata.Subscribe=arr

   //alert(postdata)/api/add/subscribe
   $scope.processing = true;
   $http.post(url_domain+'/api/add/subscribe', postdata).then(function(response){
   $scope.processing = false;
   alert(response.result.status);
});
  }


	$scope.addDomain = function(domain_name){
		postdata = {"domain-name": domain_name};
		$scope.processing = true;
		$http.post(url_domain+'/api/add-domain', postdata).then(function(response){
			$scope.processing = false;
	        alert(response.data.status);
    	});
	}

}]);
app.controller('ListSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
	//$scope.domain_name = "";
	$scope.processing = false;
  $http.get(url_domain+'/api/get/subscribe').then(function(response){
    $scope.processing = false;
         $scope.subscribers = response.data.data;
 });

}]);
app.controller('GitController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/get_data/github').then(function(response){
    $scope.processing = false;
         $scope.contrib_repo = response.data.site24x7["contrib_repo"];
         $scope.org_repo = response.data.site24x7["org_repo"];
         //alert(response.data.site24x7["contrib_repo"]);
 });

}]);
app.controller('GDorksController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = true;
        var domain_id = $stateParams.domain_id;
        alert(domain_id);
  $http.get(url_domain+'/get_data/dorks?id='+domain_id).then(function(response){
    $scope.processing = false;
         $scope.dorks = response.data
         alert(response.data["count"]);
 });

}]);

app.controller('ListSubscriberController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/get/subscribe').then(function(response){
    $scope.processing = false;
         $scope.subscribers = response.data.data;
 });

}])

app.controller('LinuxAgentController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/agent?type=LinuxAgent').then(function(response){
    $scope.processing = false;
         $scope.linux_cve = JSON.parse(response.data.cve)["data"];
         $scope.linux_servlet=JSON.parse(response.data.servlet)["data"];
         //alert($scope.linux_servlet)
 });

}])

app.controller('LinuxPollerController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/agent?type=LinuxPoller').then(function(response){
    $scope.processing = false;
         $scope.linuxpoller_cve = JSON.parse(response.data.cve)["data"];
         $scope.linuxpoller_servlet=JSON.parse(response.data.servlet)["data"];
         //alert($scope.linux_servlet)
 });

}])
//-----------------------------------------------------------------------------------------------------------------------
app.controller('WindowsAgentController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/agent?type=WindowsAgent').then(function(response){
    $scope.processing = false;
         $scope.windows_cve = JSON.parse(response.data.cve)["data"];
         $scope.windows_servlet=JSON.parse(response.data.servlet)["data"];
         //alert($scope.linux_servlet)
 });

}])

app.controller('WindowsPollerController', ['$scope', '$stateParams', '$http',function($scope, $stateParams, $http) {
        //$scope.domain_name = "";
        $scope.processing = false;
  $http.get(url_domain+'/api/agent?type=WindowsPoller').then(function(response){
    $scope.processing = false;
         $scope.windowspoller_cve = JSON.parse(response.data.cve)["data"];
         $scope.windowspoller_servlet=JSON.parse(response.data.servlet)["data"];

         //alert($scope.linux_servlet)
 });

}])

