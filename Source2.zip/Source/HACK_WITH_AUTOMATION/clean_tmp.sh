sudo rm -rf /tmp/*
