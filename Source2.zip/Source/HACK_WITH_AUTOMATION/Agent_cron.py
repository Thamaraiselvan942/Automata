import os
import requests
import schedule
import time
url_domain="http://172.20.10.4:8080/"
def addCronJob():
    url=url_domain+"/api/job/getCron"
    res=requests.get(url)
    data=res.json()
    data=data["data"]
    print(data)
    cwd=os.getcwd()+"/"

    if(data!=[]):
        for domain in data:
            cmd="bash "+cwd+"script.sh "+domain
            a=os.popen("crontab -l").read()
            r=a.split("\n")
            r=r[0]
            r=r.split()
            r=int(r[1])
            time=0
            if(r!=23):
                time=r%24+1
            minute="0 "
            hour=str(time)+" "
            day_month="* "
            month="* "
            week_day="* "

            date_time="'"+minute+hour+day_month+month+week_day+cmd+"'"
            cmd1="echo "+'"'+"$(echo "+date_time+" ; crontab -l 2>&1)"+'"'+" | crontab -"
            print(cmd1)
            os.system(cmd1)
        #for domain in data:
            #os.system("python3 Agent.py "+domain)
    else:
        print("domain not added yet")


schedule.every(4).minutes.do(addCronJob)
while True:
    schedule.run_pending()
    time.sleep(1)
