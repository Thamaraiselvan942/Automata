import os
import subprocess
def Nuclei_Automation(access_token,s247_url):
    access_token='access_token= '+access_token
    p1 = subprocess.run(['nuclei', '-u', s247_url,'-var', access_token , '-t','add_website_monitor.yaml','-p','http://192.168.100.100:3128/'], stdout=subprocess.PIPE)
    content = p1.stdout.decode("utf-8")
    print(content)
    if("info" in content):
        file=open("output2.txt","a")
        file.write(content)
    elif(len(content)==0):
        print("better luck next time")
    else:
        file=open("output.txt","a")
        file.write(content)

#Nuclei_Automation("1000.2ca70fe60e5c7e236134df5aa442e63a.121b36fa0102da1b627e091732689824","https://www.site24x7.eu")
#nuclei -t add_website_monitor.yaml -u https://www.site24x7.eu -var access_token="1000.2ca70fe60e5c7e236134df5aa442e63a.121b36fa0102da1b627e091732689824" -p http://192.168.100.100:3128 
