import json
import requests
import os
import sys
url_domain="http://172.20.10.4:8080/"
'''
site24x7-org.txt -org repo
site24x7-employees.txt -employee name
site24x7-contributors-repos.txt contrib-repo
'''
cwd=os.getcwd()
cwd="/media/sf_Workspace/Source/dorks/results/"
domain=sys.argv[1]
res={}
if(domain!=""):
    f=open(cwd+domain+".txt","r")
    data=f.readlines()
if(len(data)>0):
    res[domain]=data

res["count"]=len(data)
#print(res)
def addDomain(domain):
    getid=url_domain+"api/job/getID?domain="+domain
    id=requests.get(getid)
    id=id.json()
    print(id)
    id=id["ID"]
    if(id!=""):
        api=url_domain+"post_data/dorks?id="+id
        resp=requests.post(api,json=res)
        print(resp)

addDomain(domain)
