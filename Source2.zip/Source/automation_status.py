import traceback
import requests
import json
import time

url="http://192.168.203.60:8080/api/job/start"
params1={
          "url":"https://s247.localsite24x7.com",
          "plus_host": "https://s247plus.localsite24x7.com",
          "type": "qa_automation",

         }

proxies = {
   'http': 'http://192.168.100.100:3128/',
   'https': 'http://192.168.100.100:3128/'
}

response1 = requests.get(url, params=params1)
txt=response1.text
print(txt)
sind=txt.index(" ")+1
rs=txt[sind:]
eind=rs.index(" ")
res=rs[:eind]
params2 = {
          'id': res,
          }

while(True):
    try:
      response = requests.get('http://52.140.3.229:8080/api/job/status', params=params2)
      res=response.json()
      if("data" in res.keys()):
          key=res["data"].keys()
      status=""
      if(res["status"]=="error"):
        print("error occured...")
        break
      else:
        if("task_status" in key):
          status=res["data"]["task_status"]
        if(status=="finished" ):
          print("Task finished...")
          break
        elif(status=="failed"):
          print("Task failed...")
          break

      print(res['status'])
      time.sleep(10)
    except:
      print("Exception occured...")
      traceback.print_exc()
      break
