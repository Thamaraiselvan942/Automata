from threading import current_thread
from tkinter import NE
import mysql.connector
import datetime
import json
import requests
from datetime import date, timedelta
class Database():
    #CONNECT DATABASE
    def __init__(self):
        self.date=str(datetime.date.today())
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Arjun@123",
        )     
    def CreateDatabase(self):
        mycursor = self.mydb.cursor()
        #Create  APIINFO Database
        mycursor.execute("CREATE DATABASE IF NOT EXISTS Domain_Automation")
        mycursor.execute("USE Domain_Automation")
        #Update Job Status
        mycursor.execute("CREATE TABLE IF NOT EXISTS Domains(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(200), Frequency int,DateTime  timestamp NULL DEFAULT CURRENT_TIMESTAMP,LastRun  timestamp NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(Domain))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS SubDomains (Job_Id VARCHAR(50) NOT NULL ,SubDomain VARCHAR(200), Alive VARCHAR(10),LastRun  timestamp NULL DEFAULT CURRENT_TIMESTAMP)")
        mycursor.execute("CREATE TABLE IF NOT EXISTS Ports (Job_Id VARCHAR(50) NOT NULL , IP VARCHAR(20), Port VARCHAR(10), Service VARCHAR(500), Version VARCHAR(20),LastRun  timestamp NULL DEFAULT CURRENT_TIMESTAMP)")
        mycursor.execute("CREATE TABLE IF NOT EXISTS Vulnerabilities (Job_Id VARCHAR(50) NOT NULL ,IssueType VARCHAR(200), Severity VARCHAR(50),Url VARCHAR(1000),LastRun  timestamp NULL DEFAULT CURRENT_TIMESTAMP)")
        #Create Table For BlacklistedIP
    def AssetHistory(self,job_id):
        last_date={}
        last_date[str(date.today())]=0
        tmp_date=[str(date.today())]
        for i in range(1,7):
            dt = date.today() - timedelta(i)
            last_date[str(dt)]=0
            tmp_date.append(str(dt))
        
        fres={"asset_history": {
  	    "label": tmp_date,
  	    "series": ['Sub Domain Count', 'Ports Count', 'Vuln Count'],
  	    "data": [
  		[],
    	[],
    	[]
    	]}
        }

        sql1='select Distinct(LastRun) from SubDomains  where Job_Id='+'"'+job_id+'"'+' and LastRun > now() - INTERVAL 7 day'
        sql2='select Distinct(LastRun) from Ports  where Job_Id='+'"'+job_id+'"'+' and LastRun > now() - INTERVAL 7 day'
        sql3='select Distinct(LastRun) from Vulnerabilities  where Job_Id='+'"'+job_id+'"'+' and LastRun > now() - INTERVAL 7 day'
        mycursor = self.mydb.cursor()
        mycursor.execute("USE Domain_Automation")
        mycursor.execute(sql1)
        res=mycursor.fetchall()
        sub_res=list(res)
        mycursor.execute(sql2)
        res2=mycursor.fetchall()
        sub_res2=list(res2)
        mycursor.execute(sql3)
        res3=mycursor.fetchall()
        sub_res3=list(res3)
        #print(sub_res)
        tmp1=last_date.copy()
        tmp2=last_date.copy()
        tmp3=last_date.copy()
        for i in sub_res:
            dat=str(list(i)[0])
            mydate=dat.split(" ")[0]
            dcount='select count(SubDomain) from SubDomains  where LastRun='+'"'+dat+'"'
            mycursor.execute(dcount)
            res=mycursor.fetchall()
            r=list(res)[0]
            r=int(list(r)[0])
            if(mydate not in tmp1.keys()):
                tmp1[mydate]=r
            else:
                tmp1[mydate]+=r
        for value in tmp1.values():
            fres["asset_history"]["data"][0].append(value)
        #=================================================================================================================================
        for i in sub_res2:
            dat=str(list(i)[0])
            mydate=dat.split(" ")[0]
            dcount='select count(Port) from Ports  where LastRun='+'"'+dat+'"'
            mycursor.execute(dcount)
            res=mycursor.fetchall()
            r=list(res)[0]
            r=int(list(r)[0])
            if(mydate not in tmp2.keys()):
                tmp2[mydate]=r
            else:
                tmp2[mydate]+=r
        for value in tmp2.values():
            fres["asset_history"]["data"][1].append(value)

        #===================================================================================================================================
        for i in sub_res3:
            dat=str(list(i)[0])
            mydate=dat.split(" ")[0]
            dcount='select count(Severity) from Vulnerabilities  where LastRun='+'"'+dat+'"'
            mycursor.execute(dcount)
            res=mycursor.fetchall()
            r=list(res)[0]
            r=int(list(r)[0])
            if(mydate not in tmp3.keys()):
                tmp3[mydate]=r
            else:
                tmp3[mydate]+=r
        for value in tmp3.values():
            fres["asset_history"]["data"][2].append(value)

        return fres

            


        

        


    def Ports(self,job_id):
        sql="SELECT * from Ports where Job_Id="+'"'+job_id+'"'
        mycursor = self.mydb.cursor()
        mycursor.execute("USE Domain_Automation")
        mycursor.execute(sql)
        res=mycursor.fetchall()
        res=list(res)
        fdata={"port_details": []}
        result=[]
        for i  in res:
            data={
                "ip": "",
                "port": 0,
                "service": "",
                "version": ""
                }

            ls=list(i)
            print(ls)
            data["ip"]=ls[1]
            data["port"]=ls[2]
            data["service"]=ls[3]
            data["version"]=ls[4]
            result.append(data)
        return result

    def Vuln(self,job_id):
        print(job_id)
        sql="SELECT * from Vulnerabilities where Job_Id="+'"'+job_id+'"'
        mycursor = self.mydb.cursor()
        mycursor.execute("USE Domain_Automation")
        mycursor.execute(sql)
        res=mycursor.fetchall()
        res=list(res)
        #('job_id1668576729524', 'add_server_agent', 'info', 'https://www.site24x7.cn/api/resource_profile', datetime.datetime(2022, 11, 16, 11, 2, 9))
        fdata={"vuln_details": []}
        result=[]
        for i  in res:
            data={
                "vuln_asset": "",
                "vuln_severity": "",
                "vuln_protocol": "http",
                "vuln_name": "",
                "vuln_service": ""
                } 
            ls=list(i)
            data["vuln_asset"]=ls[3]
            data["vuln_severity"]=ls[2]
            data["vuln_name"]=ls[1]
            data["vuln_service"]=""
            result.append(data)
        return result


            
    def Subdomain(self,job_id):
        sql="SELECT * from SubDomains where Job_Id="+'"'+job_id+'"'
        mycursor = self.mydb.cursor()
        mycursor.execute("USE Domain_Automation")
        mycursor.execute(sql)
        res=mycursor.fetchall()
        res=list(res)
        fdata={"sub_domains":[]}
        result=[]
        for i  in res:
            data={"name": "", "is_active": False}
            ls=list(i)
            print(ls)
            data["name"]=ls[1]
            if(ls[2]=="Yes"):
                data["is_active"]=True
            else:
                data["is_active"]=False
            result.append(data)
       
        return result

    def Summary(self,job_id):
        result=[]
        #count Alives
        alives='select distinct(Domains.Job_Id),Domains.Domain,count(SubDomains.SubDomain),Domains.LastRun  from Domains LEFT JOIN SubDomains ON Domains.Job_Id='+'"'+job_id+'"'+' and SubDomains.Alive="Yes" and SubDomains.Job_Id='+'"'+job_id+'"'
        #count Non Alives
        non_alive='select distinct(Domains.Job_Id),Domains.Domain,count(SubDomains.SubDomain)  from Domains LEFT JOIN SubDomains ON Domains.Job_Id=SubDomains.Job_Id and SubDomains.Alive="No" Group BY Domains.Job_Id,SubDomains.Job_Id'
        id="select Distinct(Job_Id),Domain from Domains"
        jobid=""
        mycursor = self.mydb.cursor()
        mycursor.execute("USE Domain_Automation")
        mycursor.execute(alives)
        res=mycursor.fetchall()
        res=list(res)
        print(res)
        for i in res:
            data={
            "domain_id": 0,
            "domain_name": "",
            "repetition": "Everyday at 10 AM",
            "subdomain_count": 0,
            "ports_count": 0,
            "last_run": "",
            "vulnerabilities":{
            "info": 0,
            "low": 0,
            "medium": 0, 
            "high": 0, 
            "critical": 0
        } }
            rs=list(i)
            jid=rs[0]
            domain=rs[1]
            aliv_sub_count=rs[2]
            last_run=rs[3]
            data["domain_id"]=jid
            data["domain_name"]=domain
            data["last_run"]=last_run
            jobid=jid
            data["subdomain_count"]=aliv_sub_count
            vuln='select Severity, count(Severity) from Vulnerabilities where Job_Id='+'"'+jobid+'"'+' Group By Severity'
            mycursor.execute(vuln)
            sever=mycursor.fetchall()
            sever=list(sever)
            if(sever!=[]):
                for j in sever:
                    ls=list(j)
                    severity,count=ls
                    #print(severity,count)
                    data["vulnerabilities"][severity]=count
            port='select count(Port) from Ports where Job_Id='+'"'+jobid+'"'
            mycursor.execute(port)
            ports=mycursor.fetchall()
            ports=list(ports)
            if(ports!=[]):
                data["ports_count"]=list(ports[0])[0]
            result.append(data)
        return result[0]

        


    
    def ReadDB(self,domain,table):
        result=""
        if(table=="GetID"):
            sql="SELECT Job_Id from Domains where Domain="+'"'+domain+'"'
            mycursor = self.mydb.cursor()
            mycursor.execute("USE Domain_Automation")
            mycursor.execute(sql)
            res=mycursor.fetchall()
            id=""
            res=""
            if(len(list(res))>0):
                res=list(res)[0]
        if(table=="Summary"):
            result=[]
            #count Alives
            alives=' select distinct(Domains.Job_Id),Domains.Domain,count(SubDomains.SubDomain),Domains.LastRun  from Domains LEFT JOIN SubDomains ON Domains.Job_Id=SubDomains.Job_Id and SubDomains.Alive="Yes" Group BY Domains.Job_Id,SubDomains.Job_Id'
            #count Non Alives
            non_alive='select distinct(Domains.Job_Id),Domains.Domain,count(SubDomains.SubDomain)  from Domains LEFT JOIN SubDomains ON Domains.Job_Id=SubDomains.Job_Id and SubDomains.Alive="No" Group BY Domains.Job_Id,SubDomains.Job_Id'
            id="select Distinct(Job_Id),Domain from Domains"
            jobid=""
            mycursor = self.mydb.cursor()
            mycursor.execute("USE Domain_Automation")
            mycursor.execute(alives)
            res=mycursor.fetchall()
            res=list(res)
            #print(res)
            for i in res:
                data={
                "domain_id": 0,
                "domain_name": "",
                "repetition": "Everyday at 10 AM",
                "subdomain_count": 0,
                "ports_count": 0,
                "last_run": "",
                "vulnerabilities":{
				"info": 0,
				"low": 0,
				"medium": 0, 
				"high": 0, 
				"critical": 0
			} }
                rs=list(i)
                jid=rs[0]
                domain=rs[1]
                aliv_sub_count=rs[2]
                last_run=rs[3]
                data["domain_id"]=jid
                data["domain_name"]=domain
                data["last_run"]=last_run
                jobid=jid
                data["subdomain_count"]=aliv_sub_count
                vuln='select Severity, count(Severity) from Vulnerabilities where Job_Id='+'"'+jobid+'"'+' Group By Severity'
                mycursor.execute(vuln)
                sever=mycursor.fetchall()
                sever=list(sever)
                if(sever!=[]):
                    for j in sever:
                        ls=list(j)
                        severity,count=ls
                        #print(severity,count)
                        data["vulnerabilities"][severity]=count
                port='select count(Port) from Ports where Job_Id='+'"'+jobid+'"'
                mycursor.execute(port)
                ports=mycursor.fetchall()
                ports=list(ports)
                if(ports!=[]):
                    data["ports_count"]=list(ports[0])[0]
                result.append(data)
        
        if(table=="Assets"):
            Job_Id=domain
            res5=self.AssetHistory(Job_Id)
            res1=self.Vuln(Job_Id)
            res2=self.Ports(Job_Id)
            res3=self.Subdomain(Job_Id)
            res4=self.Summary(Job_Id)
            res4["port_details"]=res2
            res4["vuln_detials"]=res1
            res4["sub_domains"]=res3
            res4["asset_history"]=res5["asset_history"]
            result=res4
        return result

                        
        

       


            
    def WriteDB(self,job_id,data,table):
        if(table=="Domains"):
            domain=""
            frequency=1
            key=data.keys()
            if("domain-name" in key):
                domain=data["domain-name"]
            if("freq" in key):
                frequency=data["freq"]
            #resp_http=requests.get("http://"+domain)
            #resp_https=requests.get("https://"+domain)
            #print(resp_http)
            #print(resp_https)
            #INSERT ignore INTO Domains (Job_Id,Domain,Frequency,LastRun) VALUES ('job_id6545647498','abcd.in',1,'2022-11-8 10:45:25');
            sql = "INSERT ignore INTO "+table+"(Job_Id,Domain,Frequency) VALUES (%s,%s, %s)"
            mycursor = self.mydb.cursor()
            val=(job_id,domain,frequency)
            mycursor.execute(sql,val)
            self.mydb.commit()
            if(mycursor.rowcount==1):
                return {"status":"Domain Added Successfully","Id":job_id}
            else:
                return {"status":"Domain Already Found"}
        elif(table=="StoreDB"):
            for k,v in data.items():
                data=data[k]
            port=data["port"]
            vulns=data["vulns"]

            for i in port:
                i=json.loads(i)
                sql = "INSERT ignore INTO Ports(Job_Id,IP,Port,Service,Version) VALUES (%s,%s,%s,%s,%s)"
                ip=""
                port=""
                service=""
                version=""
                print(type(i))
                if("version" in i["metadata"].keys()):
                    ip=i["ip"]
                    port=str(i["port"])
                    service=i["service"]
                    version=i["metadata"]["version"]
                else:
                    ip=i["ip"]
                    port=str(i["port"])
                    service=i["service"]
                if("/" in port):
                    port=port[:port.index("/")]
                print(type(ip))
                print(type(port))
                print(type(service))
                print(type(version))
                print(job_id)
                mycursor = self.mydb.cursor()
                mycursor.execute("USE Domain_Automation")
                mycursor.execute(sql,(job_id,ip,port,service,version))
                self.mydb.commit()
            #-------------------------------------------------------------------------

            for i in vulns:
                r=i.split("] [")
                issue=r[1]
                severity,url=r[3].split("] ")
                mycursor = self.mydb.cursor()
                mycursor.execute("USE Domain_Automation")
                if("apikey=" in url):
                    s=url.index('apikey=')+7
                    url=url.replace(url[s:s+35],"")

                sql = "INSERT ignore INTO Vulnerabilities(Job_Id,IssueType,Severity,Url) VALUES (%s,%s,%s,%s)"
                mycursor.execute(sql, (job_id,issue,severity,url))
                self.mydb.commit()
                
            domains=data["domains"]
            alivehost=data["alivehost"]
            uniq_domain=[]
            mycursor = self.mydb.cursor()
            mycursor.execute("USE Domain_Automation")
            for i in domains:
                if(i not in alivehost):
                    uniq_domain.append(i)

            for i in alivehost:
                sql = "INSERT ignore INTO SubDomains(Job_Id,SubDomain,Alive) VALUES (%s,%s,%s)"
                mycursor.execute(sql, (job_id,i,"Yes"))
                self.mydb.commit()
            for i in uniq_domain:
                sql = "INSERT ignore INTO SubDomains(Job_Id,SubDomain,Alive) VALUES (%s,%s,%s)"
                mycursor.execute(sql, (job_id,i,"No"))
                self.mydb.commit()


            


        
                
    
