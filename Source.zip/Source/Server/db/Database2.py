from threading import current_thread
from tkinter import NE
import mysql.connector
import datetime
import trigger.ZohoAnalytics as za
import trigger.StatusIQ as sq
class Database():
    #CONNECT DATABASE
    def __init__(self):
        self.date=str(datetime.date.today())
    def CreateDatabase(self):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Arjun@123",
        )
        mycursor = mydb.cursor()
        #Create  APIINFO Database
        mycursor.execute("CREATE DATABASE IF NOT EXISTS Vulnerability_Scanning")
        mycursor.execute("USE Vulnerability_Scanning")
        #Update Job Status
        mycursor.execute("CREATE TABLE IF NOT EXISTS Task_Status (Job_Id VARCHAR(50) NOT NULL ,Status VARCHAR(30), date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        #Create Table For BlacklistedIP
        mycursor.execute("CREATE TABLE IF NOT EXISTS Blacklisted_IP (Job_Id VARCHAR(50) NOT NULL  ,IP VARCHAR(20) NOT NULL,BlackLister TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(IP,BlackLister(650)))")
        #Update jobs to Scheduler
        mycursor.execute("CREATE TABLE IF NOT EXISTS Job_Schedule (Job_Type VARCHAR(50) NOT NULL ,Scheduled_day VARCHAR(25),Scheduled_time VARCHAR(25),Scheduled_hour VARCHAR(25),Scheduled_minute VARCHAR(25),Scheduled_everyday VARCHAR(10),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE (Job_Type,Scheduled_day,Scheduled_time,Scheduled_hour,Scheduled_everyday))")
        #Create Table For SUBDOMAIN 
        mycursor.execute("CREATE TABLE IF NOT EXISTS SUBDOMAIN(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(100) NOT NULL,Vulnerabilities VARCHAR(1000) NOT NULL, Type VARCHAR(50) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Domain,Vulnerabilities(500),Type))")
        #Create Table For NucleiAutomation
        mycursor.execute("CREATE TABLE IF NOT EXISTS NucleiAutomation(Job_Id VARCHAR(50) NOT NULL ,IssueType VARCHAR(100) NOT NULL,Severity VARCHAR(100), Url VARCHAR(200), date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(IssueType,Severity,Url))")
        #Create Table For Domain
        mycursor.execute("CREATE TABLE IF NOT EXISTS DOMAIN(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(100) NOT NULL,Subdomain VARCHAR(200) NOT NULL, Org VARCHAR(100) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Domain,Subdomain,Org))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS NMAP(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(50) NOT NULL,IP VARCHAR(15) NOT NULL,Port VARCHAR(7) NOT NULL, Service VARCHAR(50) NOT NULL,Version VARCHAR(50) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Domain,IP,Port,Service,Version))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS Port(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(50) NOT NULL,Port VARCHAR(20) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Domain,Port))")

        #===========
        #LINUX AGENT
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_CVE (Job_Id VARCHAR(50) NOT NULL , Package VARCHAR(100) NOT NULL, Curr_version VARCHAR(10) NOT NULL, Vuln_version VARCHAR(10) NOT NULL, CVE VARCHAR(20) NOT NULL ,Issue VARCHAR(2000) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Package,Curr_version,Vuln_version,CVE,Issue(600)))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Servlets(700)))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(port,service))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_CODE_ANALYSE (Job_Id VARCHAR(50) NOT NULL , Code VARCHAR(1000) NOT NULL, CWE VARCHAR(500) NOT NULL, Severity VARCHAR(50) NOT NULL, Issue VARCHAR(1000) NOT NULL ,Filename VARCHAR(50) NOT NULL , LineNum INT NOT NULL, date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(CWE(200),LineNum,Issue(500)))")

        #============
        #WINDOWS AGENT
        #mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_AGENT_CVE(Job_Id VARCHAR(50) NOT NULL , DependencyName VARCHAR(50) NOT NULL,CVE VARCHAR(50) NOT NULL, CWE VARCHAR(2000) NOT NULL, CVSS_Severity VARCHAR(50), CVSS_Score VARCHAR(10) NOT NULL ,Type VARCHAR(50) NOT NULL , date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(CVE, DependencyName,CVSS_Score))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_AGENT_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Servlets(700)))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_AGENT_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(port,service))")

        #=============
        #LINUX POLLER
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_POLLER_CVE(Job_Id VARCHAR(50) NOT NULL , DependencyName VARCHAR(50) NOT NULL,CVE VARCHAR(50) NOT NULL, CWE VARCHAR(2000) NOT NULL, CVSS_Severity VARCHAR(50), CVSS_Score VARCHAR(10) NOT NULL ,Type VARCHAR(50) NOT NULL , date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(CVE, DependencyName,CVSS_Score))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_POLLER_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Servlets(700)))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_POLLER_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(port,service))")

        #============
        #WINDOWS POLLER
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_POLLER_CVE(Job_Id VARCHAR(50) NOT NULL , DependencyName VARCHAR(50) NOT NULL,CVE VARCHAR(50) NOT NULL, CWE VARCHAR(2000) NOT NULL, CVSS_Severity VARCHAR(50), CVSS_Score VARCHAR(10) NOT NULL ,Type VARCHAR(50) NOT NULL , date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(CVE, DependencyName,CVSS_Score))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_POLLER_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(Servlets(700)))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_POLLER_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(port,service))")

        return mydb
        #======================================================================================================================================================================================================================================================================================================================================================================================
    def Get_LastRun(self,job_id,table):
        sql = 'select date from '+table+' where Job_Id='+'"'+job_id+'"'
        mycursor=self.mydb.cursor()
        mycursor.execute("USE Vulnerability_Scanning")
        mycursor.execute(sql)
        res=mycursor.fetchall()
        res=list(res)
        date1=str(list(res[0])[0])
        print("Date:",date1)
        return date1

    def Automation(self):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Arjun@123",
        )
        mycursor = mydb.cursor()
        #Create  APIINFO Database
        mycursor.execute("CREATE DATABASE IF NOT EXISTS Automation_Scanning")
        mycursor.execute("USE Automation_Scanning")
        #Update Job Status
        mycursor.execute("CREATE TABLE IF NOT EXISTS Task_Status (Job_Id VARCHAR(50) NOT NULL ,Status VARCHAR(30), date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        #Create Table For BlacklistedIP
        mycursor.execute("CREATE TABLE IF NOT EXISTS Blacklisted_IP (Job_Id VARCHAR(50) NOT NULL  ,IP VARCHAR(20) NOT NULL,BlackLister TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        #Update jobs to Scheduler
        mycursor.execute("CREATE TABLE IF NOT EXISTS Job_Schedule (Job_Type VARCHAR(50) NOT NULL ,Scheduled_day VARCHAR(25),Scheduled_time VARCHAR(25),Scheduled_hour VARCHAR(25),Scheduled_minute VARCHAR(25),Scheduled_everyday VARCHAR(10),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        #Create Table For SUBDOMAIN 
        mycursor.execute("CREATE TABLE IF NOT EXISTS SUBDOMAIN(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(100) NOT NULL,Vulnerabilities VARCHAR(1000) NOT NULL, Type VARCHAR(50) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        #Create Table For NucleiAutomation
        mycursor.execute("CREATE TABLE IF NOT EXISTS NucleiAutomation(Job_Id VARCHAR(50) NOT NULL ,IssueType VARCHAR(500) NOT NULL,Severity VARCHAR(1000), Url VARCHAR(1000), date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        #Create Table For Domain
        mycursor.execute("CREATE TABLE IF NOT EXISTS DOMAIN(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(100) NOT NULL,Subdomain VARCHAR(200) NOT NULL, Org VARCHAR(100) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS NMAP(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(50) NOT NULL,IP VARCHAR(15) NOT NULL,Port VARCHAR(7) NOT NULL, Service VARCHAR(50) NOT NULL,Version VARCHAR(50) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS Port(Job_Id VARCHAR(50) NOT NULL ,Domain VARCHAR(50) NOT NULL,Port VARCHAR(20) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
       
        #===========
        #LINUX AGENT
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_CVE (Job_Id VARCHAR(50) NOT NULL , Package VARCHAR(100) NOT NULL, Curr_version VARCHAR(10) NOT NULL, Vuln_version VARCHAR(10) NOT NULL, CVE VARCHAR(20) NOT NULL ,Issue VARCHAR(2000) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_AGENT_CODE_ANALYSE (Job_Id VARCHAR(50) NOT NULL , Code VARCHAR(1000) NOT NULL, CWE VARCHAR(500) NOT NULL, Severity VARCHAR(50) NOT NULL, Issue VARCHAR(1000) NOT NULL ,Filename VARCHAR(50) NOT NULL , LineNum INT NOT NULL, date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")

        #============
        #WINDOWS AGENT
        #mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_AGENT_CVE(Job_Id VARCHAR(50) NOT NULL , DependencyName VARCHAR(50) NOT NULL,CVE VARCHAR(50) NOT NULL, CWE VARCHAR(2000) NOT NULL, CVSS_Severity VARCHAR(50), CVSS_Score VARCHAR(10) NOT NULL ,Type VARCHAR(50) NOT NULL , date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME),UNIQUE(CVE, DependencyName,CVSS_Score))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_AGENT_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_AGENT_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        
        #=============
        #LINUX POLLER
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_POLLER_CVE(Job_Id VARCHAR(50) NOT NULL , DependencyName VARCHAR(50) NOT NULL,CVE VARCHAR(50) NOT NULL, CWE VARCHAR(2000) NOT NULL, CVSS_Severity VARCHAR(50), CVSS_Score VARCHAR(10) NOT NULL ,Type VARCHAR(50) NOT NULL , date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_POLLER_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS LINUX_POLLER_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        
        #============
        #WINDOWS POLLER
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_POLLER_CVE(Job_Id VARCHAR(50) NOT NULL , DependencyName VARCHAR(50) NOT NULL,CVE VARCHAR(50) NOT NULL, CWE VARCHAR(2000) NOT NULL, CVSS_Severity VARCHAR(50), CVSS_Score VARCHAR(10) NOT NULL ,Type VARCHAR(50) NOT NULL , date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_POLLER_SERVLETS (Job_Id VARCHAR(50) NOT NULL ,Servlets TEXT(1500) NOT NULL,date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        mycursor.execute("CREATE TABLE IF NOT EXISTS WIN_POLLER_OPENPORT (Job_Id VARCHAR(50) NOT NULL  ,port VARCHAR(10) NOT NULL, service VARCHAR(50),date DATE DEFAULT (CURRENT_DATE),time TIME DEFAULT (CURRENT_TIME))")
        
        return mydb

    #READ Data FROM TABLE
    def ReadDB(self,mydb,sql,type):
        rs=[]
        query=sql
        mycursor = mydb.cursor()
        if(type in ["Lin_Poller_Cve","Win_Poller_Cve","Lin_Poller_Port","Lin_Agent_Port","Win_Poller_Port","Win_Agent_Port","Lin_Agent_Cve"]):
            mycursor.execute(query)
            res=mycursor.fetchall()
            r=set(res)
            for i in list(r):
                if(type=="Lin_Poller_Cve" or type=="Win_Poller_Cve"):
                    dep=list(i)[0]
                    cve=list(i)[1]
                    typ=list(i)[2]
                    res=[dep,cve,typ]
                    rs.append(res)
                elif(type=="Lin_Agent_Cve"):
                    pkg=list(i)[0]
                    cve=list(i)[1]
                    res=[pkg,cve]
                    rs.append(res)
                else:
                    res=list(i)[0]
                    rs.append(res)
        elif(type=="Lin_Agent_Code_Analyse"):
            mycursor.execute(query)
            res=mycursor.fetchall()
            r=set(res)
            for i in list(r):
                res=list(i)
                rs.append(res)
        
        elif(type=="status"):
            mycursor.execute(query)
            res=mycursor.fetchall()
            r=set(res)
            #print(r)
            for i in list(r):
                res=list(i)
                rs.append(res)
        elif(type=="SUBDOMAIN" or type=="NucleiAutomation"):
            mycursor.execute(query)
            res=mycursor.fetchall()
            r=set(res)
            #print(r)
            for i in list(r):
                res=list(i)
                rs.append(res)

        elif(type in ["Lin_Poller_Servlet","Lin_Agen_Servlet","Win_Poller_Servlet","Win_Agent_Servlet"]):
            mycursor.execute(query)
            res=mycursor.fetchall()
            r=set(res)
            for i in list(r):
                res=list(i)[0]
                if("?" in res):
                    ind=res.index("?")
                    res=res[:ind]
                rs.append(res)

        elif(type=="BLACKLISTEDIP"):
            blist=[]
            ipdct={}
            mycursor.execute(query)
            res=mycursor.fetchall()
            #print(res)
            for i in list(res):
                ip=list(i)[0]
                black=list(i)[1]
                if(ip not in ipdct.keys()):
                    ipdct[ip]=[black]
                else:
                    ipdct[ip].append(black)
            return ipdct
        return rs

    #Update Data to the Table
    def UpdateDB(self,typ,job_time):
        pass
    def ReadDBConnect(self,mydb,typ):
        table=""
        if(typ=="Lin_Agent_Cve"):
            table="LINUX_AGENT_CVE"
        elif(typ=="Lin_Poller_Cve"):
            table="LINUX_POLLER_CVE"
        elif(typ=="Win_Poller_Cve"):
            table="WIN_POLLER_CVE"
        elif(typ=="BLACKLISTEDIP"):
            table="Blacklisted_IP"
        mycursor = mydb.cursor()
        sql = "SELECT count(*) from "+table 
        mycursor.execute(sql)
        res=mycursor.fetchall()

        return res
    #WRITE DATA TO TABLE
    def WriteDB(self,List,jid,typ,mydb,cport,type):
        curr_res=[]
        mydb1=mydb[1]
        mydb=mydb[0]
        mycursor = mydb.cursor()
        mycursor1 = mydb1.cursor()
        table=""
        self.count=0
        sqobj=sq.Component()
        #====================================================================JOB_STATUS============================================================== 
        if(type=="status"):
            res=self.ReadDB(mydb,"SELECT Job_Id,Status from Task_Status",type)
            c=0
            for i in res:
                ids=i[0]
                st=i[1]
                if(jid==ids and st==typ):
                    c+=1
            if(c==0):
                sql = "INSERT IGNORE INTO Task_Status(Job_Id,Status) VALUES (%s,%s)"
                mycursor.execute(sql, (jid,typ))
                mydb.commit()
        #==================================================================SCHEDULE_JOBS============================================================== 
        if(type=="job_schedule"):
            #
            sql = "INSERT ignore INTO Job_Schedule(Job_Type,Scheduled_day,Scheduled_time,Scheduled_hour,Scheduled_minute,Scheduled_everyday) VALUES (%s,%s,%s,%s,%s,%s)"
            day=jid
            time,everyday=List.split("&")
            hour,minute=cport.split("&")
            type=typ
            mycursor.execute(sql, (type,day,time,hour,minute,everyday))
            mydb.commit()
            title=""
        #==================================================================CVES============================================================== 
        if("Poller_Cve" in type ):
            if(type=="Win_Poller_Cve"):
                table="WIN_POLLER_CVE"
                title="Windows Poller CVE's"
            elif(type=="Lin_Poller_Cve"):
                table="LINUX_POLLER_CVE"
                title="Linux Poller CVE's"
            zobj=za.Reports(jid)
            res=""
            for cve in List:
                    sql = "INSERT ignore INTO "+table+"(Job_Id,DependencyName,CVE,CWE,CVSS_Severity,CVSS_Score,Type) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                    mycursor.execute(sql, (jid,cve[0],cve[1],cve[2],cve[3],cve[4],typ))
                    mydb.commit()
                    sql1 = "INSERT INTO "+table+"(Job_Id,DependencyName,CVE,CWE,CVSS_Severity,CVSS_Score,Type) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                    mycursor1.execute(sql1, (jid,cve[0],cve[1],cve[2],cve[3],cve[4],typ))
                    mydb1.commit()
                    print(mycursor.rowcount, "record inserted.")
                    if(mycursor.rowcount==1):
                        self.count+=1
                        if("Win_Poller" in type ):
                            zobj.WinPoller(type,[cve[0],cve[1],cve[2],cve[3],cve[4],typ])
                        else:
                            zobj.LinPoller(type,[cve[0],cve[1],cve[2],cve[3],cve[4],typ])
                        res+=cve[0]+" - "+cve[1]+"\n"
            if(res!=""):
                sqobj.BugPost("site24x7_plus","medium","Poller CVE "+"\n\n"+res+"\n\n"+"#site24x7automation",title)

            print("count:",self.count)
            #sql = "SELECT DependencyName,CVE,Type  from "+table+" where date="+'"'+self.date+'"'
            #res=self.ReadDB(mydb,sql,type)
            return self.count

        elif(type=="Lin_Agent_Code_Analyse"):
            for cve in List:
                code=cve["code"]
                cwd=cve["issue_cwe"]["link"]
                severity=cve["issue_severity"]
                issue=cve["issue_text"]
                file=cve["filename"]
                lin=cve["line_number"]
                sql = "INSERT ignore INTO  LINUX_AGENT_CODE_ANALYSE(Job_Id,Code,CWE,Severity,Issue,Filename,LineNum) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                mycursor.execute(sql, (jid,code,cwd,severity,issue,file,lin))
                mydb.commit()
                sql1 = "INSERT INTO  LINUX_AGENT_CODE_ANALYSE(Job_Id,Code,CWE,Severity,Issue,Filename,LineNum) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                mycursor1.execute(sql1, (jid,code,cwd,severity,issue,file,lin))
                mydb1.commit()
                print(mycursor.rowcount, "record inserted.")
                if(mycursor.rowcount==1):
                    self.count+=1

            '''sql = "SELECT Code,CWE,Severity from LINUX_AGENT_CODE_ANALYSE  where date="+'"'+self.date+'"'
            res=self.ReadDB(mydb,sql,type)
            print("value....",res)'''
            return self.count

        elif(type=="Lin_Agent_Cve"):
            #sql = "SELECT Code,LineNum from LINUX_AGENT_CVE"
            #res=self.ReadDB(mydb,sql,type)
            zobj=za.Reports(jid)
            res=""
            sqobj=sq.Component()
            for cve in List:
                pkg=cve["pkg"]
                cur_ver=cve["cur_ver"]
                vul_ver=cve["vuln_ver"]
                cves=cve["cve"]
                issue=cve["issue"]
                sql = "INSERT ignore INTO  LINUX_AGENT_CVE(Job_Id,Package,Curr_version,Vuln_version,CVE,Issue) VALUES (%s,%s,%s,%s,%s,%s)"
                mycursor.execute(sql, (jid,pkg,cur_ver,vul_ver,cves,issue))
                mydb.commit()
                sql1 = "INSERT INTO  LINUX_AGENT_CVE(Job_Id,Package,Curr_version,Vuln_version,CVE,Issue) VALUES (%s,%s,%s,%s,%s,%s)"
                mycursor1.execute(sql1, (jid,pkg,cur_ver,vul_ver,cves,issue))
                mydb1.commit()
                print(mycursor.rowcount, "record inserted.")
                if(mycursor.rowcount==1):
                    self.count+=1
                    zobj.LinAgent(type,[pkg,cur_ver,vul_ver,cves,issue])
                    res+=pkg+" - "+cves+"\n"
            '''
            sql = "SELECT Package,CVE from LINUX_AGENT_CVE where date="+'"'+self.date+'"'
            res=self.ReadDB(mydb,sql,type)
            print("value....",res)'''

            if(res!=""):
                sqobj.BugPost("site24x7_plus","medium","Linux Agent CVE "+"\n\n"+res+"\n\n"+"#site24x7automation","Linux Agent CVE's")
            return self.count

        elif(type=="Win_Agent_Cve"):
            return None


        #==================================================================OPENPORTS============================================================== 
        if("Port" in type):
            if(type=="Win_Poller_Port"):
                table="WIN_POLLER_PORT"
            elif(type=="Lin_Poller_Port"):
                table="LINUX_POLLER_PORT"
            elif(type=="Lin_Agent_Port"):
                table="LINUX_AGENT_PORT"
            elif(type=="Win_Agent_Port"):
                table="WIN_AGENT_PORT"
            port_key=cport.keys()
            zobj=za.Reports(jid)
            for ports in List:
                sql = "INSERT ignore INTO "+table+"(Job_Id,Port, Service) VALUES (%s,%s, %s)"
                sql1 = "INSERT INTO "+table+"(Job_Id,Port, Service) VALUES (%s,%s, %s)"

                port=str(ports[0])
                if(port in port_key):
                    val = (jid,port,cport[str(port)])
                elif((int(port)>=5000 and int(port)<=6000 )or (int(port)>=49152 and int(port)<=65535)):
                    val = (jid,port,"WMI")
                else:
                    val = (jid,port,ports[1])
                mycursor.execute(sql, val)
                mydb.commit()
                mycursor1.execute(sql1, val)
                mydb1.commit()
                print(mycursor.rowcount, "record inserted.",port)
                if(mycursor.rowcount==1):
                    self.count+=1
                    if("Win_Poller" in type):
                        zobj.WinPoller(type,[port])
                    elif("Win_Agent" in type):
                        zobj.WinAgent(type,[port])
                    elif("Lin_Poller" in type):
                        zobj.LinPoller(type,[port])
                    elif("Lin_Agent" in type):
                        zobj.LinAgent(type,[port])



            '''sql = "SELECT port from "+table+" where date="+'"'+self.date+'"'
            res=self.ReadDB(mydb,sql,type)'''
            return self.count

        #===========================================================SERVLETS================================================================
        if("Servlet" in type):
            if(type=="Win_Poller_Servlet"):
                table="WIN_POLLER_SERVLETS"
            elif(type=="Lin_Poller_Servlet"):
                table="LINUX_POLLER_SERVLETS"
            elif(type=="Lin_Agent_Servlet"):
                table="LINUX_AGENT_SERVLETS"
            elif(type=="Win_Agent_Servlet"):
                table="WIN_AGENT_SERVLETS"

            sql = "SELECT Servlets from "+table 
            res=self.ReadDB(mydb,sql,type)
            curr_res=[]
            tmp=[]
            zobj=za.Reports(jid)
            for api in List:
                res2=api
                if("?" in api):
                    ind=res2.index("?")
                    res2=res2[:ind]
                    if(res2 not in tmp and (res2 not in res and api!="") and (len(api)>10)):
                        tmp.append(res2)
                        mycursor = mydb.cursor()
                        sql = "INSERT ignore INTO "+table+"(Job_Id,Servlets) VALUES (%s,%s)"
                        val = api
                        mycursor.execute(sql, (jid,val))
                        mydb.commit()
                        sql1 = "INSERT  INTO "+table+"(Job_Id,Servlets) VALUES (%s,%s)"
                        mycursor1.execute(sql1, (jid,val))
                        mydb1.commit()
                        if(mycursor.rowcount==1):
                            self.count+=1
                            if("Win_Poller" in type):
                                zobj.WinPoller(type,[val])
                            elif("Win_Agent" in type):
                                zobj.WinAgent(type,[val])
                            elif("Lin_Poller" in type):
                                zobj.LinPoller(type,[val])
                            elif("Lin_Agent" in type):
                                zobj.LinAgent(type,[val])
                        print(mycursor.rowcount, "record inserted.")
                        #curr_res.append(res2)    
                else:
                    mycursor = mydb.cursor()
                    sql = "INSERT ignore INTO "+table+"(Job_Id,Servlets) VALUES (%s,%s)"
                    val = api
                    mycursor.execute(sql, (jid,val))
                    mydb.commit()
                    sql1 = "INSERT  INTO "+table+"(Job_Id,Servlets) VALUES (%s,%s)"
                    mycursor1.execute(sql1, (jid,val))
                    mydb1.commit()
                    print(mycursor.rowcount, "record inserted.")
                    if(mycursor.rowcount==1):
                        self.count+=1
                        if("Win_Poller" in type):
                            zobj.WinPoller(type,[val])
                        elif("Win_Agent" in type):
                            zobj.WinAgent(type,[val])
                        elif("Lin_Poller" in type):
                            zobj.LinPoller(type,[val])
                        elif("Lin_Agent" in type):
                            zobj.LinAgent(type,[val])
                    #curr_res.append(res2)

            return self.count
        #===================================================================BLACKLISTEDIP=====================================================
        elif(type=="BLACKLISTEDIP"):
            sql="SELECT IP,BlackLister from Blacklisted_IP"
            res=self.ReadDB(mydb,sql,type)
            ipkey=res.keys()
            ipblist=res.values()
            curr_res={}
            zobj=za.Reports(jid)
            res=""
            sqobj=sq.Component()
            for ip,blister in List.items():
                for ipblis in blister:
                    if((ip not in ipkey and ipblis not in ipblist) and (ip!="" and ipblis!="")):
                        mycursor = mydb.cursor()
                        sql = "INSERT ignore INTO Blacklisted_IP(Job_Id,IP,BlackLister) VALUES (%s,%s,%s)"
                        mycursor.execute(sql, (jid,ip,ipblis))
                        mydb.commit()
                        sql1 = "INSERT  INTO Blacklisted_IP(Job_Id,IP,BlackLister) VALUES (%s,%s,%s)"
                        mycursor1.execute(sql1, (jid,ip,ipblis))
                        mydb1.commit()
                        print(mycursor.rowcount, "record inserted blacklisted ip.")
                        if(mycursor.rowcount==1):
                            self.count+=1
                            zobj.BlistIP(type,ip,ipblis)
                            res+=ip+" - "+ipblis+"\n"
                        if(ip not in curr_res.keys()):
                            curr_res[ip]=[ipblis]
                        else:
                            curr_res[ip].append(ipblis)
                if(len(res)>50):
                    res+="\n\n"

            if(res!=""):
                sqobj.BugPost("site24x7_plus","medium","Blacklisted IP's\n\n"+res+"\n\n"+"#site24x7automation","Site24x7 Monitoring Location Blacklisted IP")
            return curr_res
        #===================================================================SUBDOMAIN=====================================================
        elif(type=="Domain"):
            for i in List:
                sql = "INSERT ignore INTO DOMAIN(Job_Id,Domain,Subdomain,Org) VALUES (%s,%s,%s,%s)"
                org="-"
                if("site24x7" in i):
                    org="site24x7"
                elif("zoho" in i):
                    org="zoho"
                mycursor.execute(sql,(jid,typ,i,org))
                mydb.commit()
                sql1 = "INSERT  INTO DOMAIN(Job_Id,Domain,Subdomain,Org) VALUES (%s,%s,%s,%s)"
                mycursor1.execute(sql1,(jid,typ,i,org))
                mydb1.commit()
        elif(type=="Nmap"):
            for i in List:
                sql = "INSERT ignore INTO NMAP(Job_Id,Domain,IP,Port,Service,Version) VALUES (%s,%s,%s,%s,%s,%s)"
                res=i.split()
                ip=""
                port=""
                service=""
                version=""
                if(len(res)==4):
                    ip,port,service,version=res
                elif(len(res)==3):
                    ip,port,service=res
                if("/" in port):
                    port=port[:port.index("/")]
                mycursor.execute(sql,(jid,typ,ip,port,service,version))
                mydb.commit()
                sql1 = "INSERT INTO NMAP(Job_Id,Domain,IP,Port,Service,Version) VALUES (%s,%s,%s,%s,%s,%s)"
                mycursor1.execute(sql1,(jid,typ,ip,port,service,version))
                mydb1.commit()
        elif(type=="SUBDOMAIN"):
            #'localmanageengine.com': {'newhost': ['https://121.244.91.34'], 'priviledge_host': [], 'vulnerabilities': [], 'prehost': []}
            #Subdomain,New_Hosts,Priviledge_Hosts,Pre_Hosts,Vulnerabilities
            res=""
            sql="SELECT Domain from SUBDOMAIN"
            res=self.ReadDB(mydb,sql,type)
            Subdomain=typ
            '''New_Hosts=str(List["newhost"]).replace("]","").replace("[","")
            Priviledge_Hosts=str(List["priviledge_host"]).replace("]","").replace("[","")
            Pre_Hosts=str(List["prehost"]).replace("]","").replace("[","")
            Vulnerabilities=str(List["vulnerabilities"]).replace("]","").replace("[","")'''
            New_Hosts=List["newhost"]
            Total_Host=List["totalhost"]
            Priviledge_Hosts=List["priviledge_host"]
            Pre_Hosts=List["prehost"]
            Vulnerabilities=List["vulnerabilities"]
            Port=List["port"]
            zobj=cport
            mycursor = mydb.cursor()
            rs=""
            nhost=""
            priv_host=""
            pre_host=""
            vuln=""
            port=""

            if(New_Hosts!=[]):
                for i in New_Hosts:
                    sql = "INSERT ignore INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor.execute(sql,(jid,Subdomain,i,"New_Hosts"))
                    mydb.commit()
                    sql1 = "INSERT  INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor1.execute(sql1,(jid,Subdomain,i,"New_Hosts"))
                    mydb1.commit()
                    if(mycursor.rowcount==1):
                        zobj.Subdomain(type,[Subdomain,i,"New_Hosts"])
                        nhost=nhost+"<li>"+i+"</li>"

            if(Priviledge_Hosts!=[]):
                for i in Priviledge_Hosts:
                    sql = "INSERT ignore INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor.execute(sql,(jid,Subdomain,i,"Priviledge_Hosts"))
                    mydb.commit()
                    sql1 = "INSERT INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor1.execute(sql1,(jid,Subdomain,i,"Priviledge_Hosts"))
                    mydb1.commit()
                    if(mycursor.rowcount==1):
                        zobj.Subdomain(type,[Subdomain,i,"Priviledge_Host"])
                        priv_host=priv_host+"<li>"+i+"</li>"
                    
            if(Pre_Hosts!=[]):
                for i in Pre_Hosts:
                    sql = "INSERT ignore INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor.execute(sql,(jid,Subdomain,i,"Pre_Hosts"))
                    mydb.commit()
                    sql1 = "INSERT  INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor1.execute(sql1,(jid,Subdomain,i,"Pre_Hosts"))
                    mydb1.commit()
                    if(mycursor.rowcount==1):
                        zobj.Subdomain(type,[Subdomain,i,"Pre_Hosts"])
                        pre_host=pre_host+"<li>"+i+"</li>"
                    
            if(Vulnerabilities!=[]):
                for i in Vulnerabilities:
                    sql = "INSERT ignore INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor.execute(sql,(jid,Subdomain,i,"Invalid_SSL"))
                    mydb.commit()
                    sql1 = "INSERT INTO SUBDOMAIN(Job_Id,Domain,Vulnerabilities,Type) VALUES (%s,%s,%s,%s)"
                    mycursor1.execute(sql1,(jid,Subdomain,i,"Invalid_SSL"))
                    mydb1.commit()
                    if(mycursor.rowcount==1):
                        zobj.Subdomain(type,[Subdomain,i,"Invalid_SSL"])
                        rs+=i+"\n"
                        vuln=vuln+"<li>"+i+"</li>"
            if(Port!=[]):
                for i in Port:
                    if((":80" not in i )and (":443" not in i)):
                        sql = "INSERT ignore INTO Port(Job_Id,Domain,Port) VALUES (%s,%s,%s)"
                        mycursor.execute(sql,(jid,Subdomain,i))
                        mydb.commit()
                        sql1 = "INSERT  INTO Port(Job_Id,Domain,Port) VALUES (%s,%s,%s)"
                        mycursor1.execute(sql1,(jid,Subdomain,i))
                        mydb1.commit()
                        if(mycursor.rowcount==1):
                            port=port+"<li>"+i+"</li>"

            fres="<b>Total Hosts Found</b>"+"<li>"+Total_Host+"</li>"
            rc=0
            if(nhost!=""):
                fres+="<b>New Hosts</b><ol>"+nhost+"</ol>"
                rc+=1
            if(priv_host!=""):
                fres+="<b>Priviledge Hosts</b><ol>"+priv_host+"</ol>"
                rc+=1
            if(pre_host!=""):
                fres+="<b>Pre Hosts</b>+<ol>"+pre_host+"</ol>"
                rc+=1
            if(vuln!=""):
                fres+="<b>Vulnerabilities</b>+<ol>"+vuln+"</ol>"
                rc+=1
            if(port!=""):
                fres+="<b>OpenPorts</b>+<ol>"+port+"</ol>"
                rc+=1



            '''mycursor = mydb.cursor()
            sql = "INSERT ignore INTO SUBDOMAIN(Job_Id,Domain,New_Hosts,Priviledge_Hosts,Pre_Hosts,Vulnerabilities) VALUES (%s,%s,%s,%s,%s,%s)"
            mycursor.execute(sql, (jid,Subdomain,New_Hosts,Priviledge_Hosts,Pre_Hosts,Vulnerabilities))
            mydb.commit()
            print(mycursor.rowcount, "record inserted SUBDOMAIN")
            rs=""
            if(mycursor.rowcount==1):
                self.count+=1
                zobj.Subdomain(type,[Subdomain,New_Hosts,Priviledge_Hosts,Pre_Hosts,Vulnerabilities])
                rs+=Vulnerabilities+" "

            
            sql="SELECT Domain,New_Hosts,Priviledge_Hosts,Pre_Hosts,Vulnerabilities from SUBDOMAIN where date="+'"'+self.date+'"'
            res=self.ReadDB(mydb,sql,type)'''
        
            return [rs,fres,rc]
            
        #===================================================================NUCLEI_AUTOMATION=====================================================
        elif(type=="NucleiAutomation"):
            zobj=za.Reports(jid)
            res=[]
            rs=""
            sqobj=sq.Component()
            for i in List:
                r=i.split("] [")
                #print(r)
                issue=r[1]
                severity,url=r[3].split("] ")
                mycursor = mydb.cursor()
                if("apikey=" in url):
                    s=url.index('apikey=')+7
                    url=url.replace(url[s:s+35],"")

                sql = "INSERT ignore INTO NucleiAutomation(Job_Id,IssueType,Severity,Url) VALUES (%s,%s,%s,%s)"
                mycursor.execute(sql, (jid,issue,severity,url))
                mydb.commit()
                sql1 = "INSERT ignore INTO NucleiAutomation(Job_Id,IssueType,Severity,Url) VALUES (%s,%s,%s,%s)"
                mycursor1.execute(sql, (jid,issue,severity,url))
                mydb1.commit()
                print(mycursor.rowcount, "record inserted NucleiAutomation")
                if(mycursor.rowcount==1):
                    self.count+=1
                    zobj.NucleiAutomation(type,issue,severity,url)
                    res.append([issue,severity,url])
                    rs+=issue+" - "+severity+" - "+url+"\n"

            if(rs!=""):
                sqobj.BugPost("site24x7","low","Nuclei Automation\n\n"+rs+"\n\n"+"#site24x7automation","Site24x7 Nuclei Automation")
                       
            #sql="SELECT IssueType,Severity,Url from NucleiAutomation where date="+'"'+self.date+'"'
            #res=self.ReadDB(mydb,sql,type)
            return rs
            
            
