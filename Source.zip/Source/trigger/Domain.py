import os
import requests
url_domain="http://172.20.10.4:8080/"
class Data:
    def __init__(self):
        pass
    def GetSummary(self):
        pass
    def getDomain(self,domain):
        pwd=os.getcwd()
        dct={}
        dct[domain]={}
        fold="/home/site24x7/HACK_WITH_AUTOMATION/"+domain
        #---------------------------
        #site24x7.jp_alives.txt  site24x7.jp-asset-domains.txt
        #site24x7.jp_domains.txt  site24x7.jp_ips.txt  site24x7.jp_ports.txt  site24x7.jp-subfinder-domains.txt  site24x7.jp_vulns.txt
        total_host=0
        #total_host=os.popen("test -f "+alv+" && cat "+alv+" | wc -l").read()
        alives=fold+"/"+domain+"_alives.txt"
        domains=fold+"/"+domain+"_domains.txt"
        port=fold+"/"+domain+"_fingerprints.txt"
        vuln=fold+"/"+domain+"_vulns.txt"

        dct[domain]["domains"]=[]
        dct[domain]["vulns"]=[]
        dct[domain]["port"]=[]
        dct[domain]["alivehost"]=[]
        fil=os.popen("ls "+fold).read()
        fils=fil.split("\n")
        for fil in fils:
            if("_alives" in fil):
                f2=open(alives,"r")
                f2=[i.replace("\n","") for i in f2.readlines()]
                if(f2!=[]):
                    dct[domain]["alivehost"]=f2
            elif("_domains" in fil):
                f3=open(domains,"r")
                f3=[i.replace("\n","") for i in f3.readlines()]
                if(f3!=[]):
                    dct[domain]["domains"]=f3
            elif("_vulns" in fil):
                f4=open(vuln,"r")
                f4=[i.replace("\n","") for i in f4.readlines()]
                if(f4!=[]):
                    dct[domain]["vulns"]=f4
            elif("fingerprints" in fil):
                f5=open(port,"r")
                rs=[]
                for i in f5.readlines():
                    if(" " in i):
                        i=i.replace("\n","")
                        rs.append(i)
                if(rs!=[]):
                    dct[domain]["port"]=rs
        return dct



def addCronJob(cmd):
    print("get cron")
    a=os.popen("crontab -l").read()
    print(a)
    r=a.split("\n")
    print(r)
    r=r[0]
    r=r.split()
    r=int(r[1])
    time=0
    if(r!=23):
        time=r%24+1
    minute="0 "
    hour=str(time)+" "
    day_month="* "
    month="* "
    week_day="* "

    date_time="'"+minute+hour+day_month+month+week_day+cmd+"'"
    cmd1="echo "+'"'+"$(echo "+date_time+" ; crontab -l 2>&1)"+'"'+" | crontab -"
    print(cmd1)
    os.system(cmd1)

    '''
    cron="crontab -l >mycron"
    crondata='echo '+'"'+'0 */12 * * * '+cmd+'"'
    res=crondata+' >> mycron'
    print(res)
    os.system(res)
    addcron='crontab mycron'
    os.system(addcron)
    rmcron='rm mycron'
    os.system(rmcron)'''

def addDomain(domain,freq,id):
    cwd="/home/site24x7/HACK_WITH_AUTOMATION/"
    cmd="bash "+cwd+"script.sh "+domain
    #os.system(cmd)
    addCronJob(cmd)
    '''
    obj=Data()
    res=obj.getDomain(domain)
    res={"Domain":res}
    print(res)
    api=url_domain+"api/result?type=Domain_Automation&id="+id
    requests.post(api,json=res)'''





        




        



