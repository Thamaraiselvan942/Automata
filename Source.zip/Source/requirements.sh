#proxy for internal environment
#export http_proxy=http://192.168.100.100:3128
#export https_proxy=http://192.168.100.100:3128

sudo apt-get update -y;
sudo apt-get install python3 -y;
sudo apt install python3-pip -y;
sudo apt-get install mysql-server -y;
sudo apt-get install net-tools -y;
#p="$(pwd)/source/requirements.txt";
#echo "Installing pip requirements";
#sudo pip install -r $p;
#service mysql start;
#sudo -h localhost -y root -p
#ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Arjun@123'
sudo apt-get install redis -y;
sudo apt-get install python3-tk -y;
sudo apt-get install python3-rq -y;
sudo apt-get install python3-flask -y;
sudo apt-get install curl -y;
sudo apt-get install wget -y;
: '
wget https://go.dev/dl/go1.19.linux-amd64.tar.gz;
tar -C /usr/local -xvzf go1.19.linux-amd64.tar.gz;
export PATH=$PATH:/usr/local/go/bin;
source $HOME/.profile;
go version;
 '
#go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest;
#go install -v github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest
#mv ~/go/bin/nuclei /usr/local/bin/
#nuclei -ut;
#./security_automation.sh
