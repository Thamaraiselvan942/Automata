import os
import sys
import requests
url_domain="http://172.24.238.228:8080/"
class Data:
    def __init__(self):
        pass
    def getDomain(self,domain):
        pwd=os.getcwd()
        dct={}
        dct[domain]={}
        fold=pwd+"/"+"HACK_WITH_AUTOMATION/"+domain
        total_host=0
        alives=fold+"/"+domain+"_alives.txt"
        domains=fold+"/"+domain+"_domains.txt"
        port=fold+"/"+domain+"_fingerprintx.txt"
        vuln=fold+"/"+domain+"_vulns.txt"

        dct[domain]["domains"]=[]
        dct[domain]["vulns"]=[]
        dct[domain]["port"]=[]
        dct[domain]["alivehost"]=[]
        fil=os.popen("ls "+fold).read()
        fils=fil.split("\n")
        for fil in fils:
            if("_alives" in fil):
                f2=open(alives,"r")
                f2=[i.replace("\n","") for i in f2.readlines()]
                if(f2!=[]):
                    dct[domain]["alivehost"]=f2
            elif("_domains" in fil):
                f3=open(domains,"r")
                f3=[i.replace("\n","") for i in f3.readlines()]
                if(f3!=[]):
                    dct[domain]["domains"]=f3
            elif("_vulns" in fil):
                f4=open(vuln,"r")
                f4=[i.replace("\n","") for i in f4.readlines()]
                if(f4!=[]):
                    dct[domain]["vulns"]=f4
            elif("fingerprintx" in fil):
                f5=open(port,"r")
                rs=[]
                for i in f5.readlines():
                    if(" " in i):
                        i=i.replace("\n","")
                        rs.append(i)
                if(rs!=[]):
                    dct[domain]["port"]=rs
        return dct


def addDomain(domain):
    obj=Data()
    res=obj.getDomain(domain)
    res={"Domain":res}
    getid=url_domain+"api/job/getID?domain="+domain
    id=requests.get(getid)
    id=id["ID"]
    api=url_domain+"api/result?type=Domain_Automation&id="+id
    requests.post(api,json=res)

addDomain(sys.argv[1])




        




        



