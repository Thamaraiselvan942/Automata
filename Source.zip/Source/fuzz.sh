domain=$2
rm -rf /home/site24x7/HACK_WITH_AUTOMATION/$2/screenshots/
for i in $(cat $1);do
  cd /home/site24x7
  echo "IP Address: $i" >>find.txt
  var=$(echo "$i" | sudo /usr/local/bin/armada --top1000 |httpx -silent)
  echo $var >>find.txt
  for j in $(echo "$var");do
    cd /home/site24x7
    echo "$j"
    stcode=$(curl -s -o /dev/null -w "%{http_code}" "$j")
    echo "Status code: $stcode"
    r=1
    if [ $stcode -ne 400 ]
     then
      #ffuf -w SecLists/Discovery/Web-Content/directory-list-lowercase-2.3-medium.txt -u "$j"/FUZZ -mc 200 -fs 42 -se true -t 300 -c -o find2.txt
      #Discovery/Web-Content/common.txt
      ffuf -w SecLists/Discovery/Web-Content/common.txt -u "$j"/FUZZ -mc 200 -fs 42 -t 300 -sf -c -recursion -o find2.txt
      result=$(jq -r '.results[] | "\(.url)"' /home/site24x7/find2.txt | grep -iv "#")
      count=$(jq -r '.results[] | "\(.url)"' /home/site24x7/find2.txt | grep -iv "#" | wc -l)
      url=$(echo "$j" | sed 's#//\|/\|:#-#g')
      echo "$result" >> /home/site24x7/RESULT/"$url"
      echo "Count: $count"
      cd /home/site24x7/HACK_WITH_AUTOMATION/$domain
      if [ $count -lt 100 ]
       then
         echo "Take Screenshot..."
         for k in $(echo "$result");do
           : '
           if [ $r -eq 1 ]
             then
               echo "$dat"
               telegram-send "IP Address: $i"
               r=0
           fi
           telegram-send "$k"
             '
           img=$(echo "$k" | sed 's#//\|/\|:#-#g')
           gowitness single -o "$img"  "$k" --delay 20
           check_sum=$(md5sum /home/site24x7/HACK_WITH_AUTOMATION/$2/screenshots/"$img".png  | cut -f1 -d " ")
           echo "md5sum: $check_sum"
           is_exist=$(find /home/site24x7/HACK_WITH_AUTOMATION/$2/screenshots/ -iname "*.png" -exec md5sum {} + |cut -f1 -d " " | grep -c "$check_sum")
           echo "Unique Img: $is_exist"
           if [ $is_exist -eq 1 ]
             then
               if [ $r -eq 1]
                 then
                   echo "$dat"
                   telegram-send "IP Address: $i"
                   r=0
               fi
               telegram-send "$k"
               #echo "Unique Img: $is_exist"
               telegram-send --file /home/site24x7/HACK_WITH_AUTOMATION/$2/screenshots/"$img".png
           fi
         done
      fi
    fi

  done
  echo "=========================================================================================================================" >>find.txt

done
