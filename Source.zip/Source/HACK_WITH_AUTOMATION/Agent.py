import os
import sys
import requests
url_domain="http://172.20.10.4:8080/"
path="/media/sf_Workspace/Source"
class Data:
    def __init__(self):
        pass
    def upload(self,domain,id):
        pwd=os.getcwd()
        dct={}
        dct[domain]={}
        fold=path+"/HACK_WITH_AUTOMATION/"+domain+"/screenshots/"
        #data=os.listdir(fold)
        ls=[]
        pwd=os.popen(path+"/HACK_WITH_AUTOMATION/"+domain)
        if("screenshot" not in pwd):
            print("screenshot not found")
            return
        data=os.listdir(fold)
        for i in data:
            md5=os.popen('md5sum '+fold+i+' | cut -f1 -d " "' ).read()
            md5=md5.replace("\n","")
            if(md5 not in ls):
                ls.append(md5)
                with open(fold+i, 'rb') as f:
                    image_data = f.read()
                url=i.replace("-","/")
                #print(url)
                if(len(id)>5):
                    response = requests.post(url_domain+'/upload?img_name='+i+"&fold="+domain+"&id="+id+"&url="+url, data=image_data)
                    print(response.text)

    def getDomain(self,domain):
        pwd=os.getcwd()
        dct={}
        dct[domain]={}
        fold=path+"/HACK_WITH_AUTOMATION/"+domain
        total_host=0
        alives=fold+"/"+domain+"_alives.txt"
        domains=fold+"/"+domain+"_domains.txt"
        port=fold+"/"+domain+"_fingerprints.txt"
        vuln=fold+"/"+domain+"_vulns.txt"

        dct[domain]["domains"]=[]
        dct[domain]["vulns"]=[]
        dct[domain]["port"]=[]
        dct[domain]["alivehost"]=[]
        fil=os.popen("ls "+fold).read()
        fils=fil.split("\n")
        for fil in fils:
            if("_alives" in fil):
                f2=open(alives,"r")
                f2=[i.replace("\n","") for i in f2.readlines() ]
                if(f2!=[]):
                    dct[domain]["alivehost"]=f2
            elif("_domains" in fil):
                f3=open(domains,"r")
                f3=[i.replace("\n","") for i in f3.readlines() ]
                if(f3!=[]):
                    dct[domain]["domains"]=f3
            elif("_vulns" in fil):
                f4=open(vuln,"r")
                f4=[i.replace("\n","") for i in f4.readlines() if "\x00"  not in i]
                if(f4!=[]):
                    dct[domain]["vulns"]=f4
            elif("fingerprints" in fil):
                f5=open(port,"r")
                rs=[]
                for i in f5.readlines():
                    if(" " in i):
                        i=i.replace("\n","")
                        rs.append(i)
                if(rs!=[]):
                    dct[domain]["port"]=rs
        for i in f4:
            print(i)
        return dct


def addDomain(domain):
    obj=Data()
    res=obj.getDomain(domain)
    res={"Domain":res}
    #print(res)
    getid=url_domain+"api/job/getID?domain="+domain
    id=requests.get(getid)
    id=id.json()
    print(id)
    id=id["ID"]
    if(id!=""):
        api=url_domain+"api/result?type=Domain_Automation&id="+id
        requests.post(api,json=res)
        res=obj.upload(domain,id)

#addDomain("trainercentral.jp")
addDomain(sys.argv[1])
'''
obj=Data()
r=obj.getDomain("trainercentral.jp")
print(r)
'''
