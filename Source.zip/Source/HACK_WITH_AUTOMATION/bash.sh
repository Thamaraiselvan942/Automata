#! /bin/bash

arg=$1

subfinder -d $arg >> /media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$arg-domains.txt

