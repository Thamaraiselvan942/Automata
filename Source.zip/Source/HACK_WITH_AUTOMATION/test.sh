#!/bin/bash
source="site24x7.com"
python3 test.py $source
