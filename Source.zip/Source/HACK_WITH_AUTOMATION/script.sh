#!/bin/bash

#Requirements
#config.yaml

DOMAIN=$1

mkdir -p /media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$DOMAIN
OUTPUT="/media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$DOMAIN"
ip="/media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$DOMAIN/$1_ips.txt"
echo $ip
echo "[+] Nuclei Update"
sudo nuclei -update -silent
echo "[+] AssetFinder"
assetfinder --subs-only $DOMAIN | tee $OUTPUT/$1-asset-domains.txt
echo "[+] SubFinder"
subfinder -d $DOMAIN -silent -config /media/sf_Workspace/Source/HACK_WITH_AUTOMATION/config.yaml -recursive -all -o $OUTPUT/$1-subfinder-domains.txt
echo "[+] Amass"
amass enum -d $DOMAIN -o $OUTPUT/$1-amass-domains.txt
echo "[+] Github-Subdomains"
github-subdomains -t tokens.txt -d $DOMAIN -raw -o $OUTPUT/$1-github-domains.txt

cat $OUTPUT/*-domains.txt | anew $OUTPUT/$1_domains.txt
echo "[+] Resolve IP"
cat $OUTPUT/$1_domains.txt | while read HOST ; do ( dig +short $HOST | sed 's/\.$//' | anew -q $OUTPUT/$1_ips.txt ) ; done
echo "[+] Port Scan"
cat $OUTPUT/$1_ips.txt | grep -oE "(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])|(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\/(1[0-9]|2[0-9])" | sudo /home/kali/.cargo/bin/armada -p 1-65535 | anew $OUTPUT/$1_ports.txt
fingerprintx --json -l $OUTPUT/$1_ports.txt -o $OUTPUT/$1_fingerprints.txt

cat $OUTPUT/$1_domains.txt $OUTPUT/$1_ports.txt $OUTPUT/$1-amass-domains.txt | httpx -o $OUTPUT/$1_assets.txt

cat $OUTPUT/$1_assets.txt | sort | uniq > $OUTPUT/$1_alives.txt

echo "[+] Nuclei" 
nuclei -l $OUTPUT/$1_alives.txt -t ~/nuclei-templates -c 100 -silent -nc -es info -o $OUTPUT/$1_vulns.txt
#bash /home/site24x7/fuzz.sh $ip $DOMAIN
python3 /media/sf_Workspace/Source/HACK_WITH_AUTOMATION/Agent.py $DOMAIN

python3 /media/sf_Workspace/Source/dorks/simple.py $DOMAIN /media/sf_Workspace/Source/dorks/dorks.txt

python3 /media/sf_Workspace/Source/dorks/dorks.py $DOMAIN

