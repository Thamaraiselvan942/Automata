#!/bin/bash

#Requirements
#config.yaml


validate="^([a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]\.)+[a-zA-Z]{2,}$"
# If user doesn't enter anything
if [[ -z "$1" ]]; then
    echo "You must enter a domain"
elif [ -d "/media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$1" ]; then
    echo "Domain exists in our database"
elif [[ "$1" =~ $validate ]]; then

DOMAIN=$1
mkdir -p /media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$DOMAIN
OUTPUT="/media/sf_Workspace/Source/HACK_WITH_AUTOMATION/$DOMAIN"

sudo nuclei -update -silent

assetfinder --subs-only $DOMAIN | tee $OUTPUT/$1-asset-domains.txt

subfinder -d $DOMAIN -silent -config ~/config.yaml -recursive -all -o $OUTPUT/$1-subfinder-domains.txt

#amass enum -d $DOMAIN -o $OUTPUT/$1-amass-domains.txt

cat $OUTPUT/*-domains.txt | anew $OUTPUT/$1_domains.txt

cat $OUTPUT/$1_domains.txt | while read HOST ; do ( dig +short $HOST | sed 's/\.$//' | anew -q $OUTPUT/$1_ips.txt ) ; done
cat $OUTPUT/$1_ips.txt | grep -oE "(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])|(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\/(1[0-9]|2[0-9])" | armada -p 1-65535 | anew $OUTPUT/$1_ports.txt
fingerprintx --json -l $OUTPUT/$1_ports.txt -o $OUTPUT/$1_fingerprints.txt

cat $OUTPUT/$1_domains.txt $OUTPUT/$1_ports.txt | httpx -silent | anew $OUTPUT/$1_alives.txt

nuclei -l $OUTPUT/$1_alives.txt -t ~/nuclei-templates -c 100 -silent -nc -o $OUTPUT/$1_vulns.txt

else
    echo "Enter a valid domain name"
fi
