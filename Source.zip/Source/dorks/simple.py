import requests
import sys
from bs4 import BeautifulSoup
import re
import time
host=sys.argv[1]
query=sys.argv[2]
fl=open("/media/sf_Workspace/Source/dorks/results/"+host+".txt","w")
if query.endswith(".txt"):
    with open(query,"r") as file:
        lines = file.readlines()
    for line in lines:
        query=line.strip()
        query=query.replace("$1",host)
        page = requests.get("https://www.google.com/search?q="+query)
        time.sleep(5)
        soup = BeautifulSoup(page.content,features="html.parser")
        links = soup.findAll("a")
        for link in  soup.find_all("a",href=re.compile("(?<=/url\?q=)(htt.*://.*)")):
            res=(re.split(":(?=http)",link["href"].replace("/url?q=",""))[0])
            if("&" in res):
                r=res.index("&")
                url=res[:r]
                if("google" not in url):
                    fl.write(url+"\n")
                    print(url)
    fl.close()

else:
    page = requests.get("https://www.google.com/search?q="+query)
    soup = BeautifulSoup(page.content,features="html.parser")
    links = soup.findAll("a")
    for link in  soup.find_all("a",href=re.compile("(?<=/url\?q=)(htt.*://.*)")):
        res=(re.split(":(?=http)",link["href"].replace("/url?q=",""))[0])
        if("&" in res):
            r=res.index("&")
            url=res[:r]
            if("google" not in url):
                fl.write(url+"\n")
    fl.close()
