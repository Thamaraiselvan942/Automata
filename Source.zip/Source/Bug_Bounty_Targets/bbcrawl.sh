#!/bin/bash
current_dir=$(pwd)
count=0
while true; do
  directory_name="bounty-targets-data"
  if [ -d "$directory_name" ]; then
    echo "[+] Removing Directory $directory_name"
    sudo rm -rf "$directory_name"
  fi
  echo "[+] Cloning $directory_name"
  git clone https://github.com/arkadiyt/bounty-targets-data.git
  echo "[+] Extracting TLD"
  cat "$current_dir/bounty-targets-data/data/domains.txt" | egrep -v '^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$' | rev | cut -d'.' -f1-2 | rev | sort -u >>tl_domain.txt
  if [ $count -eq 0 ]; then
   echo "[+] Count=$count"
   cp tl_domain.txt oldtl_domain.txt
  else
   echo "[+] $count"
   diff oldtl_domain.txt tl_domain.txt  | grep '^>' | cut -c3- >>new_domain.txt
   cp tl_domain.txt oldtl_domain.txt
  fi
  let count+=1
  echo "[+] Sleep 1min"
  sleep 60 # sleep for 30 minutes
done
