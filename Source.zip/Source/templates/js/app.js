var app = angular.module('asm.app', ['ui.router', 'chart.js']); 


app.controller('AppController', ['$scope', '$stateParams',function($scope, $state, $stateParams) {

	$scope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];

	$scope.domain_details = {
		"domain_id": 1, 
		"domain_name": "site24x7.com", 
		"repetition": "Everyday at 10 AM",
		"subdomain_count": 10,
		"alive_count": 5,
		"ports_count": 100,
		"vulnerabilities":{
			"info": 1,
			"low": 2,
			"medium": 3, 
			"high": 4, 
			"critical": 5
		},
		"vulnerability_details":[
			{
				"vuln_asset": "https://www.site24x7.jp", 
				"vuln_severiy": "info", 
				"vuln_protocol": "http",
				"vuln_name": "openssl-detect", 
				"vuln_service": "OpenSSL/1.0.2k"
			},
			{
				"vuln_asset": "https://18.140.106.135", 
				"vuln_severiy": "info", 
				"vuln_protocol": "http",
				"vuln_name": "apache-detect", 
				"vuln_service": "Apache"
			}
		],
		"port_details":[
			{
			  "ip": "117.20.43.49",
			  "port": 443,
			  "service": "https",
			  "version": "Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.4.9"
			}
		], 
		"histogram":[
			""
		]
	}

	$scope.domains = [
		{
			"domain_id": 1,
			"domain_name": "site24x7.com",
			"repetition": "Everyday at 10 AM",
			"subdomain_count": 10,
			"ports_count": 100,
			"vulnerabilities":{
				"info": 1,
				"low": 2,
				"medium": 3, 
				"high": 4, 
				"critical": 5
			}
		},
		{
			"domain_id": 2,
			"domain_name": "zoho.com",
			"repetition": "Everyday at 10 AM",
			"subdomain_count": 10,
			"ports_count": 100,
			"vulnerabilities":{
				"info": 1,
				"low": 2,
				"medium": 3, 
				"high": 4, 
				"critical": 5
			}
		},{
			"domain_id": 3,
			"domain_name": "downradar.net",
			"repetition": "Everyday at 10 AM",
			"subdomain_count": 10,
			"ports_count": 100,
			"vulnerabilities":{
				"info": 1,
				"low": 2,
				"medium": 3, 
				"high": 4, 
				"critical": 5
			}
		},{
			"domain_id": 4,
			"domain_name": "zohocrm.com",
			"repetition": "Everyday at 10 AM",
			"subdomain_count": 10,
			"ports_count": 100,
			"vulnerabilities":{
				"info": 1,
				"low": 2,
				"medium": 3, 
				"high": 4, 
				"critical": 5
			}
		}
	];

  $scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.series = ['Series A', 'Series B'];
  $scope.data = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  $scope.options = {
    scales: {
      yAxes: [
        {
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left'
        },
        {
          id: 'y-axis-2',
          type: 'linear',
          display: true,
          position: 'right'
        }
      ]
    }
  };


  $scope.pie_labels =["Critical", "High", "Medium", "Low", "Info"];

  $scope.pie_data = [
    [1, 2, 3, 4, 5]
  ];


}]);

app.controller('AddDomainController', ['$scope', '$stateParams',function($scope, $state, $stateParams) {
	console.log("adding a domain");

}]);

//ui-router
app.config(['$stateProvider', '$urlRouterProvider','ChartJsProvider', function($stateProvider, $urlRouterProvider, ChartJsProvider){ 
	(function (ChartJsProvider) {
  ChartJsProvider.setOptions({ colors : [ '#803690', '#00ADF9', '#DCDCDC', '#46BFBD', '#FDB45C', '#949FB1', '#4D5360'] });
}); 


	$urlRouterProvider.when('', '/domains/list');//NO I18N
  var domainState = {
    name: 'domains',
    url: '/domains/list',
    templateUrl: 'templates/domains.html'
  }

  var addDomainState = {
    name: 'add-domain',
    url: '/add-domain',
    templateUrl: 'templates/add-domain.html',
    controller: "AddDomainController"
  }

  var domainDetails = {
  	name: 'domain-details',
    url: '/domains/:domain_id',
    templateUrl: 'templates/domain-details.html'
  }
  // var subdomain = {
  // 	name: 'domains.subdomains',
  //   url: '/subdomains/list',
  //   templateUrl: 'templates/subdomains.html'
  // }
  // var subdomain = {
  // 	name: 'domains.subdomain-details',
  //   url: '/subdomains/:subdomain_id',
  //   templateUrl: 'templates/subdomain-details.html'
  // }

  var aboutState = {
    name: 'domains/',
    url: '/about',
    template: '<h3>Its the UI-Router hello world app!</h3>'
  }

  $stateProvider.state(domainState);
  $stateProvider.state(aboutState);
  $stateProvider.state(domainDetails);
  $stateProvider.state(addDomainState);
}]);
