from ast import arg
from crypt import methods
from importlib.metadata import requires
from logging import critical
from multiprocessing import connection
from pickletools import read_string1
import subprocess
import os
from distutils.log import debug
from turtle import delay
from flask import Flask,render_template,url_for,request,redirect
import sys
from h11 import Data
import os
import redis
from rq import Queue
from concurrent.futures import ThreadPoolExecutor
import time
import json
import mysql.connector
import re
import Server.db.Database as db
import trigger.Domain as dm
app=Flask(__name__)
r=redis.Redis()
q=Queue(connection=r)
tmp=""
class User:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    

@app.route('/')
def index():
    return render_template('index.html')


def isValidDomain(str):
    regex = "^((?!-)[A-Za-z0-9-]" +"{1,63}(?<!-)\\.)" +"+[A-Za-z]{2,6}"
    p = re.compile(regex)
    if(str.count(".")<=2):
        if (str == None):
            return False
        if(re.search(p, str)):
            return True
        else:
            return False
@app.route('/api/add-domain',methods=["GET","POST"])
def Add_domain():
    if request.method=="POST":
        args = request.args
        res=request.get_json()
        
    if(res!=None and res!={}):
        k=res.keys()
        ln=len(k)
        if((ln==1 or ln==2) and ("domain-name" in k )):
            flg=isValidDomain(res["domain-name"])
            if(flg):
                id='job_id'+str(int(time.time()*1000))
                #check Database 
                obj=db.Database()
                obj.CreateDatabase()
                table="Domains"
                result=obj.WriteDB(id,res,table)
                domain=res["domain-name"]
                freq=1
                if("freq" in k):
                    freq=res["freq"]

                job=q.enqueue(dm.addDomain,args=(domain,freq,id),job_timeout=3600,job_id=id)
                q_len=len(q)
                r.set("Domain"+job.id,"")
                return result
            else:
                return  {"status":"Invalid Domain"}
        else:
            return {"status":"invalid data",
                    "data":{"add-domain":"","freq":""
                    }}

    return {"status":"Invalid Data"}

@app.route('/api/get-summary',methods=["GET","POST"])
def Get_Summary():
    if request.method=="GET":
        args = request.args
        code=args.get("code")

@app.route('/api/result',methods=["GET","POST"])
def StatusUpdate():
    if request.method=="POST":
            args = request.args
            type=args.get("type")
            jid=args.get("id")
            res=request.get_json()
            print("true")
            if("Domain" in type):
                res=res["Domain"]
                obj=db.Database()
                table="StoreDB"
                result=obj.WriteDB(jid,res,table)
            return {"status":"success"}
    else:
        return {"status":"GET"}
                
@app.route('/api/job/getID',methods=["GET","POST"])
def getID():
    if request.method=="GET":
            args = request.args
            domain=args.get("domain")
            obj=db.Database()
            table="GetID"
            id=obj.ReadDB(domain,table)
    return {"ID":id}

@app.route('/api/domain/list',methods=["GET","POST"])
def getSummary():
    if request.method=="GET":
            args = request.args
            obj=db.Database()
            table="Summary"
            result=obj.ReadDB("",table)
    return {"result":result}

@app.route('/api/assets/<section>',methods=["GET","POST"])
def Assets(section):
    if request.method=="GET":
            assert section == request.view_args['section']
            job_id=section
            obj=db.Database()
            table="Assets"
            print(job_id)
            result=obj.ReadDB(job_id,table)
    return result
            
           
    
     

if __name__  == "__main__":
    app.run(debug=True)